# FARISS RACING GAME — FRISS EDITION

An Android arcade-racing school-project prototype using a Java Android UI and C++17 native gameplay through JNI. This package contains the Android project, art assets, audio assets, and a GitHub Actions workflow in one ZIP.

## Features included in source

### Game and controls
- Portrait Android arcade racing game with neon road, scrolling city silhouettes and lane markings.
- On-screen LEFT and RIGHT buttons, plus a hold-to-use NOS button.
- Player car sprites, traffic cars, rival cars, police pursuit NPC, truck obstacles and coin pickups.
- Nitro energy bar and boost streak visuals; collisions trigger Game Over.
- Pause, restart and return-to-menu flow.

### Audio
- Original procedurally generated offline dashboard soundtrack (`dashboard_music.wav`).
- Separate original in-game racing soundtrack (`racing_music.wav`).
- Sound effects for UI button taps, NOS, coin pickups, crashes, and a low-volume looping engine sound.
- Music and sound effects can be toggled in Settings. App pauses audio when put in the background.

### Player profiles
- Local registration with unique generated Player ID (`FRS-XXXXXXXX`), username and password.
- Login using username or Player ID.
- Password hashes are stored rather than plain-text passwords.
- Per-profile best score, wallet coins, car style, upgrades, settings and local leaderboard.

### Wallet, top-up and admin
- In-game coin wallet, garage, upgrades, leaderboard and a **demo-only coin top-up screen**.
- Local demo admin dashboard can look up a registered Player ID, ban/unban that local profile, and grant 1,000 demo coins.
- Demo admin PIN: `246810`.

**Important limitation:** profiles, bans, admin actions, wallet and top-ups are stored only on the current device. The demo top-up does not charge money and is not a real payment system. The admin PIN is deliberately only a demonstration gate, not production security. A real game with accounts shared across devices, server-side bans and real top-ups requires a secure backend/database, server authorization and a legitimate payment provider; those services are not included or claimed to be active in this package.

### Developer menu
- TikTok: https://www.tiktok.com/@frissanjaymabar
- Instagram: https://www.instagram.com/frisswho?vrfl=M3FqeTRqbDd4dHF4
- Telegram: https://t.me/farisisheree

## How to use this ZIP with the existing repository

If the repository currently stores this source archive as `FARISS_RACING_GAME.zip` and has an **Auto Unzip Fix** workflow:
1. Replace the repository file `FARISS_RACING_GAME.zip` with this package (keep the filename exactly the same).
2. Keep the repository's `.github/workflows/android.yml` auto-unzip workflow as-is.
3. Commit the ZIP replacement and run Actions. That workflow should extract the package, find `settings.gradle`, and build it.
4. Download the artifact named `FARISS_RACING_GAME` from a successful run; it contains `FARISS_RACING_GAME.apk`.

If uploading the extracted project directly instead, upload all files/folders from this ZIP to the repository root (including the hidden `.github` folder) and use the included direct-build workflow.

## Toolchain
- JDK 17
- Android SDK Platform 35 / Build Tools 35.0.0
- Android NDK 27.2.12479018
- CMake 3.22.1
- Gradle 8.9

## Status
The full project and workflow are prepared, but this chat has not run a full Android Gradle/NDK build or installed the APK on a device. Use GitHub Actions logs to verify compilation, then test the resulting APK. This is a local school-project prototype, not a production-ready online game.


## Firebase configuration added (initial integration step)

- Added the Firebase `google-services.json` to `app/`.
- Added Google Services Gradle plugin and Firebase Authentication + Cloud Firestore SDK dependencies.
- Added Android INTERNET permission.
- Firebase project ID: `fariss-racing-game`; Android package: `com.friss.neonracer`.

Important: this is the Firebase SDK/configuration setup only. The current Java gameplay, login, wallets, admin tools and bans still use local SharedPreferences and are NOT yet synced to Firebase. Do not treat this ZIP as an online multiplayer build yet. Before online player data is enabled, implement Firebase Auth flows, secure Firestore rules, and server-authorized admin coin/ban operations. Multiplayer position synchronization is a separate next step.


## Neon UI + swipe controls refresh
- Refreshed menu styling with dark navy/cyan glass cards, stronger hierarchy, quick-start race CTA, and compact garage/upgrades row.
- Admin Dashboard is hidden from the visible menu. Open it by long-pressing the main menu logo, then enter the demo PIN. This remains local-only and is not secure for online admin use.
- In-race steering now uses horizontal swipes; swiping upward triggers NOS. The on-screen control bar shows swipe guidance and a NOS button.
- Firebase SDK/configuration is still only initialized at build/config level. Player accounts, coins, bans and multiplayer are not yet synced online.


## Motion / UI refresh
- Added animated startup splash with logo scale/fade and progress fill.
- Added smooth transitions when switching overlays.
- Added race entry sequence with animated 3-2-1-GO overlay before controls activate.
- Main menu uses the neon/navy card layout and keeps admin access hidden behind a long-press on the logo plus the demo PIN.
- Driving is gesture-only: swipe left/right to steer and swipe up to trigger NOS; the bottom HUD is instructions only, not tap controls.
- Firebase SDK/configuration is included, but player accounts, wallets, admin actions and multiplayer are still local-only until Firebase Auth/Firestore logic and secure server-authorized admin actions are implemented.


## Multiplayer + UI refresh (October 2026)

### Implemented in source
- Firebase-backed online lobby with public and private rooms.
- Optional room password. The password hash is stored separately from room metadata and private-room join proofs are checked by the included Firestore rules.
- Room codes are six hexadecimal characters. Private rooms are not shown in the public list; players can join with the code.
- Capacity is four players. The host can manually start when at least two have joined; the host auto-starts when the room reaches 4/4.
- Firestore listeners keep the room roster and racing presence updated. Remote racers are drawn as opponent cars while driving. Each device still runs its own local traffic/collision simulation; this is an early real-time racing prototype, not a fully authoritative shared physics simulation.
- Global leaderboard uses `leaderboard/{Firebase UID}` records, stores each online session's best score, and orders entries descending. Only scores written after this feature is added appear on the global board.
- Refreshed type hierarchy, gradient buttons, translucent panels, and animated neon background.

### Required Firebase setup before testing
1. In Firebase Console → Authentication → Sign-in method, enable **Anonymous**. The pre-existing local username/password profile system is not automatically migrated into Firebase Authentication; anonymous Firebase identity is used for lobby/leaderboard networking in this build.
2. Open Firestore → Rules. Review any existing rules first, then apply the rules from `firestore.rules`. These rules cover `rooms` and `leaderboard`; the old local login/wallet/admin code does not write to the `players` collection. Do not add a broad `allow read, write: if true` rule.
3. Build the APK and test with two physical devices or two separate app installs, since one Firebase anonymous UID represents one app installation. Create a room on device A, join using its code on device B, then start from A.

### Important limitations
- The existing player profiles, wallet/coins, top-ups and demo admin ban/unban are still local to the device in this source. This patch does not claim to turn those systems into online account administration.
- The global leaderboard accepts client-submitted scores. Production anti-cheat, permanent user accounts, online wallet transactions, and server-authorized bans require a trusted backend (for example Cloud Functions/Cloud Run) and are not implemented here.
- Rooms and presence can remain in Firestore after app closure. Close the room from its host device when finished.
- This chat environment did not have the Android SDK/Gradle toolchain installed, so no successful Gradle/NDK build or installed-APK test is claimed. Use the included GitHub Actions workflow and review the build log.
