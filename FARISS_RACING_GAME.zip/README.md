# NEON RACER — FRISS EDITION / Phase 2 OpenGL ES 3.0 — Neon City Update

Android portrait-menu / landscape-racing project using Java Android UI, Firebase Auth/Firestore, and C++17 through JNI.

## Phase 2 — Neon City gameplay renderer

The in-race scene uses a native OpenGL ES 3.0 renderer hosted by `GLSurfaceView`; Android menus and account screens remain portrait while the race switches to landscape. The previous Canvas renderer is retained in the native source as a compatibility/reference path, but the gameplay surface calls `nativeRenderGL()`. The logo pack and all Android launcher icon densities have also been refreshed with the NR / NEON RACER identity.

### Implemented in this stage
- OpenGL ES 3.0 context and native C++ shader/VBO pipeline.
- Perspective projection and a third-person chase camera that follows the player's lane.
- Procedural 3D road, curved road segments, shoulders, lane markings, neon edge strips and guardrails.
- Nighttime cyber-city skyline, neon gantries, roadside towers, blue/cyan lighting and road reflections.
- Detailed low-poly 3D chase-view vehicle bodies with rear glass, wheels, tail lamps, diffusers, aero wings, and ten NPC body/paint variants.
- Multi-lane NPC traffic, rivals, trucks, collectible coins, nitro trails, rain/fog presentation, touch steering buttons and a landscape speed HUD.
- Existing gesture steering, hold-to-use nitro, pause flow, speed/gear HUD, score, collision and coin collection remain connected to the native game state.
- OpenGL runs on a dedicated `GLSurfaceView` render thread; shared JNI gameplay state is protected by a mutex.
- Remote multiplayer racers are still drawn by a transparent Android overlay above the OpenGL surface.

### Important scope note
This is the first implementation stage of the OpenGL migration. Cars and scenery are procedural low-poly 3D geometry, not imported high-detail vehicle/track assets. The road uses a lightweight curve profile and the current handling remains arcade-style. It is a real perspective OpenGL scene, but not yet a full simulator with detailed 3D asset packs, physically based materials, suspension physics or a track editor.

## Existing features retained
The Java application flows and Firebase integration were kept in place:
- Existing local player login/create-player flow and Player IDs.
- Firebase Anonymous Authentication for online rooms and global leaderboard.
- Public/private rooms, room codes, roster/presence listeners and score publishing.
- Global leaderboard read/write flow.
- Local wallet, manual Telegram top-up flow, admin PIN gate, player lookup, local ban/unban and coin-credit tools.
- Garage car selection, car presets, speed/nitro/handling upgrade levels and local progression.
- Settings for music, sound effects, visual effects, weather and left-handed controls.

### Existing data/security limitations are unchanged
- Username/password profiles, wallet balance, admin coin credits, local bans, garage and upgrades remain local SharedPreferences data.
- The admin PIN is a demo gate, not production authentication.
- Telegram top-up remains a manual order; payments are not processed automatically.
- Multiplayer remains a shared-room/presence prototype with local race simulation on each device. It does not provide authoritative server physics or anti-cheat.
- Leaderboard scores are client-submitted; production competitive use needs trusted server-side validation.
- Secure online wallet/admin operations require a trusted backend and verified administrator identity.

## Build with GitHub Actions
1. Push the project contents to the repository's `main` or `master` branch, or run the workflow manually.
2. Keep `app/google-services.json` for Firebase project `fariss-racing-game` and Android package `com.friss.neonracer`.
3. Enable Firebase Anonymous Authentication and publish `firestore.rules` in Firebase Console.
4. Run GitHub Actions → **NEON RACER - Build APK**.
5. Download the `NEON_RACER_FRISS_EDITION` APK artifact only after the workflow succeeds.
6. Test on a physical Android device that supports OpenGL ES 3.0. Check offline race, touch steering, NOS, pause/resume, coin pickup, garage/upgrades, leaderboard and two-device room sync.

## Toolchain
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 / Gradle 8.9
- Android NDK 27.x / CMake 3.22.1
- OpenGL ES 3.0
- App version: 3.2-neon-city (versionCode 11)

## Verification performed for this source package
- ZIP source extracted and edited from the supplied NEON_RACER_PHASE2_OPENGL project.
- C++17 syntax check passed using JNI headers and an OpenGL ES declaration stub.
- Java syntax scan found no parser-level errors; a full Android Java/resource build was not possible in this environment because Android SDK/Gradle are not installed.
- APK has not been built or device-tested here. GitHub Actions must confirm the full Android/NDK build before installing.

## Phase 2 staged roadmap
- **Stage 1 — OpenGL foundation (included):** ES 3.0 surface, landscape chase camera, curved 3D road, low-poly vehicle bodies, night-city scenery and existing gameplay-state integration.
- **Stage 2 — Asset upgrade (next):** replace procedural low-poly bodies with optimized GLB/OBJ meshes, add PBR-style textures/materials, proper wheel meshes, track props and car-specific lighting.
- **Stage 3 — Driving feel (next):** delta-time steering, acceleration/braking, drift grip, suspension movement, camera banking, collision response and track boundaries.
- **Stage 4 — Content and optimization (next):** multiple tracks/environments, LOD, batching/instancing, quality presets and profiling on low/mid-range Android devices.

The stages are intentionally separated so the existing account, Firebase, wallet, admin, garage and upgrade systems can stay stable while the renderer evolves.


## Phase 3.3 – FRISS Logo + 10-car Garage

- Replaced the in-game wordmark assets with the exact supplied NEON RACER / FRISS EDITION logo artwork (black board background keyed to transparency).
- Replaced Android launcher icon density variants with the supplied NR app icon.
- Added ten independent car preview assets: Takara, Kurosawa, Toro, Velare, Nemo, Hayate, Raijin, Vortex, Blaze, and Shinobi.
- Expanded player garage/customization and persistent selected-car setting from 4 to 10 vehicles.
- Expanded `nativeSetCarStyle` and the OpenGL player renderer to select one of ten distinct vehicle geometry profiles. NPC traffic/rivals also use the same ten geometry profiles.
- The ten low-poly OpenGL bodies now have distinct proportions, cabin footprints/heights, wheelbase, tail-light layout, wing/ducktail, intakes, hood vents, side skirts and model-specific body details. This is actual procedural 3D geometry, not just a tint swap or a static gameplay image.

### Model map
1. Takara FR-90 – tuner sedan
2. Kurosawa GTR-R34 – wide GT coupe
3. Toro LP-700 – low supercar
4. Velare F8 – exotic mid-engine coupe
5. Nemo GT3 RS – luxury GT
6. Hayate WRX STI – rally sedan
7. Raijin EVO IX – rally/tuner sedan
8. Vortex M4 – long sports coupe
9. Blaze SRT – muscle coupe
10. Shinobi Civic Type R – compact hot hatch

Android project remains source-only in this package. A local APK build was not run because this environment does not have the Android SDK/NDK or Gradle executable configured. Build using Android Studio / the included GitHub Actions workflow.
