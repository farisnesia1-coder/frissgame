# FARISS RACING GAME — NEON RACER / FRISS EDITION V3.0

Android portrait arcade-racing project built with Java Android UI and C++17 native gameplay through JNI.

## V3.0 integrated upgrade

### Gameplay rendering and driving
- Expanded neon-night city backdrop with skyline blocks, building windows, horizon glow, moon/stars and animated roadside light pylons.
- Perspective road guides, reflective road highlights, cyan road edges and player-car underglow/contact shadow.
- Selectable Clear Night / Rainy City / Fog Mode visual weather in Settings.
- In-race HUD now includes estimated speed, gear, score, collected coins and personal best.
- Existing gesture controls remain: swipe left/right to steer; swipe upward for NOS.
- Existing NPC traffic, rival, truck, coins, police chase, nitro, collision/game-over, race countdown, audio and upgrades are retained.
- Rendering is procedural and lightweight; this is still a 2D portrait arcade racer, not a 3D driving simulator.

### Player progression
- Career XP and player level, with Rookie / Silver / Gold / Platinum / Diamond / Neon Legend rank titles.
- Daily Operations: finish one race, reach 500 points in one race, and collect 10 coins in a day. Rewards can be claimed once per local calendar day.
- Local achievement badges: First Finisher, Score Hunter, Coin Collector and Road Veteran.
- Career race count, total score, total coins earned and personal best.
- Garage car preset selection, existing speed/nitro/handling upgrades, and visual-effects customization.

### Online services already present in the project
- Firebase Anonymous Authentication for the online lobby and leaderboard (separate from the local username/password profile prototype).
- Public and private rooms, optional room password, shareable room code, max 4 members.
- Host can start a waiting room with at least 2 players; host auto-starts when 4 players have joined.
- Firestore listeners synchronize room state, roster and simple remote racer lane/score presence.
- Global leaderboard writes best score per Firebase anonymous UID and loads the top 50 rows.
- Apply `firestore.rules` in Firebase Console → Firestore Database → Rules.
- Enable Firebase Authentication → Sign-in method → Anonymous.
- Private room password hash is kept in a host-only secret document; do not replace the rules with public read/write rules.

## Existing local-only features / limitations

The following are still local to each device and are not made online by this V3.0 update:
- Username/password profile and the player ID used by the local account system.
- Wallet balance, manual admin coin credits, local ban/unban, and top-up confirmation.
- The admin PIN `246810` is a demonstration gate only, not secure administrator authentication.
- Telegram top-up opens a manual order chat; it does not process payments or credit a wallet automatically.
- Career XP, daily mission progress/rewards, achievements and garage upgrades are local SharedPreferences data.

Multiplayer is an early shared-room/presence prototype. Each phone still runs its own local traffic, police, collisions and score simulation. Remote racer display is approximate; there is no authoritative shared physics, matchmaking service, network interpolation/anti-cheat, or guaranteed cleanup of abandoned rooms. The global leaderboard score is client-submitted and needs trusted server-side verification before public competitive use.

Secure online wallet/admin operations require a trusted backend (for example Cloud Functions or another server) plus verified administrator identity. Do not grant players direct write access to coin balances or banned flags.

## Build using GitHub Actions

1. Replace the repository project source with the contents of this ZIP. Keep the repository workflow compatible with the included `.github/workflows/android.yml`.
2. Keep `app/google-services.json` for Firebase project `fariss-racing-game` and Android package `com.friss.neonracer`.
3. In Firebase, enable Anonymous Authentication and publish `firestore.rules`.
4. Run GitHub Actions → **FARISS RACING GAME - Build APK**.
5. Download the APK artifact only after the workflow succeeds.
6. Test first on one device (offline race, weather, missions, career, garage), then two devices (public room, private room with/without password, host start at two players, and remote racer updates).

## Toolchain
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 / Gradle 8.9
- NDK 27.x / CMake 3.22.1
- App version: 3.0 (versionCode 9)

## Verification
- ZIP integrity checked.
- C++17 source passed `g++ -fsyntax-only` against JNI headers.
- Java delimiter / source-structure checks are performed before packaging.
- This environment does not contain Android SDK / Gradle, so a successful APK build is **not** claimed. GitHub Actions must confirm the Android Java/resource/NDK build.
