# NEON RACER — FRISS EDITION (Complete GitHub Package)

A mobile arcade racing school project for Android. The Android frontend is written in Java; gameplay and rendering logic use C++17 via JNI.

## What's included
- **Logo integration:** the custom NEON RACER / FRISS EDITION logo is shown on the in-game main menu.
- **Android launcher icon:** app icon PNGs and round-icon variants at mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi densities, configured in `AndroidManifest.xml`.
- **Brand files:** main logo artwork, horizontal logo variation and the full branding board in `branding/`.
- Main menu, pause and game-over dialogs.
- Garage with four original player-car PNG sprite styles.
- PNG sprite assets for player, traffic, rival racers, police, truck and coins.
- Nitro meter and boost streak effects.
- AI traffic obstacles and rival cars that drift/change lanes.
- Police pursuit that activates as the race progresses; nitro helps delay the chase.
- Collectible coins and an in-game wallet.
- Upgrades for speed, nitro and handling, purchased with collected coins.
- Local leaderboard with top ten scores.
- Persistent best score, local records, wallet, selected car, upgrades and settings using SharedPreferences.
- Settings for visual effects and left-handed controls.
- GitHub Actions workflow to build a debug APK after a push or manual workflow run.

## Build the APK through GitHub Actions
1. Create a repository on GitHub, for example `neon-racer`.
2. Extract this ZIP and upload **all contents** to the repository root, including the hidden `.github` folder. Do not upload the ZIP as a single repository file.
3. Commit the files to `main` or `master`.
4. Open **Actions** and select **Build NEON RACER APK**. A push should start it automatically; you can also select **Run workflow**.
5. After a successful run, open the workflow run and download the artifact named `neon-racer-debug-apk`.
6. Extract that artifact ZIP to find `app-debug.apk`, then install it on an Android device.

Create a GitHub repository: https://github.com/new

## Controls
- Tap the left third of the road to steer left.
- Tap the right third of the road to steer right.
- Hold the center part of the road to use nitro.
- Use the pause button at the top-right to pause, restart or return to the main menu.

## Local build requirements
- Android Studio
- JDK 17
- Android SDK Platform 35
- Android NDK 27.2.12479018 (or a compatible NDK)
- CMake 3.22.1
- Gradle 8.9 (configured in the GitHub Actions workflow)

## Status and limitations
This is a school-project prototype. An APK has **not** been compiled or device-tested from this chat; check the first GitHub Actions run before assuming the build succeeded. The leaderboard is local to one device, not online/multiplayer. Garage car selection changes the included player sprite. Audio is not included yet.
