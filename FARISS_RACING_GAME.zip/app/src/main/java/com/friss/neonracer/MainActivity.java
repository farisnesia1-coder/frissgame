package com.friss.neonracer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    static { System.loadLibrary("neonracer"); }

    private FrameLayout root;
    private GameView game;
    private TextView hud, bottomHint;
    private Button pauseButton;
    private View overlay;
    private SharedPreferences prefs;
    private Bitmap[] playerSprites = new Bitmap[4];
    private Bitmap trafficSprite, rivalSprite, policeSprite, truckSprite, coinSprite;
    private boolean inGame = false, gameOverHandled = false, pauseDialogOpen = false;
    private int carStyle, speedLevel, nitroLevel, handlingLevel;
    private boolean effectsOn, leftHanded;
    private final int screenBg = Color.rgb(5, 10, 24);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("neon_racer_save", MODE_PRIVATE);
        loadSettings();
        loadSprites();
        immersive();

        root = new FrameLayout(this);
        game = new GameView();
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(13);
        hud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hud.setPadding(dp(14), dp(10), dp(64), dp(10));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(hud, hp);
        hud.setVisibility(View.GONE);

        pauseButton = new Button(this);
        pauseButton.setText("Ⅱ");
        pauseButton.setTextSize(16);
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setAllCaps(false);
        pauseButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(0, 113, 170)));
        pauseButton.setOnClickListener(v -> showPauseDialog());
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(48), Gravity.TOP | Gravity.RIGHT);
        pp.setMargins(0, dp(3), dp(6), 0);
        root.addView(pauseButton, pp);
        pauseButton.setVisibility(View.GONE);

        bottomHint = new TextView(this);
        bottomHint.setTextColor(Color.rgb(125, 230, 255));
        bottomHint.setTextSize(10);
        bottomHint.setGravity(Gravity.CENTER);
        bottomHint.setText("◀ LEFT       HOLD CENTER: NITRO       RIGHT ▶");
        bottomHint.setPadding(8, 8, 8, 12);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        root.addView(bottomHint, bp);
        bottomHint.setVisibility(View.GONE);
        setContentView(root);

        applyNativeOptions();
        showMenu();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void loadSettings() {
        carStyle = prefs.getInt("car_style", 0);
        speedLevel = prefs.getInt("speed_level", 0);
        nitroLevel = prefs.getInt("nitro_level", 0);
        handlingLevel = prefs.getInt("handling_level", 0);
        effectsOn = prefs.getBoolean("effects_on", true);
        leftHanded = prefs.getBoolean("left_handed", false);
    }

    private void loadSprites() {
        playerSprites[0] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player);
        playerSprites[1] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_red);
        playerSprites[2] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_purple);
        playerSprites[3] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_white);
        trafficSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_traffic);
        rivalSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_rival);
        policeSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_police);
        truckSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_truck);
        coinSprite = BitmapFactory.decodeResource(getResources(), R.drawable.coin_gold);
    }

    private Bitmap currentPlayerSprite() { return playerSprites[Math.max(0, Math.min(3, carStyle))]; }
    private String carName(int id) {
        switch (id % 4) {
            case 1: return "VOLT RS";
            case 2: return "PHANTOM X";
            case 3: return "POLAR GT";
            default: return "NEXUS GT";
        }
    }
    private void applyNativeOptions() {
        nativeSetUpgrades(speedLevel, nitroLevel, handlingLevel);
        nativeSetOptions(effectsOn, leftHanded);
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        t.setPadding(dp(8), dp(5), dp(8), dp(5));
        return t;
    }

    private Button button(String value, Runnable action, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setMinHeight(dp(46));
        b.setBackgroundTintList(ColorStateList.valueOf(primary ? Color.rgb(0, 145, 210) : Color.rgb(20, 45, 75)));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private LinearLayout makePanel(String titleText) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(20), dp(18), dp(18));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setBackgroundColor(screenBg);
        if (titleText != null && !titleText.isEmpty()) {
            TextView title = text(titleText, 27, Color.rgb(40, 220, 255));
            LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
            titleP.setMargins(0, 0, 0, dp(10));
            panel.addView(title, titleP);
        }
        return panel;
    }

    private void showOverlay(View v) {
        if (overlay != null) root.removeView(overlay);
        overlay = v;
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        hud.setVisibility(View.GONE);
        pauseButton.setVisibility(View.GONE);
        bottomHint.setVisibility(View.GONE);
        game.invalidate();
    }
    private void removeOverlay() {
        if (overlay != null) { root.removeView(overlay); overlay = null; }
    }
    private void addAction(LinearLayout panel, String label, Runnable action, boolean primary) {
        Button b = button(label, action, primary);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(4));
        panel.addView(b, p);
    }

    private void showMenu() {
        inGame = false;
        pauseDialogOpen = false;
        nativePause(true);
        nativeReset();
        loadSettings();
        applyNativeOptions();

        LinearLayout panel = makePanel("");
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAdjustViewBounds(true);
        logo.setContentDescription("NEON RACER FRISS EDITION logo");
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(-1, dp(278));
        logoParams.setMargins(0, 0, 0, dp(2));
        body.addView(logo, logoParams);
        body.addView(text("ANDROID ARCADE RACING", 12, Color.WHITE));
        body.addView(text("DODGE • BOOST • SURVIVE", 11, Color.rgb(135, 190, 220)));
        body.addView(text("BEST SCORE  " + prefs.getInt("best_score", 0), 16, Color.rgb(255, 208, 65)));
        body.addView(text("WALLET  " + prefs.getInt("bank_coins", 0) + " COINS", 14, Color.rgb(255, 205, 50)));
        addAction(body, "▶  START RACE", this::startGame, true);
        addAction(body, "GARAGE  •  " + carName(carStyle), this::showGarage, false);
        addAction(body, "UPGRADE SHOP", this::showUpgrades, false);
        addAction(body, "LOCAL LEADERBOARD", this::showLeaderboard, false);
        addAction(body, "SETTINGS", this::showSettings, false);
        body.addView(text("AI TRAFFIC • RIVALS • POLICE PURSUIT", 10, Color.GRAY));
        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }

    private void startGame() {
        removeOverlay();
        inGame = true;
        gameOverHandled = false;
        pauseDialogOpen = false;
        loadSettings();
        applyNativeOptions();
        nativeReset();
        nativePause(false);
        hud.setVisibility(View.VISIBLE);
        pauseButton.setVisibility(View.VISIBLE);
        bottomHint.setVisibility(View.VISIBLE);
        game.invalidate();
    }

    private void showPauseDialog() {
        if (!inGame || pauseDialogOpen) return;
        pauseDialogOpen = true;
        nativePause(true);
        new AlertDialog.Builder(this)
            .setTitle("RACE PAUSED")
            .setMessage("Catch your breath, racer.")
            .setCancelable(false)
            .setPositiveButton("RESUME", (d, w) -> {
                pauseDialogOpen = false;
                if (inGame) nativePause(false);
                game.invalidate();
            })
            .setNeutralButton("RESTART", (d, w) -> { pauseDialogOpen = false; startGame(); })
            .setNegativeButton("MAIN MENU", (d, w) -> { pauseDialogOpen = false; showMenu(); })
            .show();
    }

    private void finishGameIfNeeded() {
        if (!inGame || gameOverHandled || !nativeGameOver()) return;
        gameOverHandled = true;
        inGame = false;
        int score = nativeScore();
        int earned = nativeCoins();
        int best = Math.max(score, prefs.getInt("best_score", 0));
        int bank = prefs.getInt("bank_coins", 0) + earned;
        prefs.edit().putInt("best_score", best).putInt("bank_coins", bank).putInt("last_score", score).apply();
        saveLocalScore(score);
        hud.setVisibility(View.GONE);
        pauseButton.setVisibility(View.GONE);
        bottomHint.setVisibility(View.GONE);
        new AlertDialog.Builder(this)
            .setTitle("RACE OVER")
            .setMessage("Score: " + score + "\nBest: " + best + "\nCoins earned: " + earned + "\nWallet: " + bank)
            .setCancelable(false)
            .setPositiveButton("RACE AGAIN", (d, w) -> startGame())
            .setNeutralButton("GARAGE", (d, w) -> showGarage())
            .setNegativeButton("MAIN MENU", (d, w) -> showMenu())
            .show();
    }

    private void saveLocalScore(int score) {
        String raw = prefs.getString("local_scores", "");
        List<Integer> scores = new ArrayList<>();
        if (!raw.isEmpty()) for (String s : raw.split(",")) {
            try { scores.add(Integer.parseInt(s)); } catch (NumberFormatException ignored) { }
        }
        scores.add(score);
        Collections.sort(scores, Collections.reverseOrder());
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < Math.min(10, scores.size()); i++) {
            if (i > 0) out.append(',');
            out.append(scores.get(i));
        }
        prefs.edit().putString("local_scores", out.toString()).apply();
    }

    private void showGarage() {
        inGame = false;
        nativePause(true);
        LinearLayout panel = makePanel("GARAGE");
        panel.addView(text("SELECT YOUR RIDE", 12, Color.WHITE));
        ImageView carPreview = new ImageView(this);
        carPreview.setImageBitmap(currentPlayerSprite());
        carPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageP = new LinearLayout.LayoutParams(dp(116), dp(170));
        imageP.setMargins(0, dp(5), 0, dp(5));
        panel.addView(carPreview, imageP);
        panel.addView(text(carName(carStyle), 22, Color.rgb(80, 220, 255)));
        panel.addView(text("STYLE " + (carStyle + 1) + " / 4", 11, Color.LTGRAY));
        panel.addView(text("Speed " + (6 + speedLevel) + "/10   •   Handling " + (6 + handlingLevel) + "/10", 11, Color.WHITE));
        addAction(panel, "NEXT CAR  →", () -> {
            carStyle = (carStyle + 1) % 4;
            prefs.edit().putInt("car_style", carStyle).apply();
            showGarage();
        }, true);
        addAction(panel, "SELECTED  ✓  / BACK TO MENU", this::showMenu, false);
        addAction(panel, "UPGRADE SHOP", this::showUpgrades, false);
        showOverlay(panel);
    }

    private void showUpgrades() {
        inGame = false;
        nativePause(true);
        LinearLayout panel = makePanel("UPGRADE SHOP");
        int bank = prefs.getInt("bank_coins", 0);
        panel.addView(text("WALLET  " + bank + " COINS", 14, Color.rgb(255, 205, 55)));
        panel.addView(text("SPEED  LV." + speedLevel + "/5", 14, Color.WHITE));
        addAction(panel, speedLevel >= 5 ? "SPEED MAX LEVEL" : "UPGRADE SPEED  •  " + upgradeCost(speedLevel), () -> purchaseUpgrade("speed"), true);
        panel.addView(text("NITRO  LV." + nitroLevel + "/5", 14, Color.WHITE));
        addAction(panel, nitroLevel >= 5 ? "NITRO MAX LEVEL" : "UPGRADE NITRO  •  " + upgradeCost(nitroLevel), () -> purchaseUpgrade("nitro"), true);
        panel.addView(text("HANDLING  LV." + handlingLevel + "/5", 14, Color.WHITE));
        addAction(panel, handlingLevel >= 5 ? "HANDLING MAX LEVEL" : "UPGRADE HANDLING  •  " + upgradeCost(handlingLevel), () -> purchaseUpgrade("handling"), true);
        addAction(panel, "← BACK TO MENU", this::showMenu, false);
        showOverlay(panel);
    }
    private int upgradeCost(int level) { return 250 + level * 350; }

    private void purchaseUpgrade(String which) {
        int level = which.equals("speed") ? speedLevel : which.equals("nitro") ? nitroLevel : handlingLevel;
        if (level >= 5) return;
        int cost = upgradeCost(level), bank = prefs.getInt("bank_coins", 0);
        if (bank < cost) {
            new AlertDialog.Builder(this).setTitle("NOT ENOUGH COINS")
                .setMessage("Need " + cost + " coins. Race to collect more.")
                .setPositiveButton("OK", null).show();
            return;
        }
        bank -= cost;
        if (which.equals("speed")) speedLevel++;
        else if (which.equals("nitro")) nitroLevel++;
        else handlingLevel++;
        prefs.edit().putInt("bank_coins", bank).putInt("speed_level", speedLevel)
            .putInt("nitro_level", nitroLevel).putInt("handling_level", handlingLevel).apply();
        applyNativeOptions();
        showUpgrades();
    }

    private void showLeaderboard() {
        inGame = false;
        nativePause(true);
        LinearLayout panel = makePanel("LOCAL LEADERBOARD");
        panel.addView(text("TOP SCORES ON THIS DEVICE", 11, Color.LTGRAY));
        String raw = prefs.getString("local_scores", "");
        if (raw.isEmpty()) panel.addView(text("No races recorded yet. Start your first race!", 13, Color.WHITE));
        else {
            String[] scores = raw.split(",");
            for (int i = 0; i < scores.length; i++) panel.addView(text((i + 1) + ".   FRISS     " + scores[i], 14,
                i == 0 ? Color.rgb(255, 210, 65) : Color.WHITE));
        }
        panel.addView(text("BEST  " + prefs.getInt("best_score", 0) + "   •   TOTAL COINS  " + prefs.getInt("bank_coins", 0), 11, Color.rgb(75, 220, 255)));
        addAction(panel, "← BACK TO MENU", this::showMenu, true);
        showOverlay(panel);
    }

    private void showSettings() {
        inGame = false;
        nativePause(true);
        LinearLayout panel = makePanel("SETTINGS");
        panel.addView(text("VISUAL EFFECTS", 14, Color.WHITE));
        addAction(panel, "EFFECTS: " + (effectsOn ? "ON" : "OFF"), () -> {
            effectsOn = !effectsOn;
            prefs.edit().putBoolean("effects_on", effectsOn).apply();
            nativeSetOptions(effectsOn, leftHanded);
            showSettings();
        }, true);
        panel.addView(text("CONTROL LAYOUT", 14, Color.WHITE));
        addAction(panel, "LEFT-HANDED: " + (leftHanded ? "ON" : "OFF"), () -> {
            leftHanded = !leftHanded;
            prefs.edit().putBoolean("left_handed", leftHanded).apply();
            nativeSetOptions(effectsOn, leftHanded);
            showSettings();
        }, true);
        panel.addView(text("Audio is not included in this prototype.", 10, Color.GRAY));
        addAction(panel, "← BACK TO MENU", this::showMenu, false);
        showOverlay(panel);
    }

    @Override protected void onPause() {
        super.onPause();
        if (game != null && inGame) nativePause(true);
    }
    @Override protected void onResume() {
        super.onResume();
        immersive();
        if (game != null && inGame && !pauseDialogOpen) nativePause(false);
    }

    private class GameView extends View {
        GameView() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_HARDWARE, null); }
        @Override protected void onDraw(android.graphics.Canvas canvas) {
            super.onDraw(canvas);
            if (inGame) {
                nativeRender(canvas, getWidth(), getHeight(), currentPlayerSprite(), trafficSprite, rivalSprite, policeSprite, truckSprite, coinSprite);
                hud.setText("SCORE " + nativeScore() + "  •  RUN COINS " + nativeCoins() + "  •  BEST " + prefs.getInt("best_score", 0));
                finishGameIfNeeded();
                if (inGame) postInvalidateDelayed(16);
            } else canvas.drawColor(screenBg);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (!inGame) return true;
            float x = e.getX() / Math.max(1f, getWidth());
            float y = e.getY() / Math.max(1f, getHeight());
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                if (y < .14f && x > .72f) { showPauseDialog(); return true; }
                nativeTouch(x, y);
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (x > .43f && x < .57f && y > .38f) nativeTouch(x, y);
                return true;
            }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
                nativeTouch(-1f, -1f);
                return true;
            }
            return true;
        }
    }

    private native void nativeRender(android.graphics.Canvas canvas, int width, int height,
        Bitmap player, Bitmap traffic, Bitmap rival, Bitmap police, Bitmap truck, Bitmap coin);
    private native void nativeTouch(float x, float y);
    private native int nativeScore();
    private native int nativeCoins();
    private native boolean nativeGameOver();
    private native void nativePause(boolean paused);
    private native void nativeReset();
    private native void nativeSetUpgrades(int speed, int nitro, int handling);
    private native void nativeSetOptions(boolean effects, boolean leftHanded);
}
