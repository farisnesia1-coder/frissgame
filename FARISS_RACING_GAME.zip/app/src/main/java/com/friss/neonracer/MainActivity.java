package com.friss.neonracer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.HashMap;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

/**
 * FARISS RACING GAME - Android arcade racing prototype.
 * Firebase powers room matchmaking/presence and the global leaderboard.
 * Existing profile, wallet and demo-admin features remain local-only.
 */
public class MainActivity extends Activity {
    static { System.loadLibrary("neonracer"); }

    private static final String ADMIN_PIN = "246810"; // Demo-only gate, not production security.
    private static final String TIKTOK_URL = "https://www.tiktok.com/@frissanjaymabar";
    private static final String INSTAGRAM_URL = "https://www.instagram.com/frisswho?vrfl=M3FqeTRqbDd4dHF4";
    private static final String TELEGRAM_URL = "https://t.me/farisisheree";

    private FrameLayout root;
    private GameView game;
    private TextView hud;
    private Button pauseButton;
    private LinearLayout gameControls;
    private View overlay;
    private View animatedBackdrop;

    // Firebase-backed lobby and leaderboard. Game login/profile remains the existing local prototype.
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private String currentRoomCode = "";
    private String currentRoomHostUid = "";
    private boolean multiplayerRace = false;
    private boolean roomStartHandled = false;
    private float multiplayerLane = 0.50f;
    private long lastMultiplayerWriteMs = 0L;
    private ListenerRegistration roomListener, roomPlayersListener, publicRoomsListener;
    private final Map<String, RemoteRacer> remoteRacers = new LinkedHashMap<>();
    private TextView lobbyRoomsList, roomStatusText, roomCountText, roomRosterText;
    private Button roomStartButton;
    private LinearLayout roomRosterContainer;

    private SharedPreferences globalPrefs, accountsPrefs, prefs;
    private Bitmap[] playerSprites = new Bitmap[4];
    private Bitmap trafficSprite, rivalSprite, policeSprite, truckSprite, coinSprite;

    private boolean inGame = false, gameOverHandled = false, pauseDialogOpen = false;
    private int carStyle, speedLevel, nitroLevel, handlingLevel;
    private boolean effectsOn, leftHanded, musicOn, soundOn;
    private String currentUserId = "", currentUsername = "";

    private MediaPlayer backgroundMusic;
    private int currentTrackRes = 0;
    private SoundPool soundPool;
    private int clickSfx, nitroSfx, coinSfx, crashSfx, engineSfx;
    private int engineStream = 0;
    private boolean nitroSfxPlaying = false;
    private int lastSoundCoinCount = 0;

    private EditText adminIdInput;
    private TextView adminTargetSummary;
    private final int screenBg = Color.rgb(5, 10, 24);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        globalPrefs = getSharedPreferences("fariss_global", MODE_PRIVATE);
        accountsPrefs = getSharedPreferences("fariss_accounts", MODE_PRIVATE);
        prefs = globalPrefs;
        loadSettings();
        loadSprites();
        initSoundPool();
        immersive();

        root = new FrameLayout(this);
        game = new GameView();
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(13);
        hud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hud.setPadding(dp(14), dp(10), dp(64), dp(10));
        hud.setBackground(makeRounded(Color.argb(210, 8, 24, 42), Color.argb(220, 3, 10, 19), dp(14), dp(1)));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        root.addView(hud, hp);
        hud.setVisibility(View.GONE);

        pauseButton = new Button(this);
        pauseButton.setText("Ⅱ");
        pauseButton.setTextSize(16);
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setAllCaps(false);
        pauseButton.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(0, 113, 170)));
        pauseButton.setOnClickListener(v -> { playClick(); showPauseDialog(); });
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(48), Gravity.TOP | Gravity.RIGHT);
        pp.setMargins(0, dp(3), dp(6), 0);
        root.addView(pauseButton, pp);
        pauseButton.setVisibility(View.GONE);

        gameControls = createGameControls();
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM);
        cp.setMargins(dp(8), 0, dp(8), dp(8));
        root.addView(gameControls, cp);
        gameControls.setVisibility(View.GONE);

        setContentView(root);
        applyNativeOptions();

        // Animated startup sequence before routing to login or the main menu.
        showBootScreen(() -> {
            String rememberedId = globalPrefs.getString("active_user_id", "");
            JSONObject remembered = findPlayerById(rememberedId);
            if (remembered != null && !remembered.optBoolean("banned", false)) {
                activateUser(remembered, false);
                showMenu();
            } else {
                globalPrefs.edit().remove("active_user_id").apply();
                currentUserId = "";
                currentUsername = "";
                prefs = globalPrefs;
                showAuthScreen();
            }
        });
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void loadSettings() {
        carStyle = prefs.getInt("car_style", 0);
        speedLevel = prefs.getInt("speed_level", 0);
        nitroLevel = prefs.getInt("nitro_level", 0);
        handlingLevel = prefs.getInt("handling_level", 0);
        effectsOn = prefs.getBoolean("effects_on", true);
        musicOn = prefs.getBoolean("music_on", true);
        soundOn = prefs.getBoolean("sound_on", true);
        leftHanded = prefs.getBoolean("left_handed", false);
    }

    private void loadSprites() {
        playerSprites[0] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player);
        playerSprites[1] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_red);
        playerSprites[2] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_purple);
        playerSprites[3] = BitmapFactory.decodeResource(getResources(), R.drawable.car_player_white);
        trafficSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_traffic);
        rivalSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_rival);
        policeSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_police);
        truckSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_truck);
        coinSprite = BitmapFactory.decodeResource(getResources(), R.drawable.coin_gold);
    }

    private Bitmap currentPlayerSprite() { return playerSprites[Math.max(0, Math.min(3, carStyle))]; }
    private String carName(int id) {
        switch (id % 4) {
            case 1: return "VOLT RS";
            case 2: return "PHANTOM X";
            case 3: return "POLAR GT";
            default: return "NEXUS GT";
        }
    }

    private void initSoundPool() {
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
        clickSfx = soundPool.load(this, R.raw.sfx_click, 1);
        nitroSfx = soundPool.load(this, R.raw.sfx_nitro, 1);
        coinSfx = soundPool.load(this, R.raw.sfx_coin, 1);
        crashSfx = soundPool.load(this, R.raw.sfx_crash, 1);
        engineSfx = soundPool.load(this, R.raw.sfx_engine, 1);
    }
    private void playSfx(int id, float volume) {
        if (soundOn && soundPool != null && id != 0) {
            try { soundPool.play(id, volume, volume, 1, 0, 1f); } catch (Exception ignored) { }
        }
    }
    private void playClick() { playSfx(clickSfx, .65f); }
    private void startEngineSound() {
        if (!soundOn || soundPool == null || engineSfx == 0 || engineStream != 0) return;
        engineStream = soundPool.play(engineSfx, .17f, .17f, 1, -1, 1f);
    }
    private void stopEngineSound() {
        if (soundPool != null && engineStream != 0) {
            try { soundPool.stop(engineStream); } catch (Exception ignored) { }
        }
        engineStream = 0;
    }
    private void stopNitroSound() {
        if (soundPool != null && nitroSfxPlaying) {
            // Nitro is intentionally a one-shot accent rather than an infinite loop.
            nitroSfxPlaying = false;
        }
        nativeNitro(false);
    }

    private void playTrack(int resourceId) {
        if (currentTrackRes == resourceId && backgroundMusic != null) {
            applyMusicSetting();
            return;
        }
        if (backgroundMusic != null) {
            try { backgroundMusic.stop(); } catch (Exception ignored) { }
            backgroundMusic.release();
            backgroundMusic = null;
        }
        currentTrackRes = resourceId;
        try {
            backgroundMusic = MediaPlayer.create(this, resourceId);
            if (backgroundMusic != null) {
                backgroundMusic.setLooping(true);
                backgroundMusic.setVolume(.42f, .42f);
                if (musicOn) backgroundMusic.start();
            }
        } catch (Exception ignored) { backgroundMusic = null; }
    }
    private void applyMusicSetting() {
        if (backgroundMusic == null && currentTrackRes != 0) playTrack(currentTrackRes);
        if (backgroundMusic == null) return;
        try {
            if (musicOn && !backgroundMusic.isPlaying()) backgroundMusic.start();
            else if (!musicOn && backgroundMusic.isPlaying()) backgroundMusic.pause();
        } catch (Exception ignored) { }
    }

    private void applyNativeOptions() {
        nativeSetUpgrades(speedLevel, nitroLevel, handlingLevel);
        nativeSetOptions(effectsOn, leftHanded);
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(size >= 24 ? "sans-serif-black" : "sans-serif-medium", size >= 24 ? Typeface.BOLD : Typeface.NORMAL));
        t.setPadding(dp(8), dp(5), dp(8), dp(5));
        t.setLetterSpacing(size >= 20 ? 0.025f : 0.008f);
        return t;
    }
    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(140, 170, 200));
        e.setHint(hint);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(makeRounded(Color.rgb(14, 29, 48), Color.rgb(9, 18, 31), dp(12), dp(1)));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
    private Button button(String value, Runnable action, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        b.setLetterSpacing(.025f);
        b.setAllCaps(false);
        b.setMinHeight(dp(primary ? 56 : 50));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        b.setElevation(dp(primary ? 7 : 2));
        b.setBackground(makeRounded(primary ? Color.rgb(32, 215, 255) : Color.rgb(25, 43, 65),
                primary ? Color.rgb(34, 91, 230) : Color.rgb(9, 17, 31), dp(17), primary ? dp(1) : dp(1)));
        b.setOnClickListener(v -> { playClick(); action.run(); });
        return b;
    }
    private GradientDrawable makeRounded(int topColor, int bottomColor, int radius, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{topColor, bottomColor});
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, Color.argb(105, 70, 205, 255));
        return d;
    }
    private void addEyebrow(LinearLayout parent, String value) {
        TextView t = text(value, 10, Color.rgb(73, 213, 255));
        t.setLetterSpacing(.16f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(8), 0, dp(3));
        parent.addView(t, p);
    }
    private void addGlassCard(LinearLayout parent, View child) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.setBackground(makeRounded(Color.rgb(16, 33, 56), Color.rgb(8, 17, 32), dp(18), dp(1)));
        card.setElevation(dp(2));
        card.addView(child, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(2), dp(5), dp(2), dp(7));
        parent.addView(card, p);
    }

    private LinearLayout makePanel(String titleText) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(18));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        panel.setBackground(new android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(205, 8, 18, 38), Color.argb(213, 4, 8, 18), Color.argb(222, 3, 7, 15)}));
        if (titleText != null && !titleText.isEmpty()) {
            TextView title = text(titleText, 25, Color.rgb(40, 220, 255));
            LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
            titleP.setMargins(0, 0, 0, dp(10));
            panel.addView(title, titleP);
        }
        return panel;
    }
    private void showOverlay(View v) {
        if (overlay != null) root.removeView(overlay);
        if (animatedBackdrop != null) root.removeView(animatedBackdrop);
        animatedBackdrop = new AnimatedBackdrop();
        root.addView(animatedBackdrop, new FrameLayout.LayoutParams(-1, -1));
        overlay = v;
        v.setAlpha(0f);
        v.setTranslationY(dp(8));
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        v.animate().alpha(1f).translationY(0f).setDuration(260).start();
        hud.setVisibility(View.GONE);
        pauseButton.setVisibility(View.GONE);
        gameControls.setVisibility(View.GONE);
        game.invalidate();
    }

    private void showBootScreen(Runnable whenFinished) {
        LinearLayout splash = makePanel("");
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(22), dp(24), dp(22), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAlpha(.18f);
        logo.setScaleX(.82f);
        logo.setScaleY(.82f);
        LinearLayout.LayoutParams logoP = new LinearLayout.LayoutParams(-1, dp(218));
        logoP.setMargins(dp(4), 0, dp(4), dp(10));
        splash.addView(logo, logoP);

        TextView brand = text("FARISS RACING", 27, Color.WHITE);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(.13f);
        brand.setAlpha(0f);
        splash.addView(brand, new LinearLayout.LayoutParams(-1, -2));

        TextView tagline = text("NEON RACER  /  SEASON 01", 10, Color.rgb(73, 213, 255));
        tagline.setGravity(Gravity.CENTER);
        tagline.setLetterSpacing(.15f);
        LinearLayout.LayoutParams taglineP = new LinearLayout.LayoutParams(-1, -2);
        taglineP.setMargins(0, dp(8), 0, dp(26));
        splash.addView(tagline, taglineP);

        FrameLayout barTrack = new FrameLayout(this);
        barTrack.setBackground(makeRounded(Color.rgb(15, 29, 47), Color.rgb(8, 15, 27), dp(8), dp(1)));
        barTrack.setClipToOutline(true);
        View barFill = new View(this);
        barFill.setBackground(makeRounded(Color.rgb(58, 226, 255), Color.rgb(0, 112, 235), dp(8), 0));
        barFill.setScaleX(.02f);
        barFill.setPivotX(0f);
        barTrack.addView(barFill, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams trackP = new LinearLayout.LayoutParams(-1, dp(8));
        trackP.setMargins(dp(22), 0, dp(22), dp(13));
        splash.addView(barTrack, trackP);

        TextView status = text("INITIALIZING RACE SYSTEMS", 10, Color.rgb(158, 188, 215));
        status.setGravity(Gravity.CENTER);
        status.setLetterSpacing(.12f);
        splash.addView(status, new LinearLayout.LayoutParams(-1, -2));

        showOverlay(splash);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).start();
        brand.animate().alpha(1f).setStartDelay(230).setDuration(500).start();
        barFill.animate().scaleX(1f).setStartDelay(100).setDuration(1250).start();
        status.animate().alpha(.42f).setStartDelay(180).setDuration(430)
                .withEndAction(() -> status.animate().alpha(1f).setDuration(430).start()).start();

        root.postDelayed(() -> {
            if (overlay == splash) {
                removeOverlay();
                whenFinished.run();
            }
        }, 1580);
    }
    private void removeOverlay() {
        if (overlay != null) { root.removeView(overlay); overlay = null; }
        if (animatedBackdrop != null) { root.removeView(animatedBackdrop); animatedBackdrop = null; }
    }
    private void addAction(LinearLayout panel, String label, Runnable action, boolean primary) {
        Button b = button(label, action, primary);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(3), 0, dp(3));
        panel.addView(b, p);
    }
    private void addInput(LinearLayout panel, EditText e) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        panel.addView(e, p);
    }

    // -------------------- Offline account prototype --------------------
    private JSONArray getPlayers() {
        try { return new JSONArray(accountsPrefs.getString("players", "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }
    private void savePlayers(JSONArray players) { accountsPrefs.edit().putString("players", players.toString()).apply(); }
    private JSONObject findPlayerById(String id) {
        if (id == null || id.trim().isEmpty()) return null;
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && p.optString("id").equalsIgnoreCase(id.trim())) return p;
        }
        return null;
    }
    private JSONObject findPlayerByNameOrId(String value) {
        if (value == null) return null;
        String v = value.trim();
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && (p.optString("id").equalsIgnoreCase(v) || p.optString("username").equalsIgnoreCase(v))) return p;
        }
        return null;
    }
    private String passwordHash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((salt + ":" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    private void activateUser(JSONObject player, boolean persistSession) {
        currentUserId = player.optString("id", "");
        currentUsername = player.optString("username", "PLAYER");
        if (persistSession) globalPrefs.edit().putString("active_user_id", currentUserId).apply();
        prefs = getSharedPreferences("player_" + currentUserId, MODE_PRIVATE);
        loadSettings();
        applyNativeOptions();
    }
    private void showAuthScreen() {
        inGame = false;
        stopEngineSound();
        playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("PLAYER LOGIN");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo, new LinearLayout.LayoutParams(-1, dp(170)));
        body.addView(text("LOGIN OR CREATE YOUR RACER ID", 12, Color.LTGRAY));
        EditText username = input("Username or player ID", false);
        EditText password = input("Password", true);
        addInput(body, username); addInput(body, password);
        addAction(body, "LOGIN", () -> doLogin(username.getText().toString(), password.getText().toString()), true);
        addAction(body, "CREATE NEW PLAYER", this::showRegisterScreen, false);
        body.addView(text("Local profile prototype • Online rooms use Firebase", 10, Color.GRAY));
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void showRegisterScreen() {
        LinearLayout panel = makePanel("CREATE PLAYER");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(text("Pick a username. A unique Player ID is generated for you.", 12, Color.LTGRAY));
        EditText username = input("Username (3-16 letters/numbers/._)", false);
        EditText password = input("Password (minimum 6 characters)", true);
        EditText confirm = input("Confirm password", true);
        addInput(body, username); addInput(body, password); addInput(body, confirm);
        addAction(body, "CREATE ACCOUNT", () -> {
            String name = username.getText().toString().trim();
            String pass = password.getText().toString();
            if (!name.matches("[A-Za-z0-9_.]{3,16}")) { alert("Invalid username", "Use 3-16 letters, numbers, underscore or dot."); return; }
            if (pass.length() < 6) { alert("Password too short", "Use at least 6 characters."); return; }
            if (!pass.equals(confirm.getText().toString())) { alert("Password mismatch", "The passwords do not match."); return; }
            if (findPlayerByNameOrId(name) != null) { alert("Username unavailable", "Choose another username."); return; }
            String id = "FRS-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase(Locale.US);
            String salt = UUID.randomUUID().toString();
            JSONObject player = new JSONObject();
            try {
                player.put("id", id); player.put("username", name); player.put("salt", salt);
                player.put("passwordHash", passwordHash(pass, salt)); player.put("banned", false);
                player.put("createdAt", System.currentTimeMillis());
                JSONArray arr = getPlayers(); arr.put(player); savePlayers(arr);
            } catch (JSONException ex) { alert("Account error", "Could not save the account on this device."); return; }
            activateUser(player, true);
            alert("Account created", "Username: " + name + "\nYour Player ID: " + id + "\nSave this ID for reference.");
            showMenu();
        }, true);
        addAction(body, "← BACK TO LOGIN", this::showAuthScreen, false);
        sc.addView(body); panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void doLogin(String usernameOrId, String password) {
        JSONObject player = findPlayerByNameOrId(usernameOrId);
        if (player == null) { alert("Player not found", "Create an account first, or check the username / ID."); return; }
        if (player.optBoolean("banned", false)) { alert("Account banned", "This local player is banned on this device. Contact the local demo administrator."); return; }
        String salt = player.optString("salt", "");
        if (!passwordHash(password, salt).equals(player.optString("passwordHash", ""))) {
            alert("Login failed", "The password is incorrect."); return;
        }
        activateUser(player, true);
        showMenu();
    }
    private void logout() {
        inGame = false; nativePause(true); stopEngineSound(); stopNitroSound();
        currentUserId = ""; currentUsername = "";
        globalPrefs.edit().remove("active_user_id").apply();
        prefs = globalPrefs;
        showAuthScreen();
    }

    // -------------------- Screens --------------------
    private void showMenu() {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        lobbyRoomsList = null;
        inGame = false;
        pauseDialogOpen = false;
        nativeReset(); nativePause(true); stopEngineSound(); stopNitroSound();
        loadSettings(); applyNativeOptions(); playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("");
        panel.setPadding(dp(16), dp(10), dp(16), dp(16));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(2), dp(8), dp(2), dp(12));

        addEyebrow(body, "FARISS MOTORSPORTS   •   SEASON 01");
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer_horizontal);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams heroBanner = new LinearLayout.LayoutParams(-1, dp(126));
        heroBanner.setMargins(dp(2), dp(4), dp(2), dp(3));
        body.addView(logo, heroBanner);
        logo.setOnLongClickListener(v -> { playClick(); askAdminPin(); return true; });

        TextView title = text("NEON RACER", 30, Color.WHITE);
        title.setLetterSpacing(.08f);
        body.addView(title);
        body.addView(text("RACE THE NIGHT. OWN THE ROAD.", 11, Color.rgb(86, 210, 255)));
        body.addView(text("ONLINE LOBBIES  •  GLOBAL RANKINGS  •  NEON STREETS", 9, Color.rgb(170, 198, 224)));

        LinearLayout profile = new LinearLayout(this);
        profile.setOrientation(LinearLayout.VERTICAL);
        profile.setPadding(dp(14), dp(12), dp(14), dp(12));
        profile.setBackground(makeRounded(Color.rgb(19, 42, 69), Color.rgb(8, 19, 34), dp(18), dp(1)));
        TextView player = text("DRIVER  /  " + currentUsername, 16, Color.WHITE);
        player.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        profile.addView(player);
        TextView id = text("PLAYER ID  " + currentUserId, 10, Color.rgb(93, 213, 255));
        id.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        profile.addView(id);
        TextView stats = text("BEST  " + prefs.getInt("best_score", 0) + "     •     WALLET  " + prefs.getInt("bank_coins", 0) + " COINS", 12, Color.rgb(255, 211, 91));
        stats.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        profile.addView(stats);
        LinearLayout.LayoutParams profileP = new LinearLayout.LayoutParams(-1, -2);
        profileP.setMargins(0, dp(14), 0, dp(10));
        body.addView(profile, profileP);

        addEyebrow(body, "QUICK START");
        Button race = button("▶   START RACE", this::startGame, true);
        LinearLayout.LayoutParams raceP = new LinearLayout.LayoutParams(-1, -2);
        raceP.setMargins(0, dp(2), 0, dp(10));
        body.addView(race, raceP);

        addEyebrow(body, "YOUR GARAGE");
        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button garage = button("GARAGE  ›", this::showGarage, false);
        Button upgrades = button("UPGRADES  ↗", this::showUpgrades, false);
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -2, 1);
        half.setMargins(0, 0, dp(5), 0); row1.addView(garage, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -2, 1);
        half2.setMargins(dp(5), 0, 0, 0); row1.addView(upgrades, half2);
        body.addView(row1);

        addEyebrow(body, "ONLINE RACING");
        addAction(body, "✦  MULTIPLAYER LOBBY  •  PUBLIC / PRIVATE", this::showMultiplayerLobby, true);

        addEyebrow(body, "PIT WALL");
        addAction(body, "🏆  GLOBAL TOP DRIVERS", this::showLeaderboard, false);
        addAction(body, "🪙  TOP UP COINS  •  TELEGRAM", this::showTopUp, false);
        addAction(body, "⚙  SETTINGS & AUDIO", this::showSettings, false);
        addAction(body, "✦  DEVELOPER & SOCIALS", this::showDeveloper, false);
        addAction(body, "↪  LOG OUT", this::logout, false);
        body.addView(text("SWIPE LEFT / RIGHT TO STEER  •  SWIPE UP FOR NOS", 9, Color.rgb(115, 145, 174)));
        body.addView(text("ADMIN ACCESS: LONG-PRESS THE LOGO", 9, Color.rgb(63, 94, 126)));

        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }

    private LinearLayout createGameControls() {
        // Guidance-only HUD: actual driving input is gesture-based, not tap steering.
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(12), dp(5), dp(12), dp(5));
        row.setBackground(makeRounded(Color.argb(190, 7, 17, 31), Color.argb(225, 3, 9, 18), dp(18), dp(1)));
        TextView steerHint = text("SWIPE  ←   →  TO STEER", 11, Color.WHITE);
        steerHint.setGravity(Gravity.CENTER);
        row.addView(steerHint, new LinearLayout.LayoutParams(-1, dp(25)));
        TextView boostHint = text("SWIPE UP  ↑  FOR NOS BOOST", 10, Color.rgb(255, 207, 80));
        boostHint.setGravity(Gravity.CENTER);
        row.addView(boostHint, new LinearLayout.LayoutParams(-1, dp(20)));
        return row;
    }

    private void startGame() { startGame(false); }

    private void startGame(boolean onlineRace) {
        if (inGame) return;
        multiplayerRace = onlineRace;
        if (onlineRace) { multiplayerLane = 0.50f; lastMultiplayerWriteMs = 0L; remoteRacers.clear(); }
        inGame = true;
        gameOverHandled = false;
        pauseDialogOpen = false;
        loadSettings();
        applyNativeOptions();
        nativeReset();
        nativePause(true);
        lastSoundCoinCount = 0;
        playTrack(R.raw.racing_music);

        // Cinematic race-entry countdown; controls only activate after GO.
        FrameLayout cover = new FrameLayout(this);
        cover.setBackgroundColor(Color.argb(225, 2, 6, 15));
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(22), dp(20), dp(22), dp(20));

        TextView eyebrow = text(onlineRace ? "ONLINE GRID  /  RACE STARTING" : "PRE-RACE SEQUENCE", 11, Color.rgb(73, 213, 255));
        eyebrow.setGravity(Gravity.CENTER);
        eyebrow.setLetterSpacing(.18f);
        center.addView(eyebrow, new LinearLayout.LayoutParams(-1, -2));

        TextView countdown = text("3", 88, Color.rgb(64, 224, 255));
        countdown.setGravity(Gravity.CENTER);
        countdown.setShadowLayer(dp(20), 0f, 0f, Color.rgb(0, 150, 255));
        LinearLayout.LayoutParams countP = new LinearLayout.LayoutParams(-1, dp(132));
        countP.setMargins(0, dp(8), 0, dp(6));
        center.addView(countdown, countP);

        TextView guide = text("SWIPE  ←  →  TO STEER", 12, Color.WHITE);
        guide.setGravity(Gravity.CENTER);
        guide.setLetterSpacing(.04f);
        center.addView(guide, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("SWIPE UP FOR NOS BOOST", 10, Color.rgb(255, 207, 80));
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.setMargins(0, dp(8), 0, 0);
        center.addView(sub, subP);

        FrameLayout.LayoutParams centerP = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        cover.addView(center, centerP);
        showOverlay(cover);
        animateRaceCountdown(cover, countdown, 0);
    }

    private void animateRaceCountdown(FrameLayout cover, TextView countdown, int index) {
        final String[] stages = {"3", "2", "1", "GO!"};
        if (index >= stages.length) {
            cover.animate().alpha(0f).setDuration(240).withEndAction(() -> {
                if (overlay == cover) removeOverlay();
                nativePause(false);
                hud.setVisibility(View.VISIBLE);
                pauseButton.setVisibility(View.VISIBLE);
                gameControls.setVisibility(View.VISIBLE);
                startEngineSound();
                game.invalidate();
            }).start();
            return;
        }

        countdown.setText(stages[index]);
        countdown.setTextColor(index == 3 ? Color.rgb(255, 207, 80) : Color.rgb(64, 224, 255));
        countdown.setScaleX(.58f);
        countdown.setScaleY(.58f);
        countdown.setAlpha(.12f);
        countdown.animate().alpha(1f).scaleX(1.08f).scaleY(1.08f).setDuration(210)
                .withEndAction(() -> countdown.animate().alpha(.86f).scaleX(1f).scaleY(1f)
                        .setDuration(220).start()).start();
        root.postDelayed(() -> animateRaceCountdown(cover, countdown, index + 1),
                index == 3 ? 420 : 650);
    }
    private void showPauseDialog() {
        if (!inGame || pauseDialogOpen) return;
        pauseDialogOpen = true; nativePause(true); stopNitroSound(); stopEngineSound();
        if (backgroundMusic != null && backgroundMusic.isPlaying()) backgroundMusic.pause();
        new AlertDialog.Builder(this).setTitle("RACE PAUSED").setMessage("Take a break, racer.").setCancelable(false)
            .setPositiveButton("RESUME", (d,w) -> { pauseDialogOpen = false; if (inGame) { nativePause(false); applyMusicSetting(); startEngineSound(); } game.invalidate(); })
            .setNeutralButton("RESTART", (d,w) -> { pauseDialogOpen = false; startGame(); })
            .setNegativeButton("MAIN MENU", (d,w) -> { pauseDialogOpen = false; showMenu(); }).show();
    }
    private void finishGameIfNeeded() {
        if (!inGame || gameOverHandled || !nativeGameOver()) return;
        gameOverHandled = true; inGame = false; playSfx(crashSfx, 1f); stopEngineSound(); stopNitroSound(); playTrack(R.raw.dashboard_music);
        int score = nativeScore(), earned = nativeCoins();
        int best = Math.max(score, prefs.getInt("best_score", 0));
        int bank = prefs.getInt("bank_coins", 0) + earned;
        prefs.edit().putInt("best_score", best).putInt("bank_coins", bank).putInt("last_score", score).apply();
        saveLocalScore(score);
        saveOnlineLeaderboard(score);
        if (multiplayerRace) publishMultiplayerFinish(score);
        hud.setVisibility(View.GONE); pauseButton.setVisibility(View.GONE); gameControls.setVisibility(View.GONE);
        new AlertDialog.Builder(this).setTitle("RACE OVER")
            .setMessage("Player: " + currentUsername + "\nID: " + currentUserId + "\nScore: " + score + "\nBest: " + best + "\nCoins earned: " + earned + "\nWallet: " + bank)
            .setCancelable(false).setPositiveButton("RACE AGAIN", (d,w) -> startGame(multiplayerRace))
            .setNeutralButton("GARAGE", (d,w) -> showGarage()).setNegativeButton("MAIN MENU", (d,w) -> showMenu()).show();
    }
    private void saveLocalScore(int score) {
        String raw = prefs.getString("local_scores", ""); List<Integer> scores = new ArrayList<>();
        if (!raw.isEmpty()) for (String s : raw.split(",")) { try { scores.add(Integer.parseInt(s)); } catch (NumberFormatException ignored) { } }
        scores.add(score); Collections.sort(scores, Collections.reverseOrder()); StringBuilder out = new StringBuilder();
        for (int i=0; i<Math.min(10,scores.size()); i++) { if (i>0) out.append(','); out.append(scores.get(i)); }
        prefs.edit().putString("local_scores", out.toString()).apply();
    }
    private void showGarage() {
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("GARAGE"); panel.addView(text("SELECT YOUR RIDE", 12, Color.WHITE));
        ImageView carPreview = new ImageView(this); carPreview.setImageBitmap(currentPlayerSprite()); carPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        panel.addView(carPreview, new LinearLayout.LayoutParams(dp(120), dp(165)));
        panel.addView(text(carName(carStyle), 22, Color.rgb(80,220,255)));
        panel.addView(text("STYLE " + (carStyle+1) + "/4  •  SPEED " + (6+speedLevel) + "/10", 11, Color.LTGRAY));
        addAction(panel, "NEXT CAR →", () -> { carStyle=(carStyle+1)%4; prefs.edit().putInt("car_style",carStyle).apply(); showGarage(); }, true);
        addAction(panel, "UPGRADE SHOP", this::showUpgrades, false); addAction(panel, "← BACK TO MENU", this::showMenu, false); showOverlay(panel);
    }
    private void showUpgrades() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("UPGRADE SHOP");
        panel.addView(text("WALLET  " + prefs.getInt("bank_coins",0) + " COINS", 14, Color.rgb(255,205,55)));
        panel.addView(text("SPEED • LEVEL " + speedLevel + "/5", 13, Color.WHITE));
        addAction(panel, speedLevel>=5?"SPEED MAX LEVEL":"UPGRADE SPEED • "+upgradeCost(speedLevel), ()->purchaseUpgrade("speed"), true);
        panel.addView(text("NITRO • LEVEL " + nitroLevel + "/5", 13, Color.WHITE));
        addAction(panel, nitroLevel>=5?"NITRO MAX LEVEL":"UPGRADE NITRO • "+upgradeCost(nitroLevel), ()->purchaseUpgrade("nitro"), true);
        panel.addView(text("HANDLING • LEVEL " + handlingLevel + "/5", 13, Color.WHITE));
        addAction(panel, handlingLevel>=5?"HANDLING MAX LEVEL":"UPGRADE HANDLING • "+upgradeCost(handlingLevel), ()->purchaseUpgrade("handling"), true);
        addAction(panel, "COIN TOP-UP VIA TELEGRAM", this::showTopUp, false); addAction(panel, "← BACK TO MENU", this::showMenu, false); showOverlay(panel);
    }
    private int upgradeCost(int level) { return 250 + level*350; }
    private void purchaseUpgrade(String which) {
        int level = which.equals("speed")?speedLevel:which.equals("nitro")?nitroLevel:handlingLevel;
        if(level>=5) return; int cost=upgradeCost(level), bank=prefs.getInt("bank_coins",0);
        if(bank<cost) { alert("NOT ENOUGH COINS", "Need " + cost + " coins. Earn coins from races or order a top-up via Telegram."); return; }
        bank-=cost; if(which.equals("speed")) speedLevel++; else if(which.equals("nitro")) nitroLevel++; else handlingLevel++;
        prefs.edit().putInt("bank_coins",bank).putInt("speed_level",speedLevel).putInt("nitro_level",nitroLevel).putInt("handling_level",handlingLevel).apply();
        applyNativeOptions(); showUpgrades();
    }
    // -------------------- Firebase online services --------------------
    private void ensureOnlineAuth(Runnable onReady) {
        if (firebaseAuth == null || firestore == null) {
            alert("ONLINE SERVICES UNAVAILABLE", "Firebase belum bisa diinisialisasi. Periksa app/google-services.json dan koneksi internet.");
            return;
        }
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            onReady.run();
            return;
        }
        firebaseAuth.signInAnonymously()
            .addOnSuccessListener(result -> onReady.run())
            .addOnFailureListener(error -> alert("ONLINE LOGIN FAILED",
                "Aktifkan Authentication → Sign-in method → Anonymous di Firebase Console, lalu coba lagi.\n\n" + error.getLocalizedMessage()));
    }

    private String firebaseUid() {
        FirebaseUser user = firebaseAuth == null ? null : firebaseAuth.getCurrentUser();
        return user == null ? "" : user.getUid();
    }

    private String newRoomCode() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase(Locale.US);
    }

    private Map<String, Object> onlinePlayerData(String uid, float lane, int score, boolean racing, boolean finished) {
        Map<String, Object> data = new HashMap<>();
        data.put("uid", uid);
        data.put("playerId", currentUserId);
        data.put("username", currentUsername);
        data.put("lane", Math.max(.15f, Math.min(.85f, lane)));
        data.put("score", Math.max(0, score));
        data.put("isRacing", racing);
        data.put("finished", finished);
        data.put("updatedAt", FieldValue.serverTimestamp());
        return data;
    }

    private void showMultiplayerLobby() {
        inGame = false;
        nativePause(true);
        stopEngineSound();
        stopNitroSound();
        ensureOnlineAuth(() -> {
            if (!currentRoomCode.isEmpty()) {
                openRoomScreen(currentRoomCode);
                return;
            }
            renderMultiplayerLobby();
        });
    }

    private void renderMultiplayerLobby() {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        LinearLayout panel = makePanel("ONLINE PIT LANE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(4), dp(2), dp(10));
        body.addView(text("CREATE A ROOM OR JOIN A PUBLIC GRID", 11, Color.rgb(165, 206, 232)));
        body.addView(text("2 drivers needed to start • 4 drivers max • auto-start at 4", 10, Color.rgb(91, 224, 255)));
        addAction(body, "＋  CREATE ROOM", this::showCreateRoomDialog, true);
        addAction(body, "⇥  JOIN WITH ROOM CODE", this::showJoinRoomDialog, false);
        addEyebrow(body, "PUBLIC WAITING ROOMS");
        lobbyRoomsList = new LinearLayout(this);
        lobbyRoomsList.setOrientation(LinearLayout.VERTICAL);
        lobbyRoomsList.addView(text("Searching for rooms…", 12, Color.LTGRAY));
        body.addView(lobbyRoomsList, new LinearLayout.LayoutParams(-1, -2));
        addAction(body, "↻  REFRESH ROOMS", this::listenPublicRooms, false);
        addAction(body, "← BACK TO GARAGE MENU", this::showMenu, false);
        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
        listenPublicRooms();
    }

    private void listenPublicRooms() {
        if (lobbyRoomsList == null || firestore == null) return;
        if (publicRoomsListener != null) publicRoomsListener.remove();
        publicRoomsListener = firestore.collection("rooms").whereEqualTo("visibility", "public").limit(50)
            .addSnapshotListener((snapshot, error) -> {
                if (error != null) {
                    runOnUiThread(() -> {
                        if (lobbyRoomsList != null) {
                            lobbyRoomsList.removeAllViews();
                            lobbyRoomsList.addView(text("Couldn't load rooms. Check Firestore Rules and internet.", 11, Color.rgb(255, 170, 145)));
                        }
                    });
                    return;
                }
                runOnUiThread(() -> {
                    if (lobbyRoomsList == null) return;
                    lobbyRoomsList.removeAllViews();
                    int shown = 0;
                    if (snapshot != null) for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String status = doc.getString("status");
                        List<?> uids = (List<?>) doc.get("memberUids");
                        int count = uids == null ? 0 : uids.size();
                        if (!"waiting".equals(status) || count >= 4) continue;
                        shown++;
                        String code = doc.getId();
                        boolean locked = Boolean.TRUE.equals(doc.getBoolean("passwordRequired"));
                        String host = doc.getString("hostUsername");
                        if (host == null || host.trim().isEmpty()) host = "RACER";
                        LinearLayout cardBody = new LinearLayout(this);
                        cardBody.setOrientation(LinearLayout.VERTICAL);
                        TextView heading = text((locked ? "▣  " : "◉  ") + code + "   •   " + host, 14, Color.WHITE);
                        heading.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        cardBody.addView(heading);
                        TextView meta = text(count + "/4 DRIVERS   •   " + (locked ? "PASSWORD REQUIRED" : "OPEN GRID"), 10, Color.rgb(93, 219, 255));
                        meta.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        cardBody.addView(meta);
                        Button join = button("JOIN ROOM  ›", () -> promptJoinRoom(code), true);
                        cardBody.addView(join);
                        addGlassCard(lobbyRoomsList, cardBody);
                    }
                    if (shown == 0) lobbyRoomsList.addView(text("No public rooms yet. Create one and invite a friend.", 12, Color.LTGRAY));
                });
            });
    }

    private void showCreateRoomDialog() {
        LinearLayout form = new LinearLayout(this);
        form.setPadding(dp(18), dp(8), dp(18), dp(4));
        form.setOrientation(LinearLayout.VERTICAL);
        TextView label = text("VISIBILITY", 11, Color.rgb(73, 213, 255));
        label.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        form.addView(label);
        RadioGroup visibility = new RadioGroup(this);
        visibility.setOrientation(RadioGroup.VERTICAL);
        RadioButton pub = new RadioButton(this);
        pub.setId(301); pub.setText("Public — visible in room list"); pub.setTextColor(Color.WHITE); pub.setButtonTintList(ColorStateList.valueOf(Color.rgb(47, 207, 255))); pub.setChecked(true);
        RadioButton priv = new RadioButton(this);
        priv.setId(302); priv.setText("Private — join by room code only"); priv.setTextColor(Color.WHITE); priv.setButtonTintList(ColorStateList.valueOf(Color.rgb(47, 207, 255)));
        visibility.addView(pub); visibility.addView(priv); form.addView(visibility);
        TextView passLabel = text("PASSWORD (OPTIONAL)", 11, Color.rgb(73, 213, 255));
        passLabel.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        form.addView(passLabel);
        EditText pass = input("Leave blank for no password", true);
        form.addView(pass);
        new AlertDialog.Builder(this).setTitle("CREATE RACE ROOM").setView(form)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CREATE ROOM", (dialog, which) -> {
                String mode = visibility.getCheckedRadioButtonId() == 302 ? "private" : "public";
                String password = pass.getText().toString();
                if (password.length() > 0 && password.length() < 4) {
                    alert("PASSWORD TOO SHORT", "Use at least 4 characters, or leave it blank.");
                    return;
                }
                createOnlineRoom(mode, password);
            }).show();
    }

    private void createOnlineRoom(String visibility, String password) {
        ensureOnlineAuth(() -> {
            String uid = firebaseUid();
            if (uid.isEmpty()) { alert("ONLINE LOGIN FAILED", "No online player session."); return; }
            String code = newRoomCode();
            DocumentReference room = firestore.collection("rooms").document(code);
            Map<String, Object> data = new HashMap<>();
            data.put("roomCode", code);
            data.put("hostUid", uid);
            data.put("hostPlayerId", currentUserId);
            data.put("hostUsername", currentUsername);
            data.put("visibility", visibility);
            data.put("passwordRequired", !password.isEmpty());
            data.put("status", "waiting");
            data.put("maxPlayers", 4);
            data.put("memberUids", java.util.Collections.singletonList(uid));
            data.put("createdAt", FieldValue.serverTimestamp());
            data.put("updatedAt", FieldValue.serverTimestamp());
            room.set(data).addOnSuccessListener(unused -> {
                Task<Void> secretWrite = password.isEmpty()
                    ? Tasks.forResult(null)
                    : room.collection("secret").document("config").set(java.util.Collections.singletonMap("passwordHash", passwordHash(password, code)));
                secretWrite.continueWithTask(task -> {
                    if (!task.isSuccessful()) throw task.getException();
                    Map<String, Object> player = onlinePlayerData(uid, .50f, 0, false, false);
                    player.put("joinedAt", FieldValue.serverTimestamp());
                    return room.collection("players").document(uid).set(player);
                }).addOnSuccessListener(done -> openRoomScreen(code))
                  .addOnFailureListener(error -> alert("ROOM SETUP FAILED", "Room was created but its player record failed. Check Firestore Rules.\n\n" + error.getLocalizedMessage()));
            }).addOnFailureListener(error -> alert("CREATE ROOM FAILED", "Firestore denied the room write or the network is unavailable.\n\n" + error.getLocalizedMessage()));
        });
    }

    private void showJoinRoomDialog() {
        EditText code = input("6-character room code", false);
        new AlertDialog.Builder(this).setTitle("JOIN ROOM").setView(code)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("CONTINUE", (d, w) -> promptJoinRoom(code.getText().toString().trim().toUpperCase(Locale.US))).show();
    }

    private void promptJoinRoom(String roomCode) {
        String code = roomCode == null ? "" : roomCode.trim().toUpperCase(Locale.US);
        if (!code.matches("[A-F0-9]{6}")) { alert("INVALID ROOM CODE", "Enter the 6-character code shown by the room host."); return; }
        ensureOnlineAuth(() -> firestore.collection("rooms").document(code).get()
            .addOnSuccessListener(room -> {
                if (!room.exists()) { alert("ROOM NOT FOUND", "Check the code or ask the host for a new one."); return; }
                if (!"waiting".equals(room.getString("status"))) { alert("RACE ALREADY STARTED", "This room is no longer waiting for players."); return; }
                List<?> members = (List<?>) room.get("memberUids");
                if (members != null && members.size() >= 4) { alert("ROOM FULL", "This room already has four players."); return; }
                String uid = firebaseUid();
                if (members != null && members.contains(uid)) { openRoomScreen(code); return; }
                boolean needsPassword = Boolean.TRUE.equals(room.getBoolean("passwordRequired"));
                if (needsPassword) {
                    EditText password = input("Room password", true);
                    new AlertDialog.Builder(this).setTitle("PRIVATE GRID").setMessage("Enter the room password.").setView(password)
                        .setNegativeButton("CANCEL", null)
                        .setPositiveButton("JOIN", (d, w) -> joinOnlineRoom(code, password.getText().toString())).show();
                } else joinOnlineRoom(code, "");
            })
            .addOnFailureListener(error -> alert("ROOM LOOKUP FAILED", "Check Firestore Rules.\n\n" + error.getLocalizedMessage())));
    }

    private void joinOnlineRoom(String code, String password) {
        String uid = firebaseUid();
        if (uid.isEmpty()) { alert("ONLINE LOGIN FAILED", "No online player session."); return; }
        DocumentReference room = firestore.collection("rooms").document(code);
        Task<Void> proofTask = password.isEmpty() ? Tasks.forResult(null) : room.collection("joinRequests").document(uid)
            .set(new HashMap<String, Object>() {{ put("passwordHash", passwordHash(password, code)); put("requestedAt", FieldValue.serverTimestamp()); }});
        proofTask.addOnFailureListener(error -> alert("ROOM PASSWORD / RULES ERROR", "Password incorrect, or your Firestore Rules do not yet validate private-room join requests.\n\n" + error.getLocalizedMessage()));
        proofTask.addOnSuccessListener(ignored -> firestore.runTransaction(transaction -> {
            DocumentSnapshot snap = transaction.get(room);
            if (!snap.exists()) throw new IllegalStateException("Room not found.");
            if (!"waiting".equals(snap.getString("status"))) throw new IllegalStateException("Race already started.");
            List<String> ids = (List<String>) snap.get("memberUids");
            if (ids == null) ids = new ArrayList<>();
            if (ids.contains(uid)) return true;
            if (ids.size() >= 4) throw new IllegalStateException("Room is full (4/4).");
            transaction.update(room, "memberUids", FieldValue.arrayUnion(uid), "updatedAt", FieldValue.serverTimestamp());
            return true;
        }).addOnSuccessListener(ok -> {
            Map<String, Object> player = onlinePlayerData(uid, .50f, 0, false, false);
            player.put("joinedAt", FieldValue.serverTimestamp());
            room.collection("players").document(uid).set(player).addOnSuccessListener(done -> {
                room.collection("joinRequests").document(uid).delete();
                openRoomScreen(code);
            }).addOnFailureListener(error -> alert("JOIN FAILED", "Room member list updated but player setup failed. Check Firestore Rules.\n\n" + error.getLocalizedMessage()));
        }).addOnFailureListener(error -> alert("JOIN FAILED", "Could not join. The room may be full, started, or Firestore Rules need updating.\n\n" + error.getLocalizedMessage())));
    }

    private void openRoomScreen(String code) {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        if (roomListener != null) { roomListener.remove(); roomListener = null; }
        if (roomPlayersListener != null) { roomPlayersListener.remove(); roomPlayersListener = null; }
        currentRoomCode = code;
        roomStartHandled = false;
        remoteRacers.clear();
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("RACE ROOM");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(5), dp(2), dp(10));
        body.addView(text("ROOM CODE", 10, Color.rgb(73, 213, 255)));
        TextView codeView = text(code, 38, Color.WHITE);
        codeView.setLetterSpacing(.22f);
        body.addView(codeView);
        Button copyCode = button("SHARE ROOM CODE", () -> {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.setPrimaryClip(android.content.ClipData.newPlainText("FARISS room code", code));
            alert("ROOM CODE COPIED", "Share " + code + " with your friend.");
        }, false);
        body.addView(copyCode);
        roomStatusText = text("CONNECTING TO ROOM…", 12, Color.rgb(255, 215, 100));
        body.addView(roomStatusText);
        roomCountText = text("DRIVERS  1/4", 13, Color.rgb(73, 213, 255));
        body.addView(roomCountText);
        addEyebrow(body, "DRIVER GRID");
        roomRosterText = text("Loading players…", 12, Color.WHITE);
        roomRosterText.setGravity(Gravity.TOP | Gravity.LEFT);
        roomRosterText.setPadding(dp(12), dp(12), dp(12), dp(12));
        roomRosterText.setBackground(makeRounded(Color.argb(180, 7, 19, 33), Color.argb(175, 6, 12, 24), dp(14), dp(1)));
        body.addView(roomRosterText, new LinearLayout.LayoutParams(-1, -2));
        roomStartButton = button("START RACE  •  NEED 2 PLAYERS", this::startRoomRace, true);
        roomStartButton.setEnabled(false);
        body.addView(roomStartButton);
        body.addView(text("The host can start with 2–3 drivers. At 4/4, the host starts automatically.", 10, Color.LTGRAY));
        addAction(body, "LEAVE / CLOSE ROOM", this::leaveCurrentRoom, false);
        addAction(body, "← BACK TO MENU", this::showMenu, false);
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);

        DocumentReference ref = firestore.collection("rooms").document(code);
        roomListener = ref.addSnapshotListener((snap, error) -> {
            if (error != null) { runOnUiThread(() -> { if (roomStatusText != null) roomStatusText.setText("ROOM CONNECTION ERROR"); }); return; }
            if (snap == null || !snap.exists()) {
                runOnUiThread(() -> {
                    if (code.equals(currentRoomCode)) {
                        cleanupRoomListeners(); currentRoomCode = ""; currentRoomHostUid = "";
                        alert("ROOM CLOSED", "The host closed this room or it no longer exists.");
                        renderMultiplayerLobby();
                    }
                });
                return;
            }
            String hostUid = snap.getString("hostUid");
            String status = snap.getString("status");
            List<?> ids = (List<?>) snap.get("memberUids");
            int count = ids == null ? 0 : ids.size();
            boolean host = firebaseUid().equals(hostUid);
            runOnUiThread(() -> {
                if (!code.equals(currentRoomCode)) return;
                currentRoomHostUid = hostUid == null ? "" : hostUid;
                if (roomStatusText != null) roomStatusText.setText("STATUS  /  " + String.valueOf(status).toUpperCase(Locale.US) + (host ? "  •  HOST" : "  •  DRIVER"));
                if (roomCountText != null) roomCountText.setText("DRIVERS  " + count + "/4  •  " + (count >= 2 ? "READY TO START" : "WAITING FOR 1 MORE"));
                if (roomStartButton != null) {
                    roomStartButton.setEnabled(host && count >= 2 && "waiting".equals(status));
                    roomStartButton.setText(count >= 2 ? "START RACE  •  " + count + " DRIVERS" : "START RACE  •  NEED 2 PLAYERS");
                }
                if (host && count >= 4 && "waiting".equals(status) && !roomStartHandled) startRoomRace();
                if ("racing".equals(status) && !roomStartHandled) {
                    roomStartHandled = true;
                    startGame(true);
                }
                if ("completed".equals(status) && !inGame && roomStatusText != null) roomStatusText.setText("RACE COMPLETED  •  LEAVE OR RETURN TO MENU");
            });
        });
        roomPlayersListener = ref.collection("players").addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null) return;
            List<RemoteRacer> seen = new ArrayList<>();
            StringBuilder lines = new StringBuilder();
            int index = 1;
            for (QueryDocumentSnapshot doc : snapshot) {
                String uid = doc.getId();
                String name = doc.getString("username");
                if (name == null || name.trim().isEmpty()) name = "RACER";
                String id = doc.getString("playerId");
                Long scv = doc.getLong("score");
                Double ln = doc.getDouble("lane");
                Boolean racing = doc.getBoolean("isRacing");
                Boolean finished = doc.getBoolean("finished");
                RemoteRacer r = new RemoteRacer(uid, name, id == null ? "" : id, ln == null ? .5f : ln.floatValue(), scv == null ? 0 : scv.intValue(), Boolean.TRUE.equals(racing), Boolean.TRUE.equals(finished));
                seen.add(r);
                lines.append(index++).append(".  ").append(name).append(uid.equals(firebaseUid()) ? "  (YOU)" : "")
                    .append("\n    ").append(id == null ? "ONLINE DRIVER" : id)
                    .append("  •  ").append(r.finished ? "FINISHED" : r.isRacing ? "RACING" : "READY").append("\n");
            }
            synchronized (remoteRacers) {
                remoteRacers.clear();
                for (RemoteRacer r : seen) remoteRacers.put(r.uid, r);
            }
            String roster = lines.length() == 0 ? "No players connected yet." : lines.toString();
            runOnUiThread(() -> {
                if (code.equals(currentRoomCode) && roomRosterText != null) roomRosterText.setText(roster);
                if (game != null) game.invalidate();
            });
        });
    }

    private void startRoomRace() {
        if (currentRoomCode.isEmpty() || firebaseUid().isEmpty()) return;
        DocumentReference room = firestore.collection("rooms").document(currentRoomCode);
        firestore.runTransaction(transaction -> {
            DocumentSnapshot snap = transaction.get(room);
            if (!snap.exists()) throw new IllegalStateException("Room no longer exists.");
            if (!firebaseUid().equals(snap.getString("hostUid"))) throw new IllegalStateException("Only the room host can start the race.");
            if (!"waiting".equals(snap.getString("status"))) return false;
            List<?> ids = (List<?>) snap.get("memberUids");
            if (ids == null || ids.size() < 2) throw new IllegalStateException("At least 2 players are required.");
            transaction.update(room, "status", "racing", "startedAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp());
            return true;
        }).addOnSuccessListener(started -> {
            if (Boolean.TRUE.equals(started) && !roomStartHandled) {
                roomStartHandled = true;
                startGame(true);
            }
        }).addOnFailureListener(error -> alert("CAN'T START RACE", error.getLocalizedMessage() == null ? "Check room members and Firestore Rules." : error.getLocalizedMessage()));
    }

    private void leaveCurrentRoom() {
        String code = currentRoomCode;
        String uid = firebaseUid();
        if (code.isEmpty() || uid.isEmpty()) { cleanupRoomListeners(); currentRoomCode = ""; showMultiplayerLobby(); return; }
        DocumentReference room = firestore.collection("rooms").document(code);
        room.get().addOnSuccessListener(doc -> {
            if (!doc.exists()) { finishLeaveRoom(); return; }
            String host = doc.getString("hostUid");
            if (uid.equals(host)) {
                room.collection("players").get().addOnSuccessListener(players -> {
                    List<Task<?>> tasks = new ArrayList<>();
                    for (DocumentSnapshot player : players.getDocuments()) tasks.add(player.getReference().delete());
                    tasks.add(room.collection("secret").document("config").delete());
                    Tasks.whenAllComplete(tasks).addOnCompleteListener(done -> room.delete().addOnCompleteListener(deleted -> finishLeaveRoom()));
                }).addOnFailureListener(error -> alert("CLOSE ROOM FAILED", error.getLocalizedMessage()));
            } else {
                room.update("memberUids", FieldValue.arrayRemove(uid), "updatedAt", FieldValue.serverTimestamp())
                    .addOnSuccessListener(done -> room.collection("players").document(uid).delete().addOnCompleteListener(ignored ->
                        room.collection("joinRequests").document(uid).delete().addOnCompleteListener(ignored2 -> finishLeaveRoom())))
                    .addOnFailureListener(error -> alert("LEAVE ROOM FAILED", "The room may already be closed or Firestore Rules need updating.\n\n" + error.getLocalizedMessage()));
            }
        }).addOnFailureListener(error -> alert("LEAVE ROOM FAILED", error.getLocalizedMessage()));
    }

    private void finishLeaveRoom() {
        cleanupRoomListeners();
        currentRoomCode = "";
        currentRoomHostUid = "";
        multiplayerRace = false;
        roomStartHandled = false;
        remoteRacers.clear();
        roomRosterText = null; roomCountText = null; roomStatusText = null; roomStartButton = null;
        lobbyRoomsList = null;
        showMultiplayerLobby();
    }

    private void cleanupRoomListeners() {
        if (roomListener != null) { roomListener.remove(); roomListener = null; }
        if (roomPlayersListener != null) { roomPlayersListener.remove(); roomPlayersListener = null; }
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
    }

    private void publishMultiplayerState(boolean finished) {
        if (!multiplayerRace || currentRoomCode.isEmpty() || firebaseUid().isEmpty()) return;
        long now = System.currentTimeMillis();
        if (!finished && now - lastMultiplayerWriteMs < 650) return;
        lastMultiplayerWriteMs = now;
        Map<String, Object> data = onlinePlayerData(firebaseUid(), multiplayerLane, nativeScore(), inGame && !finished, finished);
        firestore.collection("rooms").document(currentRoomCode).collection("players").document(firebaseUid()).set(data, SetOptions.merge())
            .addOnFailureListener(error -> android.util.Log.w("FRISS-MULTIPLAYER", "Presence update failed: " + error.getMessage()));
    }

    private void publishMultiplayerFinish(int score) {
        publishMultiplayerState(true);
        if (!currentRoomCode.isEmpty() && firebaseUid().equals(currentRoomHostUid)) {
            firestore.collection("rooms").document(currentRoomCode).update("status", "completed", "updatedAt", FieldValue.serverTimestamp())
                .addOnFailureListener(error -> android.util.Log.w("FRISS-MULTIPLAYER", "Room completion update failed: " + error.getMessage()));
        }
    }

    private void drawRemoteRacers(Canvas canvas, int width, int height) {
        List<RemoteRacer> racers;
        synchronized (remoteRacers) { racers = new ArrayList<>(remoteRacers.values()); }
        int localScore = nativeScore();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        int drawn = 0;
        for (RemoteRacer racer : racers) {
            if (racer.uid.equals(firebaseUid()) || drawn >= 3) continue;
            float delta = Math.max(-900f, Math.min(900f, racer.score - localScore));
            float y = height * (0.605f - delta / 900f * 0.055f);
            float x = width * (0.145f + 0.71f * Math.max(.15f, Math.min(.85f, racer.lane)));
            float carW = width * .095f, carH = height * .115f;
            if (rivalSprite != null) canvas.drawBitmap(rivalSprite, null,
                new android.graphics.RectF(x - carW / 2f, y, x + carW / 2f, y + carH), paint);
            paint.setColor(Color.rgb(90, 225, 255));
            paint.setTextSize(dp(10));
            paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            canvas.drawText(racer.username.toUpperCase(Locale.US), x, y - dp(5), paint);
            paint.setColor(Color.WHITE);
            drawn++;
        }
    }

    private void saveOnlineLeaderboard(int score) {
        ensureOnlineAuth(() -> {
            String uid = firebaseUid();
            if (uid.isEmpty()) return;
            DocumentReference ref = firestore.collection("leaderboard").document(uid);
            firestore.runTransaction(transaction -> {
                DocumentSnapshot snap = transaction.get(ref);
                long oldScore = snap.exists() && snap.getLong("bestScore") != null ? snap.getLong("bestScore") : 0L;
                Map<String, Object> data = new HashMap<>();
                data.put("uid", uid);
                data.put("playerId", currentUserId);
                data.put("username", currentUsername);
                data.put("bestScore", Math.max(oldScore, Math.max(0, score)));
                data.put("lastScore", Math.max(0, score));
                data.put("updatedAt", FieldValue.serverTimestamp());
                transaction.set(ref, data, SetOptions.merge());
                return null;
            }).addOnFailureListener(error -> android.util.Log.w("FRISS-LEADERBOARD", "Save failed: " + error.getMessage()));
        });
    }

    private void loadGlobalLeaderboard(LinearLayout entries, TextView status) {
        entries.removeAllViews();
        status.setText("CONNECTING TO GLOBAL LEADERBOARD…");
        ensureOnlineAuth(() -> firestore.collection("leaderboard")
            .orderBy("bestScore", Query.Direction.DESCENDING).limit(50).get()
            .addOnSuccessListener(snapshot -> {
                entries.removeAllViews();
                if (snapshot.isEmpty()) {
                    status.setText("NO SCORES YET  •  BE THE FIRST DRIVER");
                    return;
                }
                status.setText("GLOBAL TOP " + snapshot.size() + " DRIVERS  •  LIVE FIRESTORE DATA");
                int rank = 1;
                for (QueryDocumentSnapshot doc : snapshot) {
                    String name = doc.getString("username"); if (name == null || name.isEmpty()) name = "DRIVER";
                    Long best = doc.getLong("bestScore");
                    String playerId = doc.getString("playerId");
                    LinearLayout row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(dp(12), dp(8), dp(12), dp(8));
                    TextView title = text(String.format(Locale.US, "%02d   %s", rank, name.toUpperCase(Locale.US)), 14,
                        rank == 1 ? Color.rgb(255, 214, 92) : rank <= 3 ? Color.rgb(89, 221, 255) : Color.WHITE);
                    title.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                    row.addView(title);
                    TextView meta = text("BEST SCORE  " + (best == null ? 0 : best) + "   •   " + (playerId == null ? "ONLINE DRIVER" : playerId), 9, Color.rgb(154, 183, 207));
                    meta.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                    row.addView(meta);
                    addGlassCard(entries, row);
                    rank++;
                }
            })
            .addOnFailureListener(error -> {
                status.setText("GLOBAL BOARD UNAVAILABLE  •  CHECK FIRESTORE RULES");
                entries.removeAllViews();
                entries.addView(text("GLOBAL BOARD UNAVAILABLE — LOCAL HISTORY BELOW", 11, Color.rgb(255, 170, 145)));
                String localRaw = prefs.getString("local_scores", "");
                if (localRaw.isEmpty()) {
                    entries.addView(text("No local races recorded yet.", 11, Color.LTGRAY));
                } else {
                    String[] localScores = localRaw.split(",");
                    for (int i = 0; i < localScores.length; i++) {
                        TextView localRow = text(String.format(Locale.US, "%02d   %s   •   %s", i + 1, currentUsername, localScores[i]), 12, i == 0 ? Color.rgb(255, 214, 92) : Color.WHITE);
                        localRow.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        entries.addView(localRow);
                    }
                }
                entries.addView(text("Online scores are saved once Firebase Anonymous sign-in and Firestore Rules are configured.\n" + error.getLocalizedMessage(), 10, Color.rgb(154, 183, 207)));
            }));
    }

    private void showLeaderboard() {
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("GLOBAL TOP DRIVERS");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(5), dp(2), dp(12));
        TextView status = text("CONNECTING TO GLOBAL LEADERBOARD…", 10, Color.rgb(73, 213, 255));
        body.addView(status);
        LinearLayout entries = new LinearLayout(this);
        entries.setOrientation(LinearLayout.VERTICAL);
        body.addView(entries);
        addAction(body, "↻  REFRESH GLOBAL RANKINGS", () -> loadGlobalLeaderboard(entries, status), false);
        addAction(body, "← BACK TO MENU", this::showMenu, true);
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
        loadGlobalLeaderboard(entries, status);
    }

    private void showTopUp() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("COIN TOP-UP");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(text("MANUAL TOP-UP • TELEGRAM CHAT",12,Color.rgb(75,220,255)));
        body.addView(text("PLAYER  "+currentUsername,13,Color.WHITE));
        body.addView(text("PLAYER ID  "+currentUserId,12,Color.rgb(150,210,240)));
        body.addView(text("CURRENT WALLET  "+prefs.getInt("bank_coins",0)+" COINS",15,Color.rgb(255,205,55)));
        body.addView(text("Pilih paket untuk mengirim pesanan ke chat FRISS. Harga dan cara pembayaran dikonfirmasi admin lewat Telegram.",11,Color.LTGRAY));
        addAction(body,"ORDER VIA TELEGRAM • 500 COINS",()->sendTelegramTopupOrder(500),true);
        addAction(body,"ORDER VIA TELEGRAM • 1,500 COINS",()->sendTelegramTopupOrder(1500),true);
        addAction(body,"ORDER VIA TELEGRAM • 5,000 COINS",()->sendTelegramTopupOrder(5000),true);
        body.addView(text("Koin belum otomatis bertambah setelah membuka chat. Admin harus mengecek pembayaran dan mengkreditkan koin.",10,Color.GRAY));
        addAction(body,"← BACK TO MENU",this::showMenu,false);
        sc.addView(body); panel.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }

    private void sendTelegramTopupOrder(int coinAmount) {
        String message = "Halo FRISS! Saya mau top up FARISS RACING GAME.\n"
            + "Username: " + currentUsername + "\n"
            + "Player ID: " + currentUserId + "\n"
            + "Paket: " + String.format(Locale.US, "%,d", coinAmount) + " koin\n"
            + "Status: belum membayar\n"
            + "Mohon konfirmasi harga dan metode pembayaran sebelum saya membayar.";
        openExternal(TELEGRAM_URL + "?text=" + Uri.encode(message));
    }

    // -------------------- Local demo administration --------------------
    private void askAdminPin() {
        EditText pin = input("Admin PIN", true); pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("ADMIN ACCESS • LOCAL DEMO").setMessage("PIN demo: akses ini hanya mengelola data yang tersimpan di perangkat ini.")
            .setView(pin).setNegativeButton("CANCEL", null).setPositiveButton("OPEN", (d,w)->{
                if (ADMIN_PIN.equals(pin.getText().toString())) showAdminDashboard();
                else alert("ACCESS DENIED", "Incorrect demo PIN.");
            }).show();
    }
    private void showAdminDashboard() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("ADMIN DASHBOARD");
        panel.addView(text("LOCAL DEVICE ONLY • NOT SHARED ONLINE",11,Color.rgb(255,205,55)));
        panel.addView(text("Manage registered local Player IDs",11,Color.LTGRAY));
        adminIdInput=input("Enter Player ID (FRS-XXXXXXXX)",false); addInput(panel,adminIdInput);
        adminTargetSummary=text("No player selected",12,Color.WHITE); panel.addView(adminTargetSummary);
        addAction(panel,"LOOKUP PLAYER ID",this::lookupAdminTarget,true);
        addAction(panel,"BAN PLAYER",()->changeBanState(true),false);
        addAction(panel,"UNBAN PLAYER",()->changeBanState(false),false);
        addAction(panel,"ADD CUSTOM COINS TO PLAYER ID",this::askAdminCreditAmount,true);
        addAction(panel,"← BACK TO MENU",this::showMenu,false);
        showOverlay(panel);
    }
    private String adminTypedId() { return adminIdInput==null?"":adminIdInput.getText().toString().trim().toUpperCase(Locale.US); }
    private void lookupAdminTarget() {
        String id=adminTypedId(); JSONObject p=findPlayerById(id);
        if(p==null) { adminTargetSummary.setText("Player ID not found on this device."); return; }
        adminTargetSummary.setText("Username: "+p.optString("username")+"\nID: "+p.optString("id")+"\nStatus: "+(p.optBoolean("banned")?"BANNED":"ACTIVE")+"\nWallet: "+getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE).getInt("bank_coins",0)+" coins");
    }
    private void changeBanState(boolean ban) {
        String id=adminTypedId(); JSONArray players=getPlayers(); boolean found=false; String name="";
        for(int i=0;i<players.length();i++){ JSONObject p=players.optJSONObject(i); if(p!=null&&p.optString("id").equalsIgnoreCase(id)){ try{p.put("banned",ban);name=p.optString("username");found=true;}catch(JSONException ignored){} break; } }
        if(!found){adminTargetSummary.setText("Player ID not found. Look up an ID first.");return;}
        savePlayers(players); lookupAdminTarget();
        alert("PLAYER UPDATED",name+" has been "+(ban?"banned":"unbanned")+" in this device's local demo database.");
    }
    private void askAdminCreditAmount() {
        String id=adminTypedId();
        JSONObject p=findPlayerById(id);
        if(p==null){adminTargetSummary.setText("Player ID not found on this device. This dashboard cannot manage accounts on other devices.");return;}
        EditText amountInput=input("Coins to add (e.g. 1000)",false);
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        new AlertDialog.Builder(this).setTitle("CREDIT PLAYER WALLET")
            .setMessage("Only credit coins after confirming the payment was received. This change applies only on this device.")
            .setView(amountInput).setNegativeButton("CANCEL",null).setPositiveButton("ADD COINS",(d,w)->{
                String raw=amountInput.getText().toString().trim();
                int amount;
                try { amount=Integer.parseInt(raw); } catch(Exception ex) { alert("INVALID AMOUNT","Enter a whole number greater than zero."); return; }
                if(amount<=0 || amount>10000000){alert("INVALID AMOUNT","Enter an amount from 1 to 10,000,000 coins.");return;}
                creditPlayerLocally(p,amount);
            }).show();
    }
    private void creditPlayerLocally(JSONObject p, int amount) {
        SharedPreferences target=getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE);
        int oldCoins=target.getInt("bank_coins",0);
        if(Integer.MAX_VALUE-oldCoins<amount){alert("WALLET LIMIT","This amount exceeds the wallet limit.");return;}
        target.edit().putInt("bank_coins",oldCoins+amount).putInt("admin_credit_count",target.getInt("admin_credit_count",0)+1)
            .putString("last_admin_credit",System.currentTimeMillis()+":"+amount).apply();
        lookupAdminTarget();
        alert("LOCAL CREDIT ADDED","+"+String.format(Locale.US,"%,d",amount)+" coins granted to "+p.optString("username")+" ("+p.optString("id")+").\n\nReminder: this prototype stores player data on this device only.");
    }

    private void showDeveloper() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel(""); panel.setBackgroundColor(Color.BLACK);
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(12),dp(18),dp(12),dp(18));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_neon_racer); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout nameRow=new LinearLayout(this); nameRow.setGravity(Gravity.CENTER); nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.addView(text("FARIS",34,Color.WHITE)); nameRow.addView(text(" ✓ ",22,Color.rgb(70,145,255))); body.addView(nameRow);
        body.addView(text("NEON RACER • DEVELOPER",12,Color.LTGRAY));
        LinearLayout.LayoutParams contactP=new LinearLayout.LayoutParams(-1,-2); contactP.setMargins(0,dp(20),0,dp(6)); body.addView(text("SOCIALS:",14,Color.WHITE),contactP);
        addAction(body,"♪  TIKTOK  •  @frissanjaymabar",()->openExternal(TIKTOK_URL),false);
        addAction(body,"◎  INSTAGRAM  •  @frisswho",()->openExternal(INSTAGRAM_URL),false);
        addAction(body,"➤  TELEGRAM  •  @farisisheree",()->openExternal(TELEGRAM_URL),false);
        addAction(body,"← BACK TO MENU",this::showMenu,true);
        scroll.addView(body); panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }
    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { alert("Cannot open link",url); }
    }
    private void showSettings() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("SETTINGS & AUDIO");
        panel.addView(text("BACKGROUND MUSIC",13,Color.WHITE));
        addAction(panel,"MUSIC: "+(musicOn?"ON":"OFF"),()->{musicOn=!musicOn;prefs.edit().putBoolean("music_on",musicOn).apply();applyMusicSetting();showSettings();},true);
        panel.addView(text("SOUND EFFECTS • CLICK / NOS / COIN / CRASH / ENGINE",10,Color.LTGRAY));
        addAction(panel,"SOUND FX: "+(soundOn?"ON":"OFF"),()->{soundOn=!soundOn;prefs.edit().putBoolean("sound_on",soundOn).apply();if(!soundOn)stopEngineSound();else if(inGame)startEngineSound();showSettings();},true);
        panel.addView(text("VISUAL EFFECTS",13,Color.WHITE));
        addAction(panel,"EFFECTS: "+(effectsOn?"ON":"OFF"),()->{effectsOn=!effectsOn;prefs.edit().putBoolean("effects_on",effectsOn).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();},true);
        panel.addView(text("CONTROL LAYOUT",13,Color.WHITE));
        addAction(panel,"LEFT-HANDED: "+(leftHanded?"ON":"OFF"),()->{leftHanded=!leftHanded;prefs.edit().putBoolean("left_handed",leftHanded).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();},true);
        panel.addView(text("Original procedural electronic soundtrack • offline",10,Color.GRAY)); addAction(panel,"← BACK TO MENU",this::showMenu,false); showOverlay(panel);
    }

    private void alert(String title,String message) { new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",null).show(); }

    @Override protected void onPause() {
        super.onPause(); if(game!=null&&inGame)nativePause(true); stopEngineSound(); stopNitroSound();
        if(backgroundMusic!=null&&backgroundMusic.isPlaying())backgroundMusic.pause();
    }
    @Override protected void onResume() {
        super.onResume(); immersive(); if(game!=null&&inGame&&!pauseDialogOpen){nativePause(false);startEngineSound();} applyMusicSetting();
    }
    @Override protected void onDestroy() {
        cleanupRoomListeners();
        if(backgroundMusic!=null){try{backgroundMusic.stop();}catch(Exception ignored){}backgroundMusic.release();backgroundMusic=null;}
        if(soundPool!=null){soundPool.release();soundPool=null;} super.onDestroy();
    }

    private static class RemoteRacer {
        final String uid, username, playerId;
        final float lane;
        final int score;
        final boolean isRacing, finished;
        RemoteRacer(String uid, String username, String playerId, float lane, int score, boolean isRacing, boolean finished) {
            this.uid = uid; this.username = username; this.playerId = playerId; this.lane = lane;
            this.score = score; this.isRacing = isRacing; this.finished = finished;
        }
    }

    private class AnimatedBackdrop extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private long bornAt = System.currentTimeMillis();
        AnimatedBackdrop() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_HARDWARE, null); setClickable(false); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            canvas.drawColor(Color.rgb(3, 8, 20));
            float phase = ((System.currentTimeMillis() - bornAt) % 9000L) / 9000f;
            float x1 = w * (.12f + .76f * phase);
            float y1 = h * (.18f + .10f * (float)Math.sin(phase * Math.PI * 2));
            paint.setShader(new RadialGradient(x1, y1, Math.max(w, h) * .58f,
                new int[]{Color.argb(58, 0, 180, 255), Color.argb(0, 0, 180, 255)}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(new RadialGradient(w * (.78f - .35f * phase), h * .78f, Math.max(w, h) * .48f,
                new int[]{Color.argb(42, 111, 53, 255), Color.argb(0, 111, 53, 255)}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            paint.setStrokeWidth(dp(1));
            paint.setColor(Color.argb(24, 89, 218, 255));
            float scan = (phase * h * 1.45f) % h;
            canvas.drawLine(0, scan, w, scan, paint);
            paint.setStrokeWidth(dp(2));
            paint.setColor(Color.argb(35, 50, 208, 255));
            for (int i = -2; i < 5; i++) {
                float xx = (i * w * .31f + phase * w * .45f) % (w + 1);
                canvas.drawLine(xx, 0, xx - w * .25f, h, paint);
            }
            paint.setColor(Color.argb(12, 255, 255, 255));
            paint.setStrokeWidth(dp(1));
            for (int y = dp(24); y < h; y += dp(38)) canvas.drawLine(0, y, w, y, paint);
            postInvalidateDelayed(40);
        }
    }

    private class GameView extends View {
        private float downX, downY, lastSteerX;
        private boolean swipeActive, nosTriggered;
        GameView(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_HARDWARE,null);}
        @Override protected void onDraw(android.graphics.Canvas canvas){
            super.onDraw(canvas);
            if(inGame){
                nativeRender(canvas,getWidth(),getHeight(),currentPlayerSprite(),trafficSprite,rivalSprite,policeSprite,truckSprite,coinSprite);
                if (multiplayerRace) { drawRemoteRacers(canvas, getWidth(), getHeight()); publishMultiplayerState(false); }
                int coins=nativeCoins(); if(coins>lastSoundCoinCount){playSfx(coinSfx,.85f);lastSoundCoinCount=coins;}
                hud.setText(currentUsername+"  •  SCORE "+nativeScore()+"  •  COINS "+coins+"  •  BEST "+prefs.getInt("best_score",0));
                finishGameIfNeeded(); if(inGame)postInvalidateDelayed(16);
            } else canvas.drawColor(screenBg);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(!inGame)return true;
            float x=e.getX(), y=e.getY();
            float nx=x/Math.max(1f,getWidth()), ny=y/Math.max(1f,getHeight());
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:
                    if(ny<.14f&&nx>.72f){showPauseDialog();return true;}
                    downX=x; downY=y; lastSteerX=x; swipeActive=true; nosTriggered=false;
                    nativeTouch(nx,ny);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!swipeActive)return true;
                    float dx=x-lastSteerX;
                    float threshold=dp(22);
                    if(Math.abs(dx)>=threshold){
                        int direction = dx<0?-1:1;
                        nativeSteer(direction);
                        multiplayerLane = Math.max(.22f, Math.min(.78f, multiplayerLane + direction * .09f));
                        lastSteerX=x;
                    }
                    if(!nosTriggered && downY-y>dp(52)){
                        nativeNitro(true); playSfx(nitroSfx,.95f); nosTriggered=true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    swipeActive=false; nativeTouch(-1f,-1f); nativeNitro(false);
                    return true;
            }
            return true;
        }
    }

    private native void nativeRender(android.graphics.Canvas canvas,int width,int height,Bitmap player,Bitmap traffic,Bitmap rival,Bitmap police,Bitmap truck,Bitmap coin);
    private native void nativeTouch(float x,float y);
    private native void nativeSteer(int direction);
    private native void nativeNitro(boolean down);
    private native int nativeScore();
    private native int nativeCoins();
    private native boolean nativeGameOver();
    private native void nativePause(boolean paused);
    private native void nativeReset();
    private native void nativeSetUpgrades(int speed,int nitro,int handling);
    private native void nativeSetOptions(boolean effects,boolean leftHanded);
}
