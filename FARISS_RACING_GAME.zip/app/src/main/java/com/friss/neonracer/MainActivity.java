package com.friss.neonracer;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.opengl.GLSurfaceView;
import android.opengl.GLES30;
import android.os.SystemClock;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.Date;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.HashMap;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

/**
 * FARISS RACING GAME - Android arcade racing prototype.
 * Firebase powers room matchmaking/presence and the global leaderboard.
 * Existing profile, wallet and demo-admin features remain local-only.
 */
public class MainActivity extends Activity {
    static { System.loadLibrary("neonracer"); }

    private static final String ADMIN_PIN = "246810"; // Demo-only gate, not production security.
    private static final String TIKTOK_URL = "https://www.tiktok.com/@frissanjaymabar";
    private static final String INSTAGRAM_URL = "https://www.instagram.com/frisswho?vrfl=M3FqeTRqbDd4dHF4";
    private static final String TELEGRAM_URL = "https://t.me/farisisheree";

    private FrameLayout root;
    private GameView game;
    private View remoteOverlay;
    private TextView hud;
    private TextView speedHud;
    private Button pauseButton;
    private LinearLayout gameControls;
    private View overlay;
    private View animatedBackdrop;

    // Firebase-backed lobby and leaderboard. Game login/profile remains the existing local prototype.
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore firestore;
    private String currentRoomCode = "";
    private String currentRoomHostUid = "";
    private boolean multiplayerRace = false;
    private boolean roomStartHandled = false;
    private float multiplayerLane = 0.50f;
    private long lastMultiplayerWriteMs = 0L;
    private ListenerRegistration roomListener, roomPlayersListener, publicRoomsListener;
    private final Map<String, RemoteRacer> remoteRacers = new LinkedHashMap<>();
    private LinearLayout lobbyRoomsList;
    private TextView roomStatusText, roomCountText, roomRosterText;
    private Button roomStartButton;
    private LinearLayout roomRosterContainer;

    private SharedPreferences globalPrefs, accountsPrefs, prefs;
    private Bitmap[] playerSprites = new Bitmap[10];
    private Bitmap trafficSprite, rivalSprite, policeSprite, truckSprite, coinSprite;

    private volatile boolean inGame = false;
    private boolean gameOverHandled = false, pauseDialogOpen = false;
    private int carStyle, speedLevel, nitroLevel, handlingLevel;
    private boolean effectsOn, leftHanded, musicOn, soundOn;
    private String currentUserId = "", currentUsername = "";

    private MediaPlayer backgroundMusic;
    private int currentTrackRes = 0;
    private SoundPool soundPool;
    private int clickSfx, nitroSfx, coinSfx, crashSfx, engineSfx;
    private int engineStream = 0;
    private boolean nitroSfxPlaying = false;
    private int lastSoundCoinCount = 0;

    private EditText adminIdInput, adminCoinAmountInput;
    private TextView adminTargetSummary;
    private final int screenBg = Color.rgb(5, 10, 24);
    // Bright showroom UI for player screens; dark control-room UI for pause/admin dialogs.
    private boolean lightUi = true;
    private boolean dialogReturnLightUi = true;
    private int weatherMode = 0; // 0 clear, 1 rain, 2 fog

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();
        globalPrefs = getSharedPreferences("fariss_global", MODE_PRIVATE);
        accountsPrefs = getSharedPreferences("fariss_accounts", MODE_PRIVATE);
        prefs = globalPrefs;
        loadSettings();
        loadSprites();
        initSoundPool();
        immersive();

        root = new FrameLayout(this);
        game = new GameView();
        root.addView(game, new FrameLayout.LayoutParams(-1, -1));
        remoteOverlay = new RemoteOverlayView();
        root.addView(remoteOverlay, new FrameLayout.LayoutParams(-1, -1));

        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(13);
        hud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        hud.setText("RACE SESSION\nSCORE 0  •  COINS 0");
        hud.setTextSize(11);
        hud.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
        hud.setPadding(dp(12), dp(8), dp(12), dp(8));
        hud.setBackground(makeRounded(Color.argb(218, 4, 15, 34), Color.argb(230, 20, 125, 220), dp(12), dp(1)));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(dp(205), dp(54), Gravity.TOP | Gravity.LEFT);
        hp.setMargins(dp(10), dp(10), 0, 0);
        root.addView(hud, hp);
        hud.setVisibility(View.GONE);

        speedHud = new TextView(this);
        speedHud.setText("000\nKM/H");
        speedHud.setGravity(Gravity.CENTER);
        speedHud.setTextColor(Color.WHITE);
        speedHud.setTextSize(16);
        speedHud.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        speedHud.setPadding(dp(10), dp(4), dp(10), dp(4));
        speedHud.setBackground(makeRounded(Color.argb(218, 4, 15, 34), Color.argb(230, 20, 125, 220), dp(13), dp(1)));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(94), dp(52), Gravity.TOP | Gravity.RIGHT);
        sp.setMargins(0, dp(10), dp(66), 0);
        root.addView(speedHud, sp);
        speedHud.setVisibility(View.GONE);

        pauseButton = new Button(this);
        pauseButton.setText("Ⅱ");
        pauseButton.setTextSize(18);
        pauseButton.setTextColor(Color.WHITE);
        pauseButton.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        pauseButton.setAllCaps(false);
        pauseButton.setElevation(dp(8));
        pauseButton.setBackground(makeRounded(Color.rgb(29, 215, 255), Color.rgb(22, 85, 222), dp(13), dp(1)));
        pauseButton.setOnClickListener(v -> { playClick(); showPauseDialog(); });
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(48), Gravity.TOP | Gravity.RIGHT);
        pp.setMargins(0, dp(3), dp(6), 0);
        root.addView(pauseButton, pp);
        pauseButton.setVisibility(View.GONE);

        gameControls = createGameControls();
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM);
        cp.setMargins(dp(8), 0, dp(8), dp(8));
        root.addView(gameControls, cp);
        gameControls.setVisibility(View.GONE);

        setContentView(root);
        applyNativeOptions();

        // Animated startup sequence before routing to login or the main menu.
        showBootScreen(() -> {
            String rememberedId = globalPrefs.getString("active_user_id", "");
            JSONObject remembered = findPlayerById(rememberedId);
            if (remembered != null && !remembered.optBoolean("banned", false)) {
                activateUser(remembered, false);
                showMenu();
            } else {
                globalPrefs.edit().remove("active_user_id").apply();
                currentUserId = "";
                currentUsername = "";
                prefs = globalPrefs;
                showAuthScreen();
            }
        });
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        immersive();
        if (root != null) root.requestLayout();
        if (game != null) game.requestRender();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    private void loadSettings() {
        carStyle = Math.max(0, Math.min(9, prefs.getInt("car_style", 0)));
        speedLevel = prefs.getInt("speed_level", 0);
        nitroLevel = prefs.getInt("nitro_level", 0);
        handlingLevel = prefs.getInt("handling_level", 0);
        effectsOn = prefs.getBoolean("effects_on", true);
        musicOn = prefs.getBoolean("music_on", true);
        soundOn = prefs.getBoolean("sound_on", true);
        leftHanded = prefs.getBoolean("left_handed", false);
        weatherMode = prefs.getInt("weather_mode", 0);
        nativeSetWeather(weatherMode);
    }

    private void loadSprites() {
        playerSprites[0] = BitmapFactory.decodeResource(getResources(), R.drawable.car_takara);
        playerSprites[1] = BitmapFactory.decodeResource(getResources(), R.drawable.car_kurosawa);
        playerSprites[2] = BitmapFactory.decodeResource(getResources(), R.drawable.car_toro);
        playerSprites[3] = BitmapFactory.decodeResource(getResources(), R.drawable.car_velare);
        playerSprites[4] = BitmapFactory.decodeResource(getResources(), R.drawable.car_nemo);
        playerSprites[5] = BitmapFactory.decodeResource(getResources(), R.drawable.car_hayate);
        playerSprites[6] = BitmapFactory.decodeResource(getResources(), R.drawable.car_raijin);
        playerSprites[7] = BitmapFactory.decodeResource(getResources(), R.drawable.car_vortex);
        playerSprites[8] = BitmapFactory.decodeResource(getResources(), R.drawable.car_blaze);
        playerSprites[9] = BitmapFactory.decodeResource(getResources(), R.drawable.car_shinobi);
        trafficSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_traffic);
        rivalSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_rival);
        policeSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_police);
        truckSprite = BitmapFactory.decodeResource(getResources(), R.drawable.car_truck);
        coinSprite = BitmapFactory.decodeResource(getResources(), R.drawable.coin_gold);
    }

    private Bitmap currentPlayerSprite() { return playerSprites[Math.max(0, Math.min(9, carStyle))]; }
    private String carName(int id) {
        String[] names = {"TAKARA FR-90", "KUROSAWA GTR-R34", "TORO LP-700", "VELARE F8", "NEMO GT3 RS", "HAYATE WRX STI", "RAIJIN EVO IX", "VORTEX M4", "BLAZE SRT", "SHINOBI CIVIC TYPE R"};
        return names[Math.max(0, Math.min(9, id))];
    }

    private void initSoundPool() {
        AudioAttributes attrs = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build();
        soundPool = new SoundPool.Builder().setMaxStreams(8).setAudioAttributes(attrs).build();
        clickSfx = soundPool.load(this, R.raw.sfx_click, 1);
        nitroSfx = soundPool.load(this, R.raw.sfx_nitro, 1);
        coinSfx = soundPool.load(this, R.raw.sfx_coin, 1);
        crashSfx = soundPool.load(this, R.raw.sfx_crash, 1);
        engineSfx = soundPool.load(this, R.raw.sfx_engine, 1);
    }
    private void playSfx(int id, float volume) {
        if (soundOn && soundPool != null && id != 0) {
            try { soundPool.play(id, volume, volume, 1, 0, 1f); } catch (Exception ignored) { }
        }
    }
    private void playClick() { playSfx(clickSfx, .65f); }
    private void startEngineSound() {
        if (!soundOn || soundPool == null || engineSfx == 0 || engineStream != 0) return;
        engineStream = soundPool.play(engineSfx, .17f, .17f, 1, -1, 1f);
    }
    private void stopEngineSound() {
        if (soundPool != null && engineStream != 0) {
            try { soundPool.stop(engineStream); } catch (Exception ignored) { }
        }
        engineStream = 0;
    }
    private void stopNitroSound() {
        if (soundPool != null && nitroSfxPlaying) {
            // Nitro is intentionally a one-shot accent rather than an infinite loop.
            nitroSfxPlaying = false;
        }
        nativeNitro(false);
    }

    private void playTrack(int resourceId) {
        if (currentTrackRes == resourceId && backgroundMusic != null) {
            applyMusicSetting();
            return;
        }
        if (backgroundMusic != null) {
            try { backgroundMusic.stop(); } catch (Exception ignored) { }
            backgroundMusic.release();
            backgroundMusic = null;
        }
        currentTrackRes = resourceId;
        try {
            backgroundMusic = MediaPlayer.create(this, resourceId);
            if (backgroundMusic != null) {
                backgroundMusic.setLooping(true);
                backgroundMusic.setVolume(.42f, .42f);
                if (musicOn) backgroundMusic.start();
            }
        } catch (Exception ignored) { backgroundMusic = null; }
    }
    private void applyMusicSetting() {
        if (backgroundMusic == null && currentTrackRes != 0) playTrack(currentTrackRes);
        if (backgroundMusic == null) return;
        try {
            if (musicOn && !backgroundMusic.isPlaying()) backgroundMusic.start();
            else if (!musicOn && backgroundMusic.isPlaying()) backgroundMusic.pause();
        } catch (Exception ignored) { }
    }

    private void applyNativeOptions() {
        nativeSetUpgrades(speedLevel, nitroLevel, handlingLevel);
        nativeSetCarStyle(carStyle);
        nativeSetOptions(effectsOn, leftHanded);
    }
    private int themedTextColor(int color) {
        if (!lightUi) return color;
        if (color == Color.WHITE) return Color.rgb(17, 43, 75);
        if (color == Color.LTGRAY || color == Color.GRAY) return Color.rgb(86, 111, 140);
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        // Convert pale blue/grey copy to legible slate while preserving saturated cyan and gold accents.
        boolean gold = r > 190 && g > 125 && b < 155;
        boolean saturatedAccent = b > 180 && g > 105 && (b - r > 35);
        if (!gold && !saturatedAccent && r > 130 && g > 155 && b > 175)
            return Color.rgb(77, 102, 132);
        return color;
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(themedTextColor(color));
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.create(size >= 24 ? "sans-serif-black" : "sans-serif-medium", size >= 24 ? Typeface.BOLD : Typeface.NORMAL));
        t.setPadding(dp(8), dp(5), dp(8), dp(5));
        t.setLetterSpacing(size >= 20 ? 0.025f : 0.008f);
        return t;
    }
    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        e.setTextColor(lightUi ? Color.rgb(16, 43, 76) : Color.WHITE);
        e.setHintTextColor(lightUi ? Color.rgb(113, 137, 165) : Color.rgb(140, 170, 200));
        e.setHint(hint);
        e.setPadding(dp(14), dp(11), dp(14), dp(11));
        e.setBackground(lightUi
            ? makeRounded(Color.rgb(255,255,255), Color.rgb(235,245,255), dp(14), dp(1))
            : makeRounded(Color.rgb(14, 29, 48), Color.rgb(9, 18, 31), dp(12), dp(1)));
        if (password) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        return e;
    }
    private Button button(String value, Runnable action, boolean primary) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(primary || !lightUi ? Color.WHITE : Color.rgb(18, 54, 91));
        b.setTextSize(13);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setLetterSpacing(.035f);
        b.setAllCaps(false);
        b.setMinHeight(dp(primary ? 56 : 50));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        b.setElevation(dp(primary ? 7 : 3));
        if (primary) {
            b.setBackground(makeRounded(Color.rgb(29, 211, 255), Color.rgb(24, 91, 235), dp(17), dp(1)));
        } else if (lightUi) {
            b.setBackground(makeRounded(Color.rgb(255,255,255), Color.rgb(218,235,255), dp(15), dp(1)));
        } else {
            b.setBackground(makeRounded(Color.rgb(25, 43, 65), Color.rgb(9, 17, 31), dp(15), dp(1)));
        }
        b.setOnClickListener(v -> { playClick(); action.run(); });
        return b;
    }
    private GradientDrawable makeRounded(int topColor, int bottomColor, int radius, int strokeWidth) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{topColor, bottomColor});
        d.setCornerRadius(radius);
        if (strokeWidth > 0) d.setStroke(strokeWidth, lightUi ? Color.argb(115, 71, 160, 235) : Color.argb(125, 70, 205, 255));
        return d;
    }
    private void addEyebrow(LinearLayout parent, String value) {
        TextView t = text(value, 10, Color.rgb(0, 145, 210));
        t.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        t.setLetterSpacing(.16f);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(2), dp(10), 0, dp(3));
        parent.addView(t, p);
    }
    private void addGlassCard(LinearLayout parent, View child) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13), dp(11), dp(13), dp(11));
        card.setBackground(lightUi
            ? makeRounded(Color.rgb(255,255,255), Color.rgb(235,246,255), dp(18), dp(1))
            : makeRounded(Color.rgb(16, 33, 56), Color.rgb(8, 17, 32), dp(18), dp(1)));
        card.setElevation(dp(3));
        card.addView(child, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(dp(2), dp(5), dp(2), dp(7));
        parent.addView(card, p);
    }

    private LinearLayout makePanel(String titleText) {
        lightUi = true;
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(18), dp(16), dp(18), dp(18));
        panel.setGravity(Gravity.CENTER_HORIZONTAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(231, 247, 252, 255), Color.argb(226, 225, 240, 255), Color.argb(232, 238, 247, 255)});
        bg.setCornerRadius(dp(0));
        panel.setBackground(bg);
        if (titleText != null && !titleText.isEmpty()) {
            TextView title = text(titleText, 23, Color.rgb(15, 49, 86));
            title.setGravity(Gravity.CENTER);
            title.setLetterSpacing(.045f);
            LinearLayout.LayoutParams titleP = new LinearLayout.LayoutParams(-1, -2);
            titleP.setMargins(0, 0, 0, dp(12));
            panel.addView(title, titleP);
        }
        return panel;
    }
    private void styleBrandLogo(ImageView logo) {
        logo.setBackground(makeRounded(Color.rgb(3, 11, 28), Color.rgb(0, 130, 235), dp(15), dp(1)));
        logo.setPadding(dp(8), dp(7), dp(8), dp(7));
    }

    private void showOverlay(View v) {
        int wanted = inGame ? ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT;
        if (getRequestedOrientation() != wanted) setRequestedOrientation(wanted);
        if (overlay != null) root.removeView(overlay);
        if (animatedBackdrop != null) root.removeView(animatedBackdrop);
        animatedBackdrop = new AnimatedBackdrop(lightUi);
        root.addView(animatedBackdrop, new FrameLayout.LayoutParams(-1, -1));
        overlay = v;
        v.setAlpha(0f);
        v.setTranslationY(dp(8));
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        v.animate().alpha(1f).translationY(0f).setDuration(260).start();
        hud.setVisibility(View.GONE);
        speedHud.setVisibility(View.GONE);
        pauseButton.setVisibility(View.GONE);
        gameControls.setVisibility(View.GONE);
        game.invalidate();
    }

    private void showBootScreen(Runnable whenFinished) {
        LinearLayout splash = makePanel("");
        splash.setGravity(Gravity.CENTER);
        splash.setPadding(dp(22), dp(24), dp(22), dp(24));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        styleBrandLogo(logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAlpha(.18f);
        logo.setScaleX(.82f);
        logo.setScaleY(.82f);
        LinearLayout.LayoutParams logoP = new LinearLayout.LayoutParams(-1, dp(218));
        logoP.setMargins(dp(4), 0, dp(4), dp(10));
        splash.addView(logo, logoP);

        TextView brand = text("FARISS RACING", 27, Color.WHITE);
        brand.setGravity(Gravity.CENTER);
        brand.setLetterSpacing(.13f);
        brand.setAlpha(0f);
        splash.addView(brand, new LinearLayout.LayoutParams(-1, -2));

        TextView tagline = text("NEON RACER  /  SEASON 01", 10, Color.rgb(73, 213, 255));
        tagline.setGravity(Gravity.CENTER);
        tagline.setLetterSpacing(.15f);
        LinearLayout.LayoutParams taglineP = new LinearLayout.LayoutParams(-1, -2);
        taglineP.setMargins(0, dp(8), 0, dp(26));
        splash.addView(tagline, taglineP);

        FrameLayout barTrack = new FrameLayout(this);
        barTrack.setBackground(makeRounded(Color.rgb(15, 29, 47), Color.rgb(8, 15, 27), dp(8), dp(1)));
        barTrack.setClipToOutline(true);
        View barFill = new View(this);
        barFill.setBackground(makeRounded(Color.rgb(58, 226, 255), Color.rgb(0, 112, 235), dp(8), 0));
        barFill.setScaleX(.02f);
        barFill.setPivotX(0f);
        barTrack.addView(barFill, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams trackP = new LinearLayout.LayoutParams(-1, dp(8));
        trackP.setMargins(dp(22), 0, dp(22), dp(13));
        splash.addView(barTrack, trackP);

        TextView status = text("INITIALIZING RACE SYSTEMS", 10, Color.rgb(158, 188, 215));
        status.setGravity(Gravity.CENTER);
        status.setLetterSpacing(.12f);
        splash.addView(status, new LinearLayout.LayoutParams(-1, -2));

        showOverlay(splash);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).start();
        brand.animate().alpha(1f).setStartDelay(230).setDuration(500).start();
        barFill.animate().scaleX(1f).setStartDelay(100).setDuration(1250).start();
        status.animate().alpha(.42f).setStartDelay(180).setDuration(430)
                .withEndAction(() -> status.animate().alpha(1f).setDuration(430).start()).start();

        root.postDelayed(() -> {
            if (overlay == splash) {
                removeOverlay();
                whenFinished.run();
            }
        }, 1580);
    }
    private void removeOverlay() {
        if (overlay != null) { root.removeView(overlay); overlay = null; }
        if (animatedBackdrop != null) { root.removeView(animatedBackdrop); animatedBackdrop = null; }
    }
    private void addAction(LinearLayout panel, String label, Runnable action, boolean primary) {
        Button b = button(label, action, primary);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(3), 0, dp(3));
        panel.addView(b, p);
    }
    private void addInput(LinearLayout panel, EditText e) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        panel.addView(e, p);
    }

    // -------------------- Offline account prototype --------------------
    private JSONArray getPlayers() {
        try { return new JSONArray(accountsPrefs.getString("players", "[]")); }
        catch (JSONException e) { return new JSONArray(); }
    }
    private void savePlayers(JSONArray players) { accountsPrefs.edit().putString("players", players.toString()).apply(); }
    private JSONObject findPlayerById(String id) {
        if (id == null || id.trim().isEmpty()) return null;
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && p.optString("id").equalsIgnoreCase(id.trim())) return p;
        }
        return null;
    }
    private JSONObject findPlayerByNameOrId(String value) {
        if (value == null) return null;
        String v = value.trim();
        JSONArray arr = getPlayers();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject p = arr.optJSONObject(i);
            if (p != null && (p.optString("id").equalsIgnoreCase(v) || p.optString("username").equalsIgnoreCase(v))) return p;
        }
        return null;
    }
    private String passwordHash(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest((salt + ":" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format(Locale.US, "%02x", b & 0xff));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
    private void activateUser(JSONObject player, boolean persistSession) {
        currentUserId = player.optString("id", "");
        currentUsername = player.optString("username", "PLAYER");
        if (persistSession) globalPrefs.edit().putString("active_user_id", currentUserId).apply();
        prefs = getSharedPreferences("player_" + currentUserId, MODE_PRIVATE);
        loadSettings();
        applyNativeOptions();
    }
    private void showAuthScreen() {
        inGame = false;
        stopEngineSound();
        playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("");
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(5), dp(8), dp(5), dp(14));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer);
        styleBrandLogo(logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoP = new LinearLayout.LayoutParams(-1, dp(190));
        logoP.setMargins(dp(8), 0, dp(8), dp(2));
        body.addView(logo, logoP);
        body.addView(text("PLAYER LOGIN", 24, Color.rgb(15, 47, 85)));
        body.addView(text("LOG IN OR CREATE YOUR RACER ID", 10, Color.rgb(95, 122, 151)));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(14), dp(13), dp(14), dp(13));
        form.setBackground(makeRounded(Color.rgb(255,255,255), Color.rgb(231,243,255), dp(20), dp(1)));
        EditText username = input("♟  Username or Player ID", false);
        EditText password = input("🔒  Password", true);
        addInput(form, username); addInput(form, password);
        addAction(form, "LOGIN  ›", () -> doLogin(username.getText().toString(), password.getText().toString()), true);
        LinearLayout.LayoutParams formP = new LinearLayout.LayoutParams(-1, -2);
        formP.setMargins(0, dp(12), 0, dp(8));
        body.addView(form, formP);
        body.addView(text("OR", 10, Color.rgb(115, 139, 165)));
        addAction(body, "♟  CREATE NEW PLAYER", this::showRegisterScreen, false);
        body.addView(text("Local profile prototype  •  Online rooms use Firebase", 9, Color.rgb(99, 127, 158)));
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void showRegisterScreen() {
        LinearLayout panel = makePanel("");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer_horizontal);
        styleBrandLogo(logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo, new LinearLayout.LayoutParams(-1, dp(125)));
        body.addView(text("CREATE YOUR RACER ID", 23, Color.rgb(15, 47, 85)));
        body.addView(text("Pick a username and secure password", 11, Color.rgb(95, 122, 151)));
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(14), dp(14), dp(14), dp(14));
        form.setBackground(makeRounded(Color.WHITE, Color.rgb(231,243,255), dp(18), dp(1)));
        EditText username = input("Username (3-16 letters/numbers/._)", false);
        EditText password = input("Password (minimum 6 characters)", true);
        EditText confirm = input("Confirm password", true);
        addInput(form, username); addInput(form, password); addInput(form, confirm);
        addAction(form, "CREATE ACCOUNT  ›", () -> {
            String name = username.getText().toString().trim();
            String pass = password.getText().toString();
            if (!name.matches("[A-Za-z0-9_.]{3,16}")) { alert("INVALID USERNAME", "Use 3-16 letters, numbers, underscore or dot."); return; }
            if (pass.length() < 6) { alert("PASSWORD TOO SHORT", "Use at least 6 characters."); return; }
            if (!pass.equals(confirm.getText().toString())) { alert("PASSWORD MISMATCH", "The passwords do not match."); return; }
            if (findPlayerByNameOrId(name) != null) { alert("USERNAME UNAVAILABLE", "Choose another username."); return; }
            String id = "FRS-" + UUID.randomUUID().toString().replace("-", "").substring(0, 8).toUpperCase(Locale.US);
            String salt = UUID.randomUUID().toString();
            JSONObject player = new JSONObject();
            try {
                player.put("id", id); player.put("username", name); player.put("salt", salt);
                player.put("passwordHash", passwordHash(pass, salt)); player.put("banned", false);
                player.put("createdAt", System.currentTimeMillis());
                JSONArray arr = getPlayers(); arr.put(player); savePlayers(arr);
            } catch (JSONException ex) { alert("ACCOUNT ERROR", "Could not save the account on this device."); return; }
            activateUser(player, true);
            alert("RACER ID CREATED", "Username: " + name + "\nYour Player ID: " + id + "\nSave this ID for reference.");
            showMenu();
        }, true);
        LinearLayout.LayoutParams formP = new LinearLayout.LayoutParams(-1, -2);
        formP.setMargins(0, dp(12), 0, dp(8)); body.addView(form, formP);
        addAction(body, "← BACK TO LOGIN", this::showAuthScreen, false);
        sc.addView(body); panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }
    private void doLogin(String usernameOrId, String password) {
        JSONObject player = findPlayerByNameOrId(usernameOrId);
        if (player == null) { alert("Player not found", "Create an account first, or check the username / ID."); return; }
        if (player.optBoolean("banned", false)) { alert("Account banned", "This local player is banned on this device. Contact the local demo administrator."); return; }
        String salt = player.optString("salt", "");
        if (!passwordHash(password, salt).equals(player.optString("passwordHash", ""))) {
            alert("Login failed", "The password is incorrect."); return;
        }
        activateUser(player, true);
        showMenu();
    }
    private void logout() {
        inGame = false; nativePause(true); stopEngineSound(); stopNitroSound();
        currentUserId = ""; currentUsername = "";
        globalPrefs.edit().remove("active_user_id").apply();
        prefs = globalPrefs;
        showAuthScreen();
    }

    // -------------------- Screens --------------------
    private void showMenu() {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        lobbyRoomsList = null;
        inGame = false;
        pauseDialogOpen = false;
        nativeReset(); nativePause(true); stopEngineSound(); stopNitroSound();
        loadSettings(); applyNativeOptions(); playTrack(R.raw.dashboard_music);
        LinearLayout panel = makePanel("");
        panel.setPadding(dp(14), dp(10), dp(14), dp(15));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(2), dp(4), dp(2), dp(10));

        LinearLayout profile = new LinearLayout(this);
        profile.setGravity(Gravity.CENTER_VERTICAL);
        profile.setPadding(dp(12), dp(8), dp(12), dp(8));
        profile.setBackground(makeRounded(Color.rgb(255,255,255), Color.rgb(224,240,255), dp(18), dp(1)));
        TextView avatar = text("♟", 23, Color.rgb(28, 121, 222));
        avatar.setBackground(makeRounded(Color.rgb(225,242,255), Color.rgb(204,229,255), dp(24), dp(0)));
        profile.addView(avatar, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout playerInfo = new LinearLayout(this);
        playerInfo.setOrientation(LinearLayout.VERTICAL);
        TextView player = text(currentUsername, 14, Color.rgb(15, 44, 78)); player.setGravity(Gravity.LEFT);
        TextView id = text(currentUserId, 9, Color.rgb(90, 122, 158)); id.setGravity(Gravity.LEFT);
        playerInfo.addView(player); playerInfo.addView(id);
        profile.addView(playerInfo, new LinearLayout.LayoutParams(0, -2, 1));
        TextView wallet = text("🪙  " + prefs.getInt("bank_coins", 0), 13, Color.rgb(20, 92, 180));
        wallet.setBackground(makeRounded(Color.rgb(238,247,255), Color.rgb(215,234,255), dp(14), dp(1)));
        profile.addView(wallet);
        body.addView(profile);
        addEyebrow(body, "FARISS MOTORSPORTS   •   SEASON 01");

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo_neon_racer_horizontal);
        styleBrandLogo(logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams heroBanner = new LinearLayout.LayoutParams(-1, dp(158));
        heroBanner.setMargins(dp(2), dp(0), dp(2), dp(2));
        body.addView(logo, heroBanner);
        logo.setOnLongClickListener(v -> { playClick(); askAdminPin(); return true; });
        ImageView heroCar = new ImageView(this);
        heroCar.setImageBitmap(currentPlayerSprite());
        heroCar.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams heroCarP = new LinearLayout.LayoutParams(-1, dp(105));
        heroCarP.setMargins(dp(18), dp(-2), dp(18), dp(2));
        body.addView(heroCar, heroCarP);
        TextView tagline = text("RACE THE NIGHT. OWN THE ROAD.", 11, Color.rgb(20, 93, 170));
        tagline.setLetterSpacing(.18f); body.addView(tagline);
        TextView season = text("NEON RACER  /  FRISS EDITION", 9, Color.rgb(102, 127, 157));
        body.addView(season);
        int careerXp = prefs.getInt("career_xp", 0);
        int careerLevel = careerLevel(careerXp);
        body.addView(text("LEVEL " + careerLevel + "  •  " + careerRank(careerLevel) + "  •  " + careerXp + " XP", 10, Color.rgb(25, 113, 201)));

        Button race = button("▶   START RACE     •     QUICK RACE", this::startGame, true);
        LinearLayout.LayoutParams raceP = new LinearLayout.LayoutParams(-1, dp(62));
        raceP.setMargins(0, dp(13), 0, dp(10)); body.addView(race, raceP);

        addEyebrow(body, "YOUR RACING HUB");
        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL);
        addMenuTile(row1, "🚘\nGARAGE", this::showGarage);
        addMenuTile(row1, "🔧\nUPGRADES", this::showUpgrades);
        addMenuTile(row1, "🌐\nONLINE RACING", this::showMultiplayerLobby);
        body.addView(row1);
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL);
        addMenuTile(row2, "🏆\nGLOBAL RANKINGS", this::showLeaderboard);
        addMenuTile(row2, "🪙\nTOP UP COINS", this::showTopUp);
        addMenuTile(row2, "⚙\nSETTINGS", this::showSettings);
        body.addView(row2);
        LinearLayout row3 = new LinearLayout(this); row3.setOrientation(LinearLayout.HORIZONTAL);
        addMenuTile(row3, "🎯\nDAILY OPS", this::showDailyOps);
        addMenuTile(row3, "🏅\nCAREER", this::showCareer);
        addMenuTile(row3, "🎨\nCUSTOMIZE", this::showCustomization);
        body.addView(row3);
        addAction(body, "✦  DEVELOPER & SOCIALS", this::showDeveloper, false);
        addAction(body, "↪  LOG OUT", this::logout, false);
        body.addView(text("SWIPE LEFT / RIGHT TO STEER  •  SWIPE UP FOR NOS", 9, Color.rgb(99, 126, 157)));
        body.addView(text("ADMIN ACCESS  •  LONG-PRESS THE LOGO", 9, Color.rgb(24, 130, 202)));

        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
    }

    private void addMenuTile(LinearLayout row, String label, Runnable action) {
        Button tile = button(label, action, false);
        tile.setTextSize(10);
        tile.setMinHeight(dp(68));
        tile.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(69), 1);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        row.addView(tile, p);
    }

    private LinearLayout createGameControls() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), dp(2), dp(8), dp(2));
        row.setBackgroundColor(Color.TRANSPARENT);
        Button left = button("◀", () -> nativeSteer(-1), false);
        Button right = button("▶", () -> nativeSteer(1), false);
        Button nitro = button("NITRO  ⚡", () -> { nativeNitro(true); playSfx(nitroSfx, .95f); }, true);
        left.setTextSize(22); right.setTextSize(22); nitro.setTextSize(12);
        left.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { nativeSteer(-1); v.setAlpha(.72f); return true; }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { v.setAlpha(1f); return true; }
            return true;
        });
        right.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { nativeSteer(1); v.setAlpha(.72f); return true; }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { v.setAlpha(1f); return true; }
            return true;
        });
        nitro.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) { nativeNitro(true); playSfx(nitroSfx, .95f); v.setAlpha(.72f); return true; }
            if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) { nativeNitro(false); stopNitroSound(); v.setAlpha(1f); return true; }
            return true;
        });
        LinearLayout leftGroup = new LinearLayout(this);
        leftGroup.setOrientation(LinearLayout.HORIZONTAL);
        leftGroup.setGravity(Gravity.CENTER_VERTICAL);
        leftGroup.addView(left, new LinearLayout.LayoutParams(dp(62), dp(58)));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(62), dp(58));
        rp.setMargins(dp(7), 0, 0, 0);
        leftGroup.addView(right, rp);
        row.addView(leftGroup, new LinearLayout.LayoutParams(0, -1, 1f));
        row.addView(nitro, new LinearLayout.LayoutParams(dp(116), dp(58)));
        return row;
    }

    private void startGame() { startGame(false); }

    private void startGame(boolean onlineRace) {
        if (inGame) return;
        multiplayerRace = onlineRace;
        if (remoteOverlay != null) remoteOverlay.invalidate();
        if (onlineRace) { multiplayerLane = 0.50f; lastMultiplayerWriteMs = 0L; remoteRacers.clear(); }
        inGame = true;
        gameOverHandled = false;
        pauseDialogOpen = false;
        loadSettings();
        applyNativeOptions();
        nativeReset();
        nativePause(true);
        lastSoundCoinCount = 0;
        playTrack(R.raw.racing_music);

        // Cinematic race-entry countdown; controls only activate after GO.
        FrameLayout cover = new FrameLayout(this);
        cover.setBackgroundColor(Color.argb(225, 2, 6, 15));
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(22), dp(20), dp(22), dp(20));

        TextView eyebrow = text(onlineRace ? "ONLINE GRID  /  RACE STARTING" : "PRE-RACE SEQUENCE", 11, Color.rgb(73, 213, 255));
        eyebrow.setGravity(Gravity.CENTER);
        eyebrow.setLetterSpacing(.18f);
        center.addView(eyebrow, new LinearLayout.LayoutParams(-1, -2));

        TextView countdown = text("3", 88, Color.rgb(64, 224, 255));
        countdown.setGravity(Gravity.CENTER);
        countdown.setShadowLayer(dp(20), 0f, 0f, Color.rgb(0, 150, 255));
        LinearLayout.LayoutParams countP = new LinearLayout.LayoutParams(-1, dp(132));
        countP.setMargins(0, dp(8), 0, dp(6));
        center.addView(countdown, countP);

        TextView guide = text("STEER WITH ◀  ▶  OR SWIPE LEFT / RIGHT", 12, Color.WHITE);
        guide.setGravity(Gravity.CENTER);
        guide.setLetterSpacing(.04f);
        center.addView(guide, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = text("HOLD NITRO TO BOOST", 10, Color.rgb(255, 207, 80));
        sub.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subP = new LinearLayout.LayoutParams(-1, -2);
        subP.setMargins(0, dp(8), 0, 0);
        center.addView(sub, subP);

        FrameLayout.LayoutParams centerP = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
        cover.addView(center, centerP);
        showOverlay(cover);
        animateRaceCountdown(cover, countdown, 0);
    }

    private void animateRaceCountdown(FrameLayout cover, TextView countdown, int index) {
        final String[] stages = {"3", "2", "1", "GO!"};
        if (index >= stages.length) {
            cover.animate().alpha(0f).setDuration(240).withEndAction(() -> {
                if (overlay == cover) removeOverlay();
                nativePause(false);
                hud.setVisibility(View.VISIBLE);
                speedHud.setVisibility(View.VISIBLE);
                pauseButton.setVisibility(View.VISIBLE);
                gameControls.setVisibility(View.VISIBLE);
                startEngineSound();
                game.invalidate();
            }).start();
            return;
        }

        countdown.setText(stages[index]);
        countdown.setTextColor(index == 3 ? Color.rgb(255, 207, 80) : Color.rgb(64, 224, 255));
        countdown.setScaleX(.58f);
        countdown.setScaleY(.58f);
        countdown.setAlpha(.12f);
        countdown.animate().alpha(1f).scaleX(1.08f).scaleY(1.08f).setDuration(210)
                .withEndAction(() -> countdown.animate().alpha(.86f).scaleX(1f).scaleY(1f)
                        .setDuration(220).start()).start();
        root.postDelayed(() -> animateRaceCountdown(cover, countdown, index + 1),
                index == 3 ? 420 : 650);
    }
    private void showPauseDialog() {
        if (!inGame || pauseDialogOpen) return;
        pauseDialogOpen = true; nativePause(true); stopNitroSound(); stopEngineSound();
        if (backgroundMusic != null && backgroundMusic.isPlaying()) backgroundMusic.pause();
        LinearLayout content=dialogContent("RACE PAUSED","TAKE A BREATHER, RACER");
        content.addView(text("Ⅱ",42,Color.rgb(52,205,255)));
        content.addView(text("Take a break, racer.",13,Color.rgb(190,211,233)));
        showCustomActions(content, new String[]{"▶  RESUME","⟳  RESTART","⌂  MAIN MENU"}, new Runnable[]{
            ()->{pauseDialogOpen=false;if(inGame){nativePause(false);applyMusicSetting();startEngineSound();}game.invalidate();},
            ()->{pauseDialogOpen=false;startGame();},
            ()->{pauseDialogOpen=false;showMenu();}
        });
    }
    private void finishGameIfNeeded() {
        if (!inGame || gameOverHandled || !nativeGameOver()) return;
        gameOverHandled = true; inGame = false; playSfx(crashSfx, 1f); stopEngineSound(); stopNitroSound(); playTrack(R.raw.dashboard_music);
        int score = nativeScore(), earned = nativeCoins();
        int best = Math.max(score, prefs.getInt("best_score", 0));
        int bank = prefs.getInt("bank_coins", 0) + earned;
        prefs.edit().putInt("best_score", best).putInt("bank_coins", bank).putInt("last_score", score).apply();
        saveLocalScore(score);
        updateCareerAfterRace(score, earned);
        saveOnlineLeaderboard(score);
        if (multiplayerRace) publishMultiplayerFinish(score);
        hud.setVisibility(View.GONE); speedHud.setVisibility(View.GONE); pauseButton.setVisibility(View.GONE); gameControls.setVisibility(View.GONE);
        LinearLayout result=dialogContent("RACE COMPLETE","SEASON 01 • RESULTS");
        result.addView(text("🏆  "+score+" POINTS",25,Color.rgb(55,215,255)));
        result.addView(text("PLAYER  "+currentUsername+"\nBEST  "+best+"\nCOINS EARNED  +"+earned+"\nWALLET  "+bank,13,Color.WHITE));
        showCustomActions(result,new String[]{"🏁  RACE AGAIN","🚗  GARAGE","⌂  MAIN MENU"},new Runnable[]{()->startGame(multiplayerRace),this::showGarage,this::showMenu});
    }
    private void saveLocalScore(int score) {
        String raw = prefs.getString("local_scores", ""); List<Integer> scores = new ArrayList<>();
        if (!raw.isEmpty()) for (String s : raw.split(",")) { try { scores.add(Integer.parseInt(s)); } catch (NumberFormatException ignored) { } }
        scores.add(score); Collections.sort(scores, Collections.reverseOrder()); StringBuilder out = new StringBuilder();
        for (int i=0; i<Math.min(10,scores.size()); i++) { if (i>0) out.append(','); out.append(scores.get(i)); }
        prefs.edit().putString("local_scores", out.toString()).apply();
    }
    private int careerLevel(int xp) { return Math.max(1, Math.min(100, 1 + Math.max(0, xp) / 500)); }
    private String careerRank(int level) {
        if (level >= 40) return "NEON LEGEND";
        if (level >= 25) return "DIAMOND DRIVER";
        if (level >= 15) return "PLATINUM RACER";
        if (level >= 8) return "GOLD RACER";
        if (level >= 4) return "SILVER RACER";
        return "ROOKIE";
    }
    private String todayKey() { return new java.text.SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }
    private void ensureDailyReset() {
        String today = todayKey();
        if (!today.equals(prefs.getString("daily_date", ""))) {
            prefs.edit().putString("daily_date", today).putInt("daily_races", 0).putInt("daily_score", 0)
                .putInt("daily_coins", 0).putBoolean("daily_claim_race", false)
                .putBoolean("daily_claim_score", false).putBoolean("daily_claim_coins", false).apply();
        }
    }
    private void updateCareerAfterRace(int score, int earned) {
        ensureDailyReset();
        int xpGain = Math.max(25, score / 4 + earned * 5);
        prefs.edit().putInt("career_xp", prefs.getInt("career_xp", 0) + xpGain)
            .putInt("career_races", prefs.getInt("career_races", 0) + 1)
            .putInt("career_total_score", prefs.getInt("career_total_score", 0) + Math.max(0, score))
            .putInt("career_total_coins", prefs.getInt("career_total_coins", 0) + Math.max(0, earned))
            .putInt("daily_races", prefs.getInt("daily_races", 0) + 1)
            .putInt("daily_score", Math.max(prefs.getInt("daily_score", 0), score))
            .putInt("daily_coins", prefs.getInt("daily_coins", 0) + Math.max(0, earned)).apply();
    }
    private void showDailyOps() {
        inGame=false; nativePause(true); stopEngineSound(); ensureDailyReset();
        LinearLayout panel=makePanel("DAILY OPERATIONS");
        panel.addView(text("COMPLETE MISSIONS • CLAIM YOUR COINS",10,Color.rgb(80,130,180)));
        addDailyMission(panel,"🏁  FIRST RUN","Finish 1 race today",prefs.getInt("daily_races",0),1,100,"daily_claim_race",()->prefs.getInt("daily_races",0)>=1);
        addDailyMission(panel,"⚡  HIGH SCORE","Reach 500 points in one race",prefs.getInt("daily_score",0),500,150,"daily_claim_score",()->prefs.getInt("daily_score",0)>=500);
        addDailyMission(panel,"🪙  COIN HUNTER","Collect 10 coins today",prefs.getInt("daily_coins",0),10,200,"daily_claim_coins",()->prefs.getInt("daily_coins",0)>=10);
        addGlassCard(panel,text("Daily missions reset every day. Rewards are credited to this device's local wallet.",10,Color.rgb(90,116,148)));
        addAction(panel,"← BACK TO MENU",this::showMenu,false); showOverlay(panel);
    }
    private void addDailyMission(LinearLayout parent,String title,String desc,int progress,int target,int reward,String claimKey,java.util.function.BooleanSupplier complete) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12),dp(10),dp(12),dp(10));
        card.setBackground(makeRounded(Color.WHITE,Color.rgb(216,235,255),dp(16),dp(1)));
        TextView h=text(title,13,Color.rgb(15,60,110));h.setGravity(Gravity.LEFT);card.addView(h);
        TextView d=text(desc,10,Color.rgb(100,126,155));d.setGravity(Gravity.LEFT);card.addView(d);
        int shown=Math.min(target,progress);
        TextView p=text(shown+" / "+target+"  •  REWARD "+reward+" COINS",10,Color.rgb(24,111,194));p.setGravity(Gravity.LEFT);card.addView(p);
        boolean claimed=prefs.getBoolean(claimKey,false);
        String label=claimed?"CLAIMED ✓":(complete.getAsBoolean()?"CLAIM +"+reward+" COINS":"MISSION IN PROGRESS");
        Button claim=button(label,()->{
            if(prefs.getBoolean(claimKey,false)) return;
            if(!complete.getAsBoolean()){alert("MISSION NOT COMPLETE","Selesaikan misi ini dulu.");return;}
            prefs.edit().putBoolean(claimKey,true).putInt("bank_coins",prefs.getInt("bank_coins",0)+reward).apply();
            playSfx(coinSfx,1f); showDailyOps();
        },!claimed && complete.getAsBoolean());
        claim.setEnabled(!claimed && complete.getAsBoolean());card.addView(claim);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(6),0,dp(7));parent.addView(card,cp);
    }
    private void showCareer() {
        inGame=false; nativePause(true); stopEngineSound();
        int xp=prefs.getInt("career_xp",0), level=careerLevel(xp), races=prefs.getInt("career_races",0);
        LinearLayout panel=makePanel("DRIVER CAREER");
        TextView rank=text(careerRank(level),24,Color.rgb(0,130,220));rank.setGravity(Gravity.CENTER);panel.addView(rank);
        TextView lv=text("LEVEL "+level+"  •  "+xp+" XP",13,Color.rgb(35,76,120));lv.setGravity(Gravity.CENTER);panel.addView(lv);
        addGlassCard(panel,text("RACES  "+races+"\nTOTAL SCORE  "+prefs.getInt("career_total_score",0)+"\nTOTAL COINS EARNED  "+prefs.getInt("career_total_coins",0)+"\nPERSONAL BEST  "+prefs.getInt("best_score",0),13,Color.rgb(35,76,120)));
        String[] badges={"FIRST FINISHER","SCORE HUNTER","COIN COLLECTOR","ROAD VETERAN"};
        boolean[] unlocked={races>=1,prefs.getInt("best_score",0)>=1000,prefs.getInt("career_total_coins",0)>=25,races>=25};
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);
        for(int i=0;i<badges.length;i++) addGlassCard(grid,text((unlocked[i]?"🏅  ":"🔒  ")+badges[i],11,unlocked[i]?Color.rgb(12,130,190):Color.GRAY));
        panel.addView(grid);addAction(panel,"DAILY OPERATIONS",this::showDailyOps,true);addAction(panel,"← BACK TO MENU",this::showMenu,false);showOverlay(panel);
    }
    private View carTile(int id, int imageHeight, Runnable refreshScreen) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER);
        tile.setPadding(dp(2),dp(2),dp(2),dp(2));
        tile.setBackground(makeRounded(id==carStyle?Color.rgb(8,62,112):Color.rgb(12,24,43),
            id==carStyle?Color.rgb(0,190,255):Color.rgb(35,61,92),dp(10),dp(1)));
        ImageView image = new ImageView(this);
        image.setImageBitmap(playerSprites[id]);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        tile.addView(image,new LinearLayout.LayoutParams(-1,imageHeight));
        String shortName=carName(id).split(" ")[0];
        TextView label=text(shortName,7,Color.rgb(220,240,255));
        label.setGravity(Gravity.CENTER);
        label.setSingleLine(true);
        tile.addView(label,new LinearLayout.LayoutParams(-1,dp(13)));
        tile.setOnClickListener(v->{carStyle=id;nativeSetCarStyle(id);prefs.edit().putInt("car_style",id).apply();refreshScreen.run();});
        return tile;
    }

    private void showCustomization() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("RACE CUSTOMIZATION");
        panel.addView(text("SELECT YOUR CAR STYLE",11,Color.rgb(80,120,160)));
        LinearLayout carGrid=new LinearLayout(this);carGrid.setOrientation(LinearLayout.VERTICAL);
        for(int rowIndex=0;rowIndex<2;rowIndex++){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            for(int col=0;col<5;col++){final int id=rowIndex*5+col;LinearLayout.LayoutParams vp=new LinearLayout.LayoutParams(0,dp(83),1);vp.setMargins(dp(3),dp(4),dp(3),dp(4));row.addView(carTile(id,dp(65),this::showCustomization),vp);}
            carGrid.addView(row);
        }
        panel.addView(carGrid);
        panel.addView(text(carName(carStyle)+"  •  MODEL "+(carStyle+1)+"/10",12,Color.rgb(0,154,224)));
        addSettingCard(panel,"✨  NEON EFFECTS","Glow, boost streaks and light effects",effectsOn?"ENABLED":"DISABLED",()->{effectsOn=!effectsOn;prefs.edit().putBoolean("effects_on",effectsOn).apply();nativeSetOptions(effectsOn,leftHanded);showCustomization();});
        addAction(panel,"OPEN GARAGE",this::showGarage,false);addAction(panel,"← BACK TO MENU",this::showMenu,false);showOverlay(panel);
    }

    private void showGarage() {
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("GARAGE");
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.addView(text("SELECT YOUR RIDE  •  10 UNIQUE MODELS", 11, Color.rgb(90,120,154)));

        LinearLayout preview = new LinearLayout(this);
        preview.setGravity(Gravity.CENTER);
        preview.setPadding(dp(10), dp(6), dp(10), dp(6));
        preview.setBackground(makeRounded(Color.rgb(7,18,36), Color.rgb(0,145,230), dp(18), dp(1)));
        ImageView carPreview = new ImageView(this);
        carPreview.setImageBitmap(currentPlayerSprite());
        carPreview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.addView(carPreview, new LinearLayout.LayoutParams(-1, dp(170)));
        LinearLayout.LayoutParams previewP = new LinearLayout.LayoutParams(-1, dp(183));
        previewP.setMargins(0, dp(9), 0, dp(8)); body.addView(preview, previewP);
        body.addView(text(carName(carStyle), 22, Color.rgb(0,126,207)));
        body.addView(text("MODEL " + (carStyle+1) + "/10  •  SPEED " + (6+speedLevel) + "/10", 11, Color.rgb(75,104,140)));
        LinearLayout stats = new LinearLayout(this); stats.setOrientation(LinearLayout.VERTICAL);
        addStatLine(stats, "SPEED", 6 + speedLevel);
        addStatLine(stats, "HANDLING", 5 + handlingLevel);
        addStatLine(stats, "NITRO", 5 + nitroLevel);
        addGlassCard(body, stats);

        LinearLayout thumbnails = new LinearLayout(this); thumbnails.setOrientation(LinearLayout.VERTICAL);
        for (int rowIndex=0;rowIndex<2;rowIndex++) {
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for(int col=0;col<5;col++) {
                final int id=rowIndex*5+col;
                LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(67),1);
                tp.setMargins(dp(3),dp(3),dp(3),dp(3));
                row.addView(carTile(id,dp(49),this::showGarage),tp);
            }
            thumbnails.addView(row);
        }
        body.addView(text("CHOOSE A MODEL", 10, Color.rgb(75,104,140)));
        body.addView(thumbnails);
        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        addAction(panel, "NEXT CAR  →", () -> { carStyle=(carStyle+1)%10; nativeSetCarStyle(carStyle); prefs.edit().putInt("car_style",carStyle).apply(); showGarage(); }, true);
        addAction(panel, "UPGRADE SHOP", this::showUpgrades, false);
        addAction(panel, "← BACK TO MENU", this::showMenu, false);
        showOverlay(panel);
    }
    private void addStatLine(LinearLayout parent, String label, int value) {
        LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(dp(5),dp(4),dp(5),dp(4));
        TextView name=text(label,10,Color.rgb(62,91,127));name.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
        line.addView(name,new LinearLayout.LayoutParams(dp(92),-2));
        View track=new View(this);track.setBackground(makeRounded(Color.rgb(213,229,246),Color.rgb(213,229,246),dp(8),0));
        FrameLayout bar=new FrameLayout(this);bar.addView(track,new FrameLayout.LayoutParams(-1,dp(8)));
        View fill=new View(this);fill.setBackground(makeRounded(Color.rgb(38,218,255),Color.rgb(27,105,231),dp(8),0));
        FrameLayout.LayoutParams fp=new FrameLayout.LayoutParams(-1,dp(8),Gravity.LEFT);fill.setPivotX(0f);fill.setScaleX(Math.max(0.08f,Math.min(1f,value/10f)));bar.addView(fill,fp);
        line.addView(bar,new LinearLayout.LayoutParams(0,dp(13),1));
        line.addView(text(value+"/10",10,Color.rgb(24,98,176)));
        parent.addView(line);
    }
    private void showUpgrades() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("UPGRADE SHOP");
        TextView wallet=text("🪙  WALLET  " + prefs.getInt("bank_coins",0) + " COINS",14,Color.rgb(181,123,0));
        wallet.setBackground(makeRounded(Color.rgb(255,249,223),Color.rgb(255,239,191),dp(15),dp(1)));
        panel.addView(wallet);
        addUpgradeCard(panel,"SPEED",speedLevel,"Improve straight-line pace",()->purchaseUpgrade("speed"));
        addUpgradeCard(panel,"NITRO",nitroLevel,"Boost duration and power",()->purchaseUpgrade("nitro"));
        addUpgradeCard(panel,"HANDLING",handlingLevel,"Sharper lane response",()->purchaseUpgrade("handling"));
        addAction(panel,"COIN TOP-UP VIA TELEGRAM",this::showTopUp,false);
        addAction(panel,"← BACK TO MENU",this::showMenu,false);
        showOverlay(panel);
    }
    private void addUpgradeCard(LinearLayout parent,String name,int level,String desc,Runnable action) {
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        TextView heading=text(name+"  •  LEVEL "+level+"/5",14,Color.rgb(20,73,125));heading.setGravity(Gravity.LEFT);content.addView(heading);
        TextView detail=text(desc,10,Color.rgb(100,126,155));detail.setGravity(Gravity.LEFT);content.addView(detail);
        addAction(content,level>=5?name+" MAX LEVEL":"UPGRADE  •  "+upgradeCost(level)+" COINS",action,true);
        addGlassCard(parent,content);
    }
    private int upgradeCost(int level) { return 250 + level*350; }
    private void purchaseUpgrade(String which) {
        int level = which.equals("speed")?speedLevel:which.equals("nitro")?nitroLevel:handlingLevel;
        if(level>=5) return; int cost=upgradeCost(level), bank=prefs.getInt("bank_coins",0);
        if(bank<cost) { alert("NOT ENOUGH COINS", "Need " + cost + " coins. Earn coins from races or order a top-up via Telegram."); return; }
        bank-=cost; if(which.equals("speed")) speedLevel++; else if(which.equals("nitro")) nitroLevel++; else handlingLevel++;
        prefs.edit().putInt("bank_coins",bank).putInt("speed_level",speedLevel).putInt("nitro_level",nitroLevel).putInt("handling_level",handlingLevel).apply();
        applyNativeOptions(); showUpgrades();
    }
    // -------------------- Firebase online services --------------------
    private void ensureOnlineAuth(Runnable onReady) {
        if (firebaseAuth == null || firestore == null) {
            alert("ONLINE SERVICES UNAVAILABLE", "Firebase belum bisa diinisialisasi. Periksa app/google-services.json dan koneksi internet.");
            return;
        }
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            onReady.run();
            return;
        }
        firebaseAuth.signInAnonymously()
            .addOnSuccessListener(result -> onReady.run())
            .addOnFailureListener(error -> alert("ONLINE LOGIN FAILED",
                "Aktifkan Authentication → Sign-in method → Anonymous di Firebase Console, lalu coba lagi.\n\n" + error.getLocalizedMessage()));
    }

    private String firebaseUid() {
        FirebaseUser user = firebaseAuth == null ? null : firebaseAuth.getCurrentUser();
        return user == null ? "" : user.getUid();
    }

    private String newRoomCode() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase(Locale.US);
    }

    private Map<String, Object> onlinePlayerData(String uid, float lane, int score, boolean racing, boolean finished) {
        Map<String, Object> data = new HashMap<>();
        data.put("uid", uid);
        data.put("playerId", currentUserId);
        data.put("username", currentUsername);
        data.put("lane", Math.max(.15f, Math.min(.85f, lane)));
        data.put("score", Math.max(0, score));
        data.put("isRacing", racing);
        data.put("finished", finished);
        data.put("updatedAt", FieldValue.serverTimestamp());
        return data;
    }

    private void showMultiplayerLobby() {
        inGame = false;
        nativePause(true);
        stopEngineSound();
        stopNitroSound();
        ensureOnlineAuth(() -> {
            if (!currentRoomCode.isEmpty()) {
                openRoomScreen(currentRoomCode);
                return;
            }
            renderMultiplayerLobby();
        });
    }

    private void renderMultiplayerLobby() {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        LinearLayout panel = makePanel("ONLINE PIT LANE");
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(4), dp(2), dp(10));
        body.addView(text("CREATE A ROOM OR JOIN A PUBLIC GRID", 11, Color.rgb(165, 206, 232)));
        body.addView(text("2 drivers needed to start • 4 drivers max • auto-start at 4", 10, Color.rgb(91, 224, 255)));
        addAction(body, "＋  CREATE ROOM", this::showCreateRoomDialog, true);
        addAction(body, "⇥  JOIN WITH ROOM CODE", this::showJoinRoomDialog, false);
        addEyebrow(body, "PUBLIC WAITING ROOMS");
        lobbyRoomsList = new LinearLayout(this);
        lobbyRoomsList.setOrientation(LinearLayout.VERTICAL);
        lobbyRoomsList.addView(text("Searching for rooms…", 12, Color.LTGRAY));
        body.addView(lobbyRoomsList, new LinearLayout.LayoutParams(-1, -2));
        addAction(body, "↻  REFRESH ROOMS", this::listenPublicRooms, false);
        addAction(body, "← BACK TO GARAGE MENU", this::showMenu, false);
        scroll.addView(body);
        panel.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);
        listenPublicRooms();
    }

    private void listenPublicRooms() {
        if (lobbyRoomsList == null || firestore == null) return;
        if (publicRoomsListener != null) publicRoomsListener.remove();
        publicRoomsListener = firestore.collection("rooms").whereEqualTo("visibility", "public").limit(50)
            .addSnapshotListener((snapshot, error) -> {
                if (error != null) {
                    runOnUiThread(() -> {
                        if (lobbyRoomsList != null) {
                            lobbyRoomsList.removeAllViews();
                            lobbyRoomsList.addView(text("Couldn't load rooms. Check Firestore Rules and internet.", 11, Color.rgb(255, 170, 145)));
                        }
                    });
                    return;
                }
                runOnUiThread(() -> {
                    if (lobbyRoomsList == null) return;
                    lobbyRoomsList.removeAllViews();
                    int shown = 0;
                    if (snapshot != null) for (DocumentSnapshot doc : snapshot.getDocuments()) {
                        String status = doc.getString("status");
                        List<?> uids = (List<?>) doc.get("memberUids");
                        int count = uids == null ? 0 : uids.size();
                        if (!"waiting".equals(status) || count >= 4) continue;
                        shown++;
                        String code = doc.getId();
                        boolean locked = Boolean.TRUE.equals(doc.getBoolean("passwordRequired"));
                        String host = doc.getString("hostUsername");
                        if (host == null || host.trim().isEmpty()) host = "RACER";
                        LinearLayout cardBody = new LinearLayout(this);
                        cardBody.setOrientation(LinearLayout.VERTICAL);
                        TextView heading = text((locked ? "▣  " : "◉  ") + code + "   •   " + host, 14, Color.WHITE);
                        heading.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        cardBody.addView(heading);
                        TextView meta = text(count + "/4 DRIVERS   •   " + (locked ? "PASSWORD REQUIRED" : "OPEN GRID"), 10, Color.rgb(93, 219, 255));
                        meta.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        cardBody.addView(meta);
                        Button join = button("JOIN ROOM  ›", () -> promptJoinRoom(code), true);
                        cardBody.addView(join);
                        addGlassCard(lobbyRoomsList, cardBody);
                    }
                    if (shown == 0) lobbyRoomsList.addView(text("No public rooms yet. Create one and invite a friend.", 12, Color.LTGRAY));
                });
            });
    }

    private void showCreateRoomDialog() {
        LinearLayout form = dialogContent("CREATE RACE ROOM", "PUBLIC GRID • PRIVATE GRID");
        TextView label = text("ROOM VISIBILITY", 11, Color.rgb(73, 213, 255));
        label.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        form.addView(label);
        RadioGroup visibility = new RadioGroup(this);
        visibility.setOrientation(RadioGroup.VERTICAL);
        RadioButton pub = new RadioButton(this);
        pub.setId(301); pub.setText("Public — visible in room list"); pub.setTextColor(Color.WHITE); pub.setButtonTintList(ColorStateList.valueOf(Color.rgb(47, 207, 255))); pub.setChecked(true);
        RadioButton priv = new RadioButton(this);
        priv.setId(302); priv.setText("Private — join by room code only"); priv.setTextColor(Color.WHITE); priv.setButtonTintList(ColorStateList.valueOf(Color.rgb(47, 207, 255)));
        visibility.addView(pub); visibility.addView(priv); form.addView(visibility);
        TextView passLabel = text("PASSWORD (OPTIONAL)", 11, Color.rgb(73, 213, 255));
        passLabel.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        form.addView(passLabel);
        EditText pass = input("Leave blank for no password", true);
        form.addView(pass);
        showStyledDialog("CREATE RACE ROOM", form, "CREATE ROOM", () -> {
            String mode = visibility.getCheckedRadioButtonId() == 302 ? "private" : "public";
            String password = pass.getText().toString();
            if (password.length() > 0 && password.length() < 4) {
                alert("PASSWORD TOO SHORT", "Use at least 4 characters, or leave it blank.");
                return;
            }
            createOnlineRoom(mode, password);
        }, "CANCEL", null);
    }

    private void createOnlineRoom(String visibility, String password) {
        ensureOnlineAuth(() -> {
            String uid = firebaseUid();
            if (uid.isEmpty()) { alert("ONLINE LOGIN FAILED", "No online player session."); return; }
            String code = newRoomCode();
            DocumentReference room = firestore.collection("rooms").document(code);
            Map<String, Object> data = new HashMap<>();
            data.put("roomCode", code);
            data.put("hostUid", uid);
            data.put("hostPlayerId", currentUserId);
            data.put("hostUsername", currentUsername);
            data.put("visibility", visibility);
            data.put("passwordRequired", !password.isEmpty());
            data.put("status", "waiting");
            data.put("maxPlayers", 4);
            data.put("memberUids", java.util.Collections.singletonList(uid));
            data.put("createdAt", FieldValue.serverTimestamp());
            data.put("updatedAt", FieldValue.serverTimestamp());
            room.set(data).addOnSuccessListener(unused -> {
                Task<Void> secretWrite = password.isEmpty()
                    ? Tasks.forResult(null)
                    : room.collection("secret").document("config").set(java.util.Collections.singletonMap("passwordHash", passwordHash(password, code)));
                secretWrite.continueWithTask(task -> {
                    if (!task.isSuccessful()) throw task.getException();
                    Map<String, Object> player = onlinePlayerData(uid, .50f, 0, false, false);
                    player.put("joinedAt", FieldValue.serverTimestamp());
                    return room.collection("players").document(uid).set(player);
                }).addOnSuccessListener(done -> openRoomScreen(code))
                  .addOnFailureListener(error -> alert("ROOM SETUP FAILED", "Room was created but its player record failed. Check Firestore Rules.\n\n" + error.getLocalizedMessage()));
            }).addOnFailureListener(error -> alert("CREATE ROOM FAILED", "Firestore denied the room write or the network is unavailable.\n\n" + error.getLocalizedMessage()));
        });
    }

    private void showJoinRoomDialog() {
        LinearLayout form=dialogContent("JOIN RACE ROOM","ENTER THE 6-CHARACTER ROOM CODE");
        EditText code=input("Room code",false);
        form.addView(code);
        showStyledDialog("JOIN ROOM",form,"CONTINUE",()->promptJoinRoom(code.getText().toString().trim().toUpperCase(Locale.US)),"CANCEL",null);
    }

    private void promptJoinRoom(String roomCode) {
        String code = roomCode == null ? "" : roomCode.trim().toUpperCase(Locale.US);
        if (!code.matches("[A-F0-9]{6}")) { alert("INVALID ROOM CODE", "Enter the 6-character code shown by the room host."); return; }
        ensureOnlineAuth(() -> firestore.collection("rooms").document(code).get()
            .addOnSuccessListener(room -> {
                if (!room.exists()) { alert("ROOM NOT FOUND", "Check the code or ask the host for a new one."); return; }
                if (!"waiting".equals(room.getString("status"))) { alert("RACE ALREADY STARTED", "This room is no longer waiting for players."); return; }
                List<?> members = (List<?>) room.get("memberUids");
                if (members != null && members.size() >= 4) { alert("ROOM FULL", "This room already has four players."); return; }
                String uid = firebaseUid();
                if (members != null && members.contains(uid)) { openRoomScreen(code); return; }
                boolean needsPassword = Boolean.TRUE.equals(room.getBoolean("passwordRequired"));
                if (needsPassword) {
                    LinearLayout form=dialogContent("PRIVATE GRID","PASSWORD REQUIRED TO JOIN");
                    EditText password=input("Room password",true);form.addView(password);
                    showStyledDialog("PRIVATE GRID",form,"JOIN",()->joinOnlineRoom(code,password.getText().toString()),"CANCEL",null);
                } else joinOnlineRoom(code, "");
            })
            .addOnFailureListener(error -> alert("ROOM LOOKUP FAILED", "Check Firestore Rules.\n\n" + error.getLocalizedMessage())));
    }

    private void joinOnlineRoom(String code, String password) {
        String uid = firebaseUid();
        if (uid.isEmpty()) { alert("ONLINE LOGIN FAILED", "No online player session."); return; }
        DocumentReference room = firestore.collection("rooms").document(code);
        Task<Void> proofTask = password.isEmpty() ? Tasks.forResult(null) : room.collection("joinRequests").document(uid)
            .set(new HashMap<String, Object>() {{ put("passwordHash", passwordHash(password, code)); put("requestedAt", FieldValue.serverTimestamp()); }});
        proofTask.addOnFailureListener(error -> alert("ROOM PASSWORD / RULES ERROR", "Password incorrect, or your Firestore Rules do not yet validate private-room join requests.\n\n" + error.getLocalizedMessage()));
        proofTask.addOnSuccessListener(ignored -> firestore.runTransaction(transaction -> {
            DocumentSnapshot snap = transaction.get(room);
            if (!snap.exists()) throw new IllegalStateException("Room not found.");
            if (!"waiting".equals(snap.getString("status"))) throw new IllegalStateException("Race already started.");
            List<String> ids = (List<String>) snap.get("memberUids");
            if (ids == null) ids = new ArrayList<>();
            if (ids.contains(uid)) return true;
            if (ids.size() >= 4) throw new IllegalStateException("Room is full (4/4).");
            transaction.update(room, "memberUids", FieldValue.arrayUnion(uid), "updatedAt", FieldValue.serverTimestamp());
            return true;
        }).addOnSuccessListener(ok -> {
            Map<String, Object> player = onlinePlayerData(uid, .50f, 0, false, false);
            player.put("joinedAt", FieldValue.serverTimestamp());
            room.collection("players").document(uid).set(player).addOnSuccessListener(done -> {
                room.collection("joinRequests").document(uid).delete();
                openRoomScreen(code);
            }).addOnFailureListener(error -> alert("JOIN FAILED", "Room member list updated but player setup failed. Check Firestore Rules.\n\n" + error.getLocalizedMessage()));
        }).addOnFailureListener(error -> alert("JOIN FAILED", "Could not join. The room may be full, started, or Firestore Rules need updating.\n\n" + error.getLocalizedMessage())));
    }

    private void openRoomScreen(String code) {
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
        if (roomListener != null) { roomListener.remove(); roomListener = null; }
        if (roomPlayersListener != null) { roomPlayersListener.remove(); roomPlayersListener = null; }
        currentRoomCode = code;
        roomStartHandled = false;
        remoteRacers.clear();
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("RACE ROOM");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(5), dp(2), dp(10));
        body.addView(text("ROOM CODE", 10, Color.rgb(73, 213, 255)));
        TextView codeView = text(code, 38, Color.WHITE);
        codeView.setLetterSpacing(.22f);
        body.addView(codeView);
        Button copyCode = button("SHARE ROOM CODE", () -> {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clipboard != null) clipboard.setPrimaryClip(android.content.ClipData.newPlainText("FARISS room code", code));
            alert("ROOM CODE COPIED", "Share " + code + " with your friend.");
        }, false);
        body.addView(copyCode);
        roomStatusText = text("CONNECTING TO ROOM…", 12, Color.rgb(255, 215, 100));
        body.addView(roomStatusText);
        roomCountText = text("DRIVERS  1/4", 13, Color.rgb(73, 213, 255));
        body.addView(roomCountText);
        addEyebrow(body, "DRIVER GRID");
        roomRosterText = text("Loading players…", 12, Color.WHITE);
        roomRosterText.setGravity(Gravity.TOP | Gravity.LEFT);
        roomRosterText.setPadding(dp(12), dp(12), dp(12), dp(12));
        roomRosterText.setBackground(makeRounded(Color.rgb(255,255,255), Color.rgb(225,241,255), dp(14), dp(1)));
        body.addView(roomRosterText, new LinearLayout.LayoutParams(-1, -2));
        roomStartButton = button("START RACE  •  NEED 2 PLAYERS", this::startRoomRace, true);
        roomStartButton.setEnabled(false);
        body.addView(roomStartButton);
        body.addView(text("The host can start with 2–3 drivers. At 4/4, the host starts automatically.", 10, Color.LTGRAY));
        addAction(body, "LEAVE / CLOSE ROOM", this::leaveCurrentRoom, false);
        addAction(body, "← BACK TO MENU", this::showMenu, false);
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        showOverlay(panel);

        DocumentReference ref = firestore.collection("rooms").document(code);
        roomListener = ref.addSnapshotListener((snap, error) -> {
            if (error != null) { runOnUiThread(() -> { if (roomStatusText != null) roomStatusText.setText("ROOM CONNECTION ERROR"); }); return; }
            if (snap == null || !snap.exists()) {
                runOnUiThread(() -> {
                    if (code.equals(currentRoomCode)) {
                        cleanupRoomListeners(); currentRoomCode = ""; currentRoomHostUid = "";
                        alert("ROOM CLOSED", "The host closed this room or it no longer exists.");
                        renderMultiplayerLobby();
                    }
                });
                return;
            }
            String hostUid = snap.getString("hostUid");
            String status = snap.getString("status");
            List<?> ids = (List<?>) snap.get("memberUids");
            int count = ids == null ? 0 : ids.size();
            boolean host = firebaseUid().equals(hostUid);
            runOnUiThread(() -> {
                if (!code.equals(currentRoomCode)) return;
                currentRoomHostUid = hostUid == null ? "" : hostUid;
                if (roomStatusText != null) roomStatusText.setText("STATUS  /  " + String.valueOf(status).toUpperCase(Locale.US) + (host ? "  •  HOST" : "  •  DRIVER"));
                if (roomCountText != null) roomCountText.setText("DRIVERS  " + count + "/4  •  " + (count >= 2 ? "READY TO START" : "WAITING FOR 1 MORE"));
                if (roomStartButton != null) {
                    roomStartButton.setEnabled(host && count >= 2 && "waiting".equals(status));
                    roomStartButton.setText(count >= 2 ? "START RACE  •  " + count + " DRIVERS" : "START RACE  •  NEED 2 PLAYERS");
                }
                if (host && count >= 4 && "waiting".equals(status) && !roomStartHandled) startRoomRace();
                if ("racing".equals(status) && !roomStartHandled) {
                    roomStartHandled = true;
                    startGame(true);
                }
                if ("completed".equals(status) && !inGame && roomStatusText != null) roomStatusText.setText("RACE COMPLETED  •  LEAVE OR RETURN TO MENU");
            });
        });
        roomPlayersListener = ref.collection("players").addSnapshotListener((snapshot, error) -> {
            if (error != null || snapshot == null) return;
            List<RemoteRacer> seen = new ArrayList<>();
            StringBuilder lines = new StringBuilder();
            int index = 1;
            for (QueryDocumentSnapshot doc : snapshot) {
                String uid = doc.getId();
                String name = doc.getString("username");
                if (name == null || name.trim().isEmpty()) name = "RACER";
                String id = doc.getString("playerId");
                Long scv = doc.getLong("score");
                Double ln = doc.getDouble("lane");
                Boolean racing = doc.getBoolean("isRacing");
                Boolean finished = doc.getBoolean("finished");
                RemoteRacer r = new RemoteRacer(uid, name, id == null ? "" : id, ln == null ? .5f : ln.floatValue(), scv == null ? 0 : scv.intValue(), Boolean.TRUE.equals(racing), Boolean.TRUE.equals(finished));
                seen.add(r);
                lines.append(index++).append(".  ").append(name).append(uid.equals(firebaseUid()) ? "  (YOU)" : "")
                    .append("\n    ").append(id == null ? "ONLINE DRIVER" : id)
                    .append("  •  ").append(r.finished ? "FINISHED" : r.isRacing ? "RACING" : "READY").append("\n");
            }
            synchronized (remoteRacers) {
                remoteRacers.clear();
                for (RemoteRacer r : seen) remoteRacers.put(r.uid, r);
            }
            String roster = lines.length() == 0 ? "No players connected yet." : lines.toString();
            runOnUiThread(() -> {
                if (code.equals(currentRoomCode) && roomRosterText != null) roomRosterText.setText(roster);
                if (game != null) game.invalidate();
                if (remoteOverlay != null) remoteOverlay.invalidate();
            });
        });
    }

    private void startRoomRace() {
        if (currentRoomCode.isEmpty() || firebaseUid().isEmpty()) return;
        DocumentReference room = firestore.collection("rooms").document(currentRoomCode);
        firestore.runTransaction(transaction -> {
            DocumentSnapshot snap = transaction.get(room);
            if (!snap.exists()) throw new IllegalStateException("Room no longer exists.");
            if (!firebaseUid().equals(snap.getString("hostUid"))) throw new IllegalStateException("Only the room host can start the race.");
            if (!"waiting".equals(snap.getString("status"))) return false;
            List<?> ids = (List<?>) snap.get("memberUids");
            if (ids == null || ids.size() < 2) throw new IllegalStateException("At least 2 players are required.");
            transaction.update(room, "status", "racing", "startedAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp());
            return true;
        }).addOnSuccessListener(started -> {
            if (Boolean.TRUE.equals(started) && !roomStartHandled) {
                roomStartHandled = true;
                startGame(true);
            }
        }).addOnFailureListener(error -> alert("CAN'T START RACE", error.getLocalizedMessage() == null ? "Check room members and Firestore Rules." : error.getLocalizedMessage()));
    }

    private void leaveCurrentRoom() {
        String code = currentRoomCode;
        String uid = firebaseUid();
        if (code.isEmpty() || uid.isEmpty()) { cleanupRoomListeners(); currentRoomCode = ""; showMultiplayerLobby(); return; }
        DocumentReference room = firestore.collection("rooms").document(code);
        room.get().addOnSuccessListener(doc -> {
            if (!doc.exists()) { finishLeaveRoom(); return; }
            String host = doc.getString("hostUid");
            if (uid.equals(host)) {
                room.collection("players").get().addOnSuccessListener(players -> {
                    List<Task<?>> tasks = new ArrayList<>();
                    for (DocumentSnapshot player : players.getDocuments()) tasks.add(player.getReference().delete());
                    tasks.add(room.collection("secret").document("config").delete());
                    Tasks.whenAllComplete(tasks).addOnCompleteListener(done -> room.delete().addOnCompleteListener(deleted -> finishLeaveRoom()));
                }).addOnFailureListener(error -> alert("CLOSE ROOM FAILED", error.getLocalizedMessage()));
            } else {
                room.update("memberUids", FieldValue.arrayRemove(uid), "updatedAt", FieldValue.serverTimestamp())
                    .addOnSuccessListener(done -> room.collection("players").document(uid).delete().addOnCompleteListener(ignored ->
                        room.collection("joinRequests").document(uid).delete().addOnCompleteListener(ignored2 -> finishLeaveRoom())))
                    .addOnFailureListener(error -> alert("LEAVE ROOM FAILED", "The room may already be closed or Firestore Rules need updating.\n\n" + error.getLocalizedMessage()));
            }
        }).addOnFailureListener(error -> alert("LEAVE ROOM FAILED", error.getLocalizedMessage()));
    }

    private void finishLeaveRoom() {
        cleanupRoomListeners();
        currentRoomCode = "";
        currentRoomHostUid = "";
        multiplayerRace = false;
        if (remoteOverlay != null) remoteOverlay.invalidate();
        roomStartHandled = false;
        remoteRacers.clear();
        roomRosterText = null; roomCountText = null; roomStatusText = null; roomStartButton = null;
        lobbyRoomsList = null;
        showMultiplayerLobby();
    }

    private void cleanupRoomListeners() {
        if (roomListener != null) { roomListener.remove(); roomListener = null; }
        if (roomPlayersListener != null) { roomPlayersListener.remove(); roomPlayersListener = null; }
        if (publicRoomsListener != null) { publicRoomsListener.remove(); publicRoomsListener = null; }
    }

    private void publishMultiplayerState(boolean finished) {
        if (!multiplayerRace || currentRoomCode.isEmpty() || firebaseUid().isEmpty()) return;
        long now = System.currentTimeMillis();
        if (!finished && now - lastMultiplayerWriteMs < 650) return;
        lastMultiplayerWriteMs = now;
        Map<String, Object> data = onlinePlayerData(firebaseUid(), multiplayerLane, nativeScore(), inGame && !finished, finished);
        firestore.collection("rooms").document(currentRoomCode).collection("players").document(firebaseUid()).set(data, SetOptions.merge())
            .addOnFailureListener(error -> android.util.Log.w("FRISS-MULTIPLAYER", "Presence update failed: " + error.getMessage()));
    }

    private void publishMultiplayerFinish(int score) {
        publishMultiplayerState(true);
        if (!currentRoomCode.isEmpty() && firebaseUid().equals(currentRoomHostUid)) {
            firestore.collection("rooms").document(currentRoomCode).update("status", "completed", "updatedAt", FieldValue.serverTimestamp())
                .addOnFailureListener(error -> android.util.Log.w("FRISS-MULTIPLAYER", "Room completion update failed: " + error.getMessage()));
        }
    }

    private void drawRemoteRacers(Canvas canvas, int width, int height) {
        List<RemoteRacer> racers;
        synchronized (remoteRacers) { racers = new ArrayList<>(remoteRacers.values()); }
        int localScore = nativeScore();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        int drawn = 0;
        for (RemoteRacer racer : racers) {
            if (racer.uid.equals(firebaseUid()) || drawn >= 3) continue;
            float delta = Math.max(-900f, Math.min(900f, racer.score - localScore));
            float y = height * (0.605f - delta / 900f * 0.055f);
            float x = width * (0.145f + 0.71f * Math.max(.15f, Math.min(.85f, racer.lane)));
            float carW = width * .095f, carH = height * .115f;
            if (rivalSprite != null) canvas.drawBitmap(rivalSprite, null,
                new android.graphics.RectF(x - carW / 2f, y, x + carW / 2f, y + carH), paint);
            paint.setColor(Color.rgb(90, 225, 255));
            paint.setTextSize(dp(10));
            paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            canvas.drawText(racer.username.toUpperCase(Locale.US), x, y - dp(5), paint);
            paint.setColor(Color.WHITE);
            drawn++;
        }
    }

    private void saveOnlineLeaderboard(int score) {
        ensureOnlineAuth(() -> {
            String uid = firebaseUid();
            if (uid.isEmpty()) return;
            DocumentReference ref = firestore.collection("leaderboard").document(uid);
            firestore.runTransaction(transaction -> {
                DocumentSnapshot snap = transaction.get(ref);
                long oldScore = snap.exists() && snap.getLong("bestScore") != null ? snap.getLong("bestScore") : 0L;
                Map<String, Object> data = new HashMap<>();
                data.put("uid", uid);
                data.put("playerId", currentUserId);
                data.put("username", currentUsername);
                data.put("bestScore", Math.max(oldScore, Math.max(0, score)));
                data.put("lastScore", Math.max(0, score));
                data.put("updatedAt", FieldValue.serverTimestamp());
                transaction.set(ref, data, SetOptions.merge());
                return null;
            }).addOnFailureListener(error -> android.util.Log.w("FRISS-LEADERBOARD", "Save failed: " + error.getMessage()));
        });
    }

    private void loadGlobalLeaderboard(LinearLayout entries, TextView status) {
        entries.removeAllViews();
        status.setText("CONNECTING TO GLOBAL LEADERBOARD…");
        ensureOnlineAuth(() -> firestore.collection("leaderboard")
            .orderBy("bestScore", Query.Direction.DESCENDING).limit(50).get()
            .addOnSuccessListener(snapshot -> {
                entries.removeAllViews();
                if (snapshot.isEmpty()) {
                    status.setText("NO SCORES YET  •  BE THE FIRST DRIVER");
                    return;
                }
                status.setText("GLOBAL TOP " + snapshot.size() + " DRIVERS  •  LIVE FIRESTORE DATA");
                int rank = 1;
                for (QueryDocumentSnapshot doc : snapshot) {
                    String name = doc.getString("username"); if (name == null || name.isEmpty()) name = "DRIVER";
                    Long best = doc.getLong("bestScore");
                    String playerId = doc.getString("playerId");
                    LinearLayout row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    TextView badge = text(rank <= 3 ? new String[]{"🥇","🥈","🥉"}[rank-1] : String.valueOf(rank), 13,
                        rank == 1 ? Color.rgb(224, 155, 0) : Color.rgb(38, 112, 198));
                    badge.setBackground(makeRounded(Color.rgb(231,244,255), Color.rgb(210,231,255), dp(12), dp(1)));
                    row.addView(badge, new LinearLayout.LayoutParams(dp(42), dp(42)));
                    LinearLayout identity = new LinearLayout(this);
                    identity.setOrientation(LinearLayout.VERTICAL);
                    TextView title = text(name.toUpperCase(Locale.US), 13, rank == 1 ? Color.rgb(179, 119, 0) : Color.rgb(17, 56, 96));
                    title.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                    TextView meta = text(playerId == null ? "ONLINE DRIVER" : playerId, 9, Color.rgb(110, 132, 159));
                    meta.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                    identity.addView(title); identity.addView(meta);
                    row.addView(identity, new LinearLayout.LayoutParams(0, -2, 1));
                    TextView scoreText = text(String.format(Locale.US, "%,d", best == null ? 0 : best), 14, Color.rgb(0, 125, 212));
                    row.addView(scoreText);
                    addGlassCard(entries, row);
                    rank++;
                }
            })
            .addOnFailureListener(error -> {
                status.setText("GLOBAL BOARD UNAVAILABLE  •  CHECK FIRESTORE RULES");
                entries.removeAllViews();
                entries.addView(text("GLOBAL BOARD UNAVAILABLE — LOCAL HISTORY BELOW", 11, Color.rgb(255, 170, 145)));
                String localRaw = prefs.getString("local_scores", "");
                if (localRaw.isEmpty()) {
                    entries.addView(text("No local races recorded yet.", 11, Color.LTGRAY));
                } else {
                    String[] localScores = localRaw.split(",");
                    for (int i = 0; i < localScores.length; i++) {
                        TextView localRow = text(String.format(Locale.US, "%02d   %s   •   %s", i + 1, currentUsername, localScores[i]), 12, i == 0 ? Color.rgb(255, 214, 92) : Color.WHITE);
                        localRow.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
                        entries.addView(localRow);
                    }
                }
                entries.addView(text("Online scores are saved once Firebase Anonymous sign-in and Firestore Rules are configured.\n" + error.getLocalizedMessage(), 10, Color.rgb(154, 183, 207)));
            }));
    }

    private void showLeaderboard() {
        inGame = false; nativePause(true); stopEngineSound();
        LinearLayout panel = makePanel("");
        LinearLayout heading = new LinearLayout(this);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.addView(text("🏆", 25, Color.rgb(224,155,0)));
        heading.addView(text("GLOBAL TOP DRIVERS", 21, Color.rgb(15,49,86)));
        panel.addView(heading);
        TextView status = text("CONNECTING TO GLOBAL LEADERBOARD…", 10, Color.rgb(0,133,205));
        panel.addView(status);
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(4), dp(2), dp(10));
        LinearLayout entries = new LinearLayout(this);
        entries.setOrientation(LinearLayout.VERTICAL);
        body.addView(entries);
        sc.addView(body);
        panel.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));
        addAction(panel, "↻  REFRESH GLOBAL RANKINGS", () -> loadGlobalLeaderboard(entries, status), false);
        addAction(panel, "← BACK TO MENU", this::showMenu, false);
        showOverlay(panel);
        loadGlobalLeaderboard(entries, status);
    }

    private void showTopUp() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("COIN TOP-UP");
        ScrollView sc = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout playerCard = new LinearLayout(this); playerCard.setOrientation(LinearLayout.VERTICAL);
        TextView player = text("PLAYER  " + currentUsername,13,Color.rgb(20,67,111)); player.setGravity(Gravity.LEFT);
        TextView id = text("PLAYER ID  " + currentUserId,10,Color.rgb(98,125,155)); id.setGravity(Gravity.LEFT);
        playerCard.addView(player); playerCard.addView(id); addGlassCard(body,playerCard);
        TextView wallet = text("🪙  CURRENT WALLET  " + prefs.getInt("bank_coins",0) + " COINS",16,Color.rgb(184,126,0));
        wallet.setBackground(makeRounded(Color.rgb(255,249,224),Color.rgb(255,238,189),dp(16),dp(1)));
        LinearLayout.LayoutParams walletP = new LinearLayout.LayoutParams(-1,dp(54)); walletP.setMargins(0,dp(6),0,dp(8)); body.addView(wallet,walletP);
        body.addView(text("MANUAL TOP-UP  •  TELEGRAM CHAT",11,Color.rgb(0,129,203)));
        body.addView(text("Pilih paket untuk mengirim pesanan ke chat FRISS. Harga dan cara pembayaran dikonfirmasi admin lewat Telegram.",10,Color.rgb(91,117,146)));
        addTopupPackage(body,500,"COINS  •  STARTER PACK");
        addTopupPackage(body,1500,"COINS  •  BOOST PACK");
        addTopupPackage(body,5000,"COINS  •  PRO PACK");
        body.addView(text("Koin belum otomatis bertambah setelah membuka chat. Admin harus mengecek pembayaran dan mengkreditkan koin.",9,Color.rgb(106,128,153)));
        addAction(body,"← BACK TO MENU",this::showMenu,false);
        sc.addView(body); panel.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }
    private void addTopupPackage(LinearLayout parent,int coins,String label) {
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = text(coins>=5000?"💎":"🪙",26,Color.rgb(195,137,0));
        row.addView(icon,new LinearLayout.LayoutParams(dp(52),dp(52)));
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        info.addView(text(String.format(Locale.US,"%,d",coins),17,Color.rgb(15,55,95)));
        info.addView(text(label,9,Color.rgb(101,127,157)));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button order = button("ORDER  ›",()->sendTelegramTopupOrder(coins),true); order.setTextSize(10);
        row.addView(order,new LinearLayout.LayoutParams(dp(112),dp(47)));
        addGlassCard(parent,row);
    }

    private void sendTelegramTopupOrder(int coinAmount) {
        String message = "Halo FRISS! Saya mau top up FARISS RACING GAME.\n"
            + "Username: " + currentUsername + "\n"
            + "Player ID: " + currentUserId + "\n"
            + "Paket: " + String.format(Locale.US, "%,d", coinAmount) + " koin\n"
            + "Status: belum membayar\n"
            + "Mohon konfirmasi harga dan metode pembayaran sebelum saya membayar.";
        openExternal(TELEGRAM_URL + "?text=" + Uri.encode(message));
    }

    // -------------------- Local demo administration --------------------
    private void askAdminPin() {
        LinearLayout content = dialogContent("ADMIN ACCESS", "LOCAL DEMO • DEVICE DATA ONLY");
        EditText pin = input("Enter admin PIN", true);
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        TextView shield = text("♜", 42, Color.rgb(45, 205, 255));
        content.addView(shield, new LinearLayout.LayoutParams(-1, dp(58)));
        content.addView(text("ADMIN ACCESS", 23, Color.WHITE));
        content.addView(text("PIN demo hanya mengelola data lokal pada perangkat ini.", 12, Color.rgb(177, 202, 229)));
        addInput(content, pin);
        showStyledDialog("ADMIN ACCESS", content, "OPEN", () -> {
            if (ADMIN_PIN.equals(pin.getText().toString())) showAdminDashboard();
            else alert("ACCESS DENIED", "PIN tidak sesuai. Coba lagi.");
        }, "CANCEL", null);
    }

    private void showAdminDashboard() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("");
        lightUi = false;
        panel.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.argb(235,5,18,43), Color.argb(232,7,27,58), Color.argb(238,3,11,27)}));
        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(2), dp(8), dp(2), dp(16));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 34, Color.WHITE);
        back.setBackground(makeRounded(Color.rgb(20,48,82),Color.rgb(7,19,38),dp(14),dp(1)));
        header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(46)));
        back.setOnClickListener(v -> showMenu());
        TextView title = text("ADMIN DASHBOARD", 23, Color.WHITE);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(12),0,0,0);
        header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView gear = text("⚙", 23, Color.rgb(70,210,255));
        header.addView(gear,new LinearLayout.LayoutParams(dp(44),dp(44)));
        body.addView(header);
        body.addView(text("FARISS MOTORSPORTS  •  SEASON 01\nLOCAL DEVICE ONLY  •  NOT SHARED ONLINE",10,Color.rgb(93,205,255)));

        LinearLayout searchCard = adminCard();
        searchCard.addView(text("⌕  SEARCH PLAYER ID",11,Color.rgb(90,205,255)));
        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        adminIdInput=input("FRS-XXXXXXXX",false);
        LinearLayout.LayoutParams searchInputP = new LinearLayout.LayoutParams(0, -2, 1);
        searchInputP.setMargins(0, 0, dp(7), 0);
        searchRow.addView(adminIdInput, searchInputP);
        Button lookup = button("⌕", this::lookupAdminTarget, true);
        searchRow.addView(lookup, new LinearLayout.LayoutParams(dp(54), dp(50)));
        searchCard.addView(searchRow);
        body.addView(searchCard);

        LinearLayout targetCard=adminCard();
        targetCard.addView(text("PLAYER DETAILS",10,Color.rgb(90,205,255)));
        adminTargetSummary=text("No player selected\nCari Player ID untuk melihat data.",13,Color.WHITE);
        adminTargetSummary.setGravity(Gravity.CENTER_VERTICAL);
        adminTargetSummary.setMinHeight(dp(76));
        targetCard.addView(adminTargetSummary);
        body.addView(targetCard);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        addAdminButton(actions,"⛔ BAN",()->changeBanState(true),Color.rgb(208,43,78),Color.rgb(116,22,53),true);
        addAdminButton(actions,"🔓 UNBAN",()->changeBanState(false),Color.rgb(239,153,24),Color.rgb(171,91,8),true);
        body.addView(actions);

        LinearLayout coinCard=adminCard();
        coinCard.addView(text("🪙  ADD CUSTOM COINS TO PLAYER ID",13,Color.rgb(90,205,255)));
        coinCard.addView(text("Credit only after payment is confirmed.",10,Color.rgb(177,202,229)));
        adminCoinAmountInput=input("1000",false);
        adminCoinAmountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        adminCoinAmountInput.setText("1000");
        addInput(coinCard,adminCoinAmountInput);
        LinearLayout presets=new LinearLayout(this);presets.setOrientation(LinearLayout.HORIZONTAL);
        addCoinPreset(presets,"+100",100); addCoinPreset(presets,"+500",500);
        addCoinPreset(presets,"+1,000",1000); addCoinPreset(presets,"+5,000",5000);
        coinCard.addView(presets);
        addAdminButton(coinCard,"➤  ADD COINS",this::askAdminCreditAmount,Color.rgb(0,174,255),Color.rgb(24,83,222));
        body.addView(coinCard);

        LinearLayout playersCard=adminCard();
        playersCard.addView(text("♟  REGISTERED PLAYERS (LOCAL)",13,Color.WHITE));
        playersCard.addView(text("#   PLAYER NAME / PLAYER ID                         COINS       STATUS",8,Color.rgb(83,190,235)));
        JSONArray players=getPlayers();
        if(players.length()==0) playersCard.addView(text("No local players registered.",12,Color.LTGRAY));
        for(int i=0;i<players.length();i++) {
            JSONObject player=players.optJSONObject(i); if(player==null) continue;
            String id=player.optString("id");
            int coins=getSharedPreferences("player_"+id,MODE_PRIVATE).getInt("bank_coins",0);
            boolean banned=player.optBoolean("banned");
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(6),dp(8),dp(6),dp(8));
            row.setBackground(makeRounded(Color.rgb(18,43,72),Color.rgb(9,24,45),dp(10),dp(1)));
            TextView rank=text(String.valueOf(i+1),10,Color.WHITE);
            rank.setBackground(makeRounded(Color.rgb(25,75,122),Color.rgb(8,37,73),dp(8),dp(1)));
            row.addView(rank,new LinearLayout.LayoutParams(dp(29),dp(31)));
            LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
            info.addView(text(player.optString("username","Player"),11,Color.WHITE));
            info.addView(text(id,8,Color.rgb(155,190,220)));
            LinearLayout.LayoutParams infoP=new LinearLayout.LayoutParams(0,-2,1);infoP.setMargins(dp(6),0,dp(2),0);row.addView(info,infoP);
            row.addView(text(String.format(Locale.US,"%,d",coins),9,Color.rgb(255,208,91)));
            TextView status=text(banned?"BANNED":"ACTIVE",8,banned?Color.rgb(255,115,130):Color.rgb(62,230,177));
            row.addView(status);
            row.setOnClickListener(v->{adminIdInput.setText(id);lookupAdminTarget();});
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.setMargins(0,dp(4),0,dp(4));playersCard.addView(row,rp);
        }
        body.addView(playersCard);
        LinearLayout infoCard=adminCard();
        infoCard.addView(text("ⓘ  INFORMATION",13,Color.rgb(40,194,255)));
        infoCard.addView(text("Semua data admin dan pemain pada dashboard ini masih tersimpan di perangkat ini. Perubahan tidak dibagikan ke perangkat lain.",11,Color.rgb(180,205,230)));
        body.addView(infoCard);
        addAdminButton(body,"←  BACK TO MENU",this::showMenu,Color.rgb(30,57,91),Color.rgb(8,21,40));
        scroll.addView(body); panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }

    private void addCoinPreset(LinearLayout row,String label,int amount) {
        Button b=button(label,()->{if(adminCoinAmountInput!=null)adminCoinAmountInput.setText(String.valueOf(amount));},false);
        b.setTextSize(9); b.setMinHeight(dp(40));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);
        p.setMargins(dp(2),dp(3),dp(2),dp(3));row.addView(b,p);
    }
    private LinearLayout adminCard() {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(13),dp(11),dp(13),dp(11));
        card.setBackground(makeRounded(Color.rgb(17,43,74),Color.rgb(7,20,39),dp(17),dp(1)));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,dp(6),0,dp(6));
        return card;
    }
    private void addAdminButton(LinearLayout parent,String label,Runnable action,int top,int bottom) {
        addAdminButton(parent,label,action,top,bottom,false);
    }
    private void addAdminButton(LinearLayout parent,String label,Runnable action,int top,int bottom,boolean weighted) {
        Button b=button(label,action,true); b.setTextSize(11); b.setMinHeight(dp(48));
        b.setBackground(makeRounded(top,bottom,dp(13),dp(1)));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(weighted?0:-1,dp(48),weighted?1:0);
        bp.setMargins(dp(3),dp(4),dp(3),dp(4)); parent.addView(b,bp);
    }
    private String adminTypedId() { return adminIdInput==null?"":adminIdInput.getText().toString().trim().toUpperCase(Locale.US); }
    private void lookupAdminTarget() {
        String id=adminTypedId(); JSONObject p=findPlayerById(id);
        if(p==null) { adminTargetSummary.setText("No player selected\nPlayer ID tidak ditemukan di perangkat ini."); return; }
        adminTargetSummary.setText("♟  "+p.optString("username")+"\nID: "+p.optString("id")+"\nSTATUS: "+(p.optBoolean("banned")?"BANNED":"ACTIVE")+"\nWALLET: "+getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE).getInt("bank_coins",0)+" COINS");
    }
    private void changeBanState(boolean ban) {
        String id=adminTypedId(); JSONArray players=getPlayers(); boolean found=false; String name="";
        for(int i=0;i<players.length();i++){ JSONObject p=players.optJSONObject(i); if(p!=null&&p.optString("id").equalsIgnoreCase(id)){ try{p.put("banned",ban);name=p.optString("username");found=true;}catch(JSONException ignored){} break; } }
        if(!found){alert("PLAYER NOT FOUND","Masukkan Player ID yang terdaftar di perangkat ini.");return;}
        savePlayers(players); lookupAdminTarget();
        alert(ban?"PLAYER BANNED":"PLAYER UNBANNED",name+" telah "+(ban?"diblokir":"diaktifkan kembali")+" pada database lokal perangkat ini.");
    }
    private void askAdminCreditAmount() {
        String id=adminTypedId(); JSONObject p=findPlayerById(id);
        if(p==null){alert("PLAYER NOT FOUND","Select a registered player or enter its Player ID first.");return;}
        if(adminCoinAmountInput!=null) {
            String raw=adminCoinAmountInput.getText().toString().trim();
            int amount;
            try { amount=Integer.parseInt(raw); } catch(Exception ex) { alert("INVALID AMOUNT","Enter a coin amount as a number."); return; }
            if(amount<=0 || amount>10000000){alert("INVALID AMOUNT","Jumlah harus 1 sampai 10.000.000 koin.");return;}
            creditPlayerLocally(p,amount);
            return;
        }
        LinearLayout content=dialogContent("CREDIT PLAYER WALLET","LOCAL WALLET • PAYMENT CHECK REQUIRED");
        EditText amountInput=input("Coins to add (e.g. 1000)",false); amountInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        content.addView(text("🪙",36,Color.rgb(255,196,55)));
        content.addView(text("Tambah koin untuk "+p.optString("username"),13,Color.WHITE)); addInput(content,amountInput);
        showStyledDialog("CREDIT WALLET",content,"ADD COINS",()->{
            String raw=amountInput.getText().toString().trim(); int amount;
            try { amount=Integer.parseInt(raw); } catch(Exception ex) { alert("INVALID AMOUNT","Masukkan jumlah koin berupa angka."); return; }
            if(amount<=0 || amount>10000000){alert("INVALID AMOUNT","Jumlah harus 1 sampai 10.000.000 koin.");return;}
            creditPlayerLocally(p,amount);
        },"CANCEL",null);
    }
    private void creditPlayerLocally(JSONObject p, int amount) {
        SharedPreferences target=getSharedPreferences("player_"+p.optString("id"),MODE_PRIVATE);
        int oldCoins=target.getInt("bank_coins",0);
        if(Integer.MAX_VALUE-oldCoins<amount){alert("WALLET LIMIT","Jumlah melebihi batas saldo.");return;}
        target.edit().putInt("bank_coins",oldCoins+amount).putInt("admin_credit_count",target.getInt("admin_credit_count",0)+1)
            .putString("last_admin_credit",System.currentTimeMillis()+":"+amount).apply();
        lookupAdminTarget();
        alert("COINS ADDED","+"+String.format(Locale.US,"%,d",amount)+" coins untuk "+p.optString("username")+" ("+p.optString("id")+").\n\nData tersimpan lokal di perangkat ini.");
    }

    private void showDeveloper() {
        inGame=false; nativePause(true); stopEngineSound(); LinearLayout panel=makePanel("");
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setGravity(Gravity.CENTER_HORIZONTAL);
        body.setPadding(dp(12),dp(18),dp(12),dp(18));
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.logo_neon_racer); styleBrandLogo(logo); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        body.addView(logo,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout nameRow=new LinearLayout(this); nameRow.setGravity(Gravity.CENTER); nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.addView(text("FARIS",34,Color.WHITE)); nameRow.addView(text(" ✓ ",22,Color.rgb(70,145,255))); body.addView(nameRow);
        body.addView(text("NEON RACER • DEVELOPER",12,Color.LTGRAY));
        LinearLayout.LayoutParams contactP=new LinearLayout.LayoutParams(-1,-2); contactP.setMargins(0,dp(20),0,dp(6)); body.addView(text("SOCIALS:",14,Color.WHITE),contactP);
        addAction(body,"♪  TIKTOK  •  @frissanjaymabar",()->openExternal(TIKTOK_URL),false);
        addAction(body,"◎  INSTAGRAM  •  @frisswho",()->openExternal(INSTAGRAM_URL),false);
        addAction(body,"➤  TELEGRAM  •  @farisisheree",()->openExternal(TELEGRAM_URL),false);
        addAction(body,"← BACK TO MENU",this::showMenu,true);
        scroll.addView(body); panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); showOverlay(panel);
    }
    private void openExternal(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { alert("Cannot open link",url); }
    }
    private void showSettings() {
        inGame=false; nativePause(true); stopEngineSound();
        LinearLayout panel=makePanel("SETTINGS & AUDIO");
        addSettingCard(panel,"🎵  BACKGROUND MUSIC","Dashboard and race soundtrack", "MUSIC: "+(musicOn?"ON":"OFF"),()->{musicOn=!musicOn;prefs.edit().putBoolean("music_on",musicOn).apply();applyMusicSetting();showSettings();});
        addSettingCard(panel,"🔊  SOUND EFFECTS","Click / NOS / coin / crash / engine", "SOUND FX: "+(soundOn?"ON":"OFF"),()->{soundOn=!soundOn;prefs.edit().putBoolean("sound_on",soundOn).apply();if(!soundOn)stopEngineSound();else if(inGame)startEngineSound();showSettings();});
        addSettingCard(panel,"✨  VISUAL EFFECTS","Neon lighting and racing effects", "EFFECTS: "+(effectsOn?"ON":"OFF"),()->{effectsOn=!effectsOn;prefs.edit().putBoolean("effects_on",effectsOn).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();});
        String[] weatherNames={"CLEAR NIGHT","RAINY CITY","FOG MODE"};
        addSettingCard(panel,"🌧  WEATHER","Change the race environment",weatherNames[Math.max(0,Math.min(2,weatherMode))],()->{weatherMode=(weatherMode+1)%3;prefs.edit().putInt("weather_mode",weatherMode).apply();nativeSetWeather(weatherMode);showSettings();});
        addSettingCard(panel,"🕹  CONTROL LAYOUT","Choose your preferred driving side", "LEFT-HANDED: "+(leftHanded?"ON":"OFF"),()->{leftHanded=!leftHanded;prefs.edit().putBoolean("left_handed",leftHanded).apply();nativeSetOptions(effectsOn,leftHanded);showSettings();});
        addGlassCard(panel,text("GAME INFO\nOriginal procedural electronic soundtrack  •  Offline mode supported",10,Color.rgb(89,116,148)));
        addAction(panel,"← BACK TO MENU",this::showMenu,false); showOverlay(panel);
    }
    private void addSettingCard(LinearLayout parent,String title,String desc,String state,Runnable action) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        TextView h=text(title,13,Color.rgb(17,59,101));h.setGravity(Gravity.LEFT);card.addView(h);
        TextView d=text(desc,9,Color.rgb(101,127,155));d.setGravity(Gravity.LEFT);card.addView(d);
        addAction(card,state,action,true); addGlassCard(parent,card);
    }

    private LinearLayout dialogContent(String title, String subtitle) {
        dialogReturnLightUi = lightUi;
        lightUi = false;
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18),dp(15),dp(18),dp(8)); box.setBackground(makeRounded(Color.rgb(16,39,69),Color.rgb(5,14,29),dp(20),dp(1)));
        TextView h=text(title,18,Color.WHITE); h.setGravity(Gravity.CENTER); box.addView(h);
        TextView sub=text(subtitle,10,Color.rgb(66,207,255)); sub.setGravity(Gravity.CENTER); box.addView(sub);
        return box;
    }
    private void showStyledDialog(String title, View content, String positive, Runnable yes, String negative, Runnable no) {
        LinearLayout wrapper=new LinearLayout(this); wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(6),dp(6),dp(6),dp(6)); wrapper.addView(content);
        LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(wrapper).create();
        Button cancel=button(negative,()->{dialog.dismiss();lightUi=dialogReturnLightUi;if(no!=null)no.run();},false);
        Button open=button(positive,()->{dialog.dismiss();lightUi=dialogReturnLightUi;if(yes!=null)yes.run();},true);
        cancel.setTextSize(11);open.setTextSize(11);
        actions.addView(cancel,new LinearLayout.LayoutParams(0,dp(48),1));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(48),1)); wrapper.addView(actions);
        dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);});
        dialog.setOnDismissListener(d -> lightUi = dialogReturnLightUi);
        dialog.show();
    }
    private void showCustomActions(LinearLayout content,String[] labels,Runnable[] actions) {
        LinearLayout wrapper=new LinearLayout(this); wrapper.setOrientation(LinearLayout.VERTICAL);
        wrapper.setPadding(dp(6),dp(6),dp(6),dp(6)); wrapper.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(wrapper).create();
        for(int i=0;i<labels.length;i++) {
            final Runnable action=actions[i];
            Button b=button(labels[i],()->{dialog.dismiss();lightUi=dialogReturnLightUi;if(action!=null)action.run();},i==0);
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(48));bp.setMargins(dp(3),dp(4),dp(3),dp(4));wrapper.addView(b,bp);
        }
        dialog.setCancelable(false);
        dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);});
        dialog.setOnDismissListener(d -> lightUi = dialogReturnLightUi);
        dialog.show();
    }
    private void alert(String title,String message) {
        LinearLayout content=dialogContent(title,"NEON RACER • SYSTEM MESSAGE");
        String normalized=title==null?"":title.toUpperCase(Locale.US);
        boolean failed=normalized.contains("FAIL")||normalized.contains("ERROR")||normalized.contains("DENIED")||normalized.contains("INVALID")||normalized.contains("NOT FOUND");
        TextView emblem=text(failed?"⚠":"✓",34,failed?Color.rgb(255,105,120):Color.rgb(48,214,255));
        content.addView(emblem,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView msg=text(message,13,Color.rgb(205,222,240)); msg.setGravity(Gravity.CENTER); msg.setPadding(dp(6),dp(10),dp(6),dp(12)); content.addView(msg);
        LinearLayout wrapper=new LinearLayout(this);wrapper.setOrientation(LinearLayout.VERTICAL);wrapper.setPadding(dp(6),dp(6),dp(6),dp(6));wrapper.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setView(wrapper).create();
        Button ok=button("GOT IT",dialog::dismiss,true);LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(-1,dp(48));op.setMargins(dp(3),dp(5),dp(3),dp(3));wrapper.addView(ok,op);
        dialog.setOnShowListener(x->{if(dialog.getWindow()!=null)dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);});
        dialog.setOnDismissListener(d -> lightUi = dialogReturnLightUi);
        dialog.show();
    }

    @Override protected void onPause() {
        super.onPause(); if(game!=null){if(inGame)nativePause(true);game.onPause();} stopEngineSound(); stopNitroSound();
        if(backgroundMusic!=null&&backgroundMusic.isPlaying())backgroundMusic.pause();
    }
    @Override protected void onResume() {
        super.onResume(); immersive(); if(game!=null){game.onResume();if(inGame&&!pauseDialogOpen){nativePause(false);startEngineSound();}} applyMusicSetting();
    }
    @Override protected void onDestroy() {
        cleanupRoomListeners();
        if(backgroundMusic!=null){try{backgroundMusic.stop();}catch(Exception ignored){}backgroundMusic.release();backgroundMusic=null;}
        if(soundPool!=null){soundPool.release();soundPool=null;} super.onDestroy();
    }

    private static class RemoteRacer {
        final String uid, username, playerId;
        final float lane;
        final int score;
        final boolean isRacing, finished;
        RemoteRacer(String uid, String username, String playerId, float lane, int score, boolean isRacing, boolean finished) {
            this.uid = uid; this.username = username; this.playerId = playerId; this.lane = lane;
            this.score = score; this.isRacing = isRacing; this.finished = finished;
        }
    }

    private class AnimatedBackdrop extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final boolean light;
        private long bornAt = System.currentTimeMillis();
        AnimatedBackdrop(boolean light) { super(MainActivity.this); this.light = light; setLayerType(View.LAYER_TYPE_HARDWARE, null); setClickable(false); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            int w = getWidth(), h = getHeight();
            canvas.drawColor(light ? Color.rgb(228, 241, 255) : Color.rgb(3, 8, 20));
            float phase = ((System.currentTimeMillis() - bornAt) % 9000L) / 9000f;
            float x1 = w * (.12f + .76f * phase);
            float y1 = h * (.18f + .10f * (float)Math.sin(phase * Math.PI * 2));
            paint.setShader(new RadialGradient(x1, y1, Math.max(w, h) * .58f,
                new int[]{light ? Color.argb(72, 50, 169, 255) : Color.argb(58, 0, 180, 255), Color.argb(0, 0, 180, 255)}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(new RadialGradient(w * (.78f - .35f * phase), h * .78f, Math.max(w, h) * .48f,
                new int[]{light ? Color.argb(36, 84, 126, 255) : Color.argb(42, 111, 53, 255), Color.argb(0, 111, 53, 255)}, null, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setShader(null);
            paint.setStrokeWidth(dp(1));
            paint.setColor(light ? Color.argb(30, 30, 135, 220) : Color.argb(24, 89, 218, 255));
            float scan = (phase * h * 1.45f) % h;
            canvas.drawLine(0, scan, w, scan, paint);
            paint.setStrokeWidth(dp(2));
            paint.setColor(light ? Color.argb(23, 20, 102, 190) : Color.argb(35, 50, 208, 255));
            for (int i = -2; i < 5; i++) {
                float xx = (i * w * .31f + phase * w * .45f) % (w + 1);
                canvas.drawLine(xx, 0, xx - w * .25f, h, paint);
            }
            paint.setColor(light ? Color.argb(20, 255, 255, 255) : Color.argb(12, 255, 255, 255));
            paint.setStrokeWidth(dp(1));
            for (int y = dp(24); y < h; y += dp(38)) canvas.drawLine(0, y, w, y, paint);
            postInvalidateDelayed(40);
        }
    }

    private class RemoteOverlayView extends View {
        private final Paint remotePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        RemoteOverlayView(){ super(MainActivity.this); setWillNotDraw(false); }
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            if(inGame && multiplayerRace){ drawRemoteRacers(canvas,getWidth(),getHeight()); postInvalidateDelayed(60); }
        }
    }

    private class GameView extends GLSurfaceView implements GLSurfaceView.Renderer {
        private float downX, downY, lastSteerX;
        private boolean swipeActive, nosTriggered;
        private long lastFrameNs = 0L, lastHudMs = 0L, lastNetworkMs = 0L;
        GameView(){
            super(MainActivity.this);
            setEGLContextClientVersion(3);
            setPreserveEGLContextOnPause(true);
            setRenderer(this);
            setRenderMode(GLSurfaceView.RENDERMODE_CONTINUOUSLY);
        }
        @Override public void onSurfaceCreated(GL10 gl, EGLConfig config){ nativeGlInit(); }
        @Override public void onSurfaceChanged(GL10 gl, int width, int height){ GLES30.glViewport(0,0,width,height); }
        @Override public void onDrawFrame(GL10 gl){
            long now=System.nanoTime();
            float dt=lastFrameNs==0L?1f/60f:Math.min(.05f,(now-lastFrameNs)/1_000_000_000f);
            lastFrameNs=now;
            if(inGame){
                nativeRenderGL(getWidth(),getHeight(),dt);
                long ms=SystemClock.elapsedRealtime();
                if(ms-lastHudMs>=100L){
                    lastHudMs=ms;
                    final int coins=nativeCoins(), speed=nativeSpeed(), score=nativeScore();
                    runOnUiThread(()->{
                        if(!inGame)return;
                        if(coins>lastSoundCoinCount){playSfx(coinSfx,.85f);lastSoundCoinCount=coins;}
                        int gear=Math.max(1,Math.min(6,1+speed/55));
                        hud.setText(currentUsername.toUpperCase(Locale.US)+"  •  G"+gear+"\nSCORE "+score+"  •  COINS "+coins);
                        speedHud.setText(String.format(Locale.US, "%03d\nKM/H", speed));
                        finishGameIfNeeded();
                    });
                }
                if(multiplayerRace && ms-lastNetworkMs>=350L){lastNetworkMs=ms;runOnUiThread(()->{if(inGame&&multiplayerRace)publishMultiplayerState(false);});}
            } else {
                GLES30.glClearColor(.035f,.055f,.095f,1f);
                GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            if(!inGame)return true;
            float x=e.getX(), y=e.getY();
            float nx=x/Math.max(1f,getWidth()), ny=y/Math.max(1f,getHeight());
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN:
                    if(ny<.14f&&nx>.72f){showPauseDialog();return true;}
                    downX=x; downY=y; lastSteerX=x; swipeActive=true; nosTriggered=false;
                    nativeTouch(nx,ny);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(!swipeActive)return true;
                    float dx=x-lastSteerX;
                    float threshold=dp(22);
                    if(Math.abs(dx)>=threshold){
                        int direction = dx<0?-1:1;
                        nativeSteer(direction);
                        multiplayerLane = Math.max(.22f, Math.min(.78f, multiplayerLane + direction * .09f));
                        lastSteerX=x;
                    }
                    if(!nosTriggered && downY-y>dp(52)){
                        nativeNitro(true); playSfx(nitroSfx,.95f); nosTriggered=true;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    swipeActive=false; nativeTouch(-1f,-1f); nativeNitro(false);
                    return true;
            }
            return true;
        }
    }

    private native void nativeGlInit();
    private native void nativeRenderGL(int width,int height,float deltaSeconds);
    private native void nativeRender(android.graphics.Canvas canvas,int width,int height,Bitmap player,Bitmap traffic,Bitmap rival,Bitmap police,Bitmap truck,Bitmap coin);
    private native void nativeTouch(float x,float y);
    private native void nativeSteer(int direction);
    private native void nativeNitro(boolean down);
    private native int nativeScore();
    private native int nativeCoins();
    private native int nativeSpeed();
    private native boolean nativeGameOver();
    private native void nativePause(boolean paused);
    private native void nativeReset();
    private native void nativeSetUpgrades(int speed,int nitro,int handling);
    private native void nativeSetCarStyle(int style);
    private native void nativeSetOptions(boolean effects,boolean leftHanded);
    private native void nativeSetWeather(int mode);
}
