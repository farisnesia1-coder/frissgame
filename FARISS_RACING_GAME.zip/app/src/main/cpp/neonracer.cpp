#include <jni.h>
#include <algorithm>
#include <cmath>
#include <vector>

struct Entity {
    float x, y, w, h, phase;
    int type;       // 0 traffic, 1 coin, 2 rival, 3 truck
    bool active;
    bool rewarded;
};

static float carX = 0.5f, roadScroll = 0.f, chase = 0.f, policeX = 0.5f;
static float nitroEnergy = 1.f;
static int score = 0, runCoins = 0, frameCount = 0;
static int speedLevel = 0, nitroLevel = 0, handlingLevel = 0;
static bool paused = true, gameOver = false, nitroHeld = false;
static bool effectsOn = true, leftHanded = false, policeActive = false;
static std::vector<Entity> entities;

static jint rgb(int r, int g, int b) {
    return (jint)(0xff000000u | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
}
static void applyPaintColor(JNIEnv* e, jobject p, jmethodID m, int c) {
    e->CallVoidMethod(p, m, (jint)c);
}
static void rect(JNIEnv* e, jobject canvas, jmethodID draw, jobject p, jmethodID color,
                 float l, float t, float r, float b, int c) {
    applyPaintColor(e, p, color, c);
    e->CallVoidMethod(canvas, draw, l, t, r, b, p);
}
static void drawSprite(JNIEnv* e, jobject canvas, jmethodID drawBitmap, jobject bitmap,
                       jobject srcRect, jobject dstRect, jmethodID rectSet, jmethodID rectFSet,
                       jmethodID getWidth, jmethodID getHeight, jobject paint,
                       float l, float t, float r, float b) {
    if (!bitmap) return;
    jint bw = e->CallIntMethod(bitmap, getWidth);
    jint bh = e->CallIntMethod(bitmap, getHeight);
    e->CallVoidMethod(srcRect, rectSet, 0, 0, bw, bh);
    e->CallVoidMethod(dstRect, rectFSet, l, t, r, b);
    e->CallVoidMethod(canvas, drawBitmap, bitmap, srcRect, dstRect, paint);
}
static float clampf(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRender(
    JNIEnv* env, jobject, jobject canvas, jint width, jint height,
    jobject playerBitmap, jobject trafficBitmap, jobject rivalBitmap,
    jobject policeBitmap, jobject truckBitmap, jobject coinBitmap) {

    jclass canvasClass = env->GetObjectClass(canvas);
    jclass paintClass = env->FindClass("android/graphics/Paint");
    jclass rectClass = env->FindClass("android/graphics/Rect");
    jclass rectFClass = env->FindClass("android/graphics/RectF");
    jmethodID paintCtor = env->GetMethodID(paintClass, "<init>", "()V");
    jobject paint = env->NewObject(paintClass, paintCtor);
    jmethodID setColor = env->GetMethodID(paintClass, "setColor", "(I)V");
    jmethodID setAA = env->GetMethodID(paintClass, "setAntiAlias", "(Z)V");
    jmethodID setFilter = env->GetMethodID(paintClass, "setFilterBitmap", "(Z)V");
    env->CallVoidMethod(paint, setAA, JNI_TRUE);
    env->CallVoidMethod(paint, setFilter, JNI_TRUE);
    jmethodID drawRect = env->GetMethodID(canvasClass, "drawRect", "(FFFFLandroid/graphics/Paint;)V");
    jmethodID drawCircle = env->GetMethodID(canvasClass, "drawCircle", "(FFFLandroid/graphics/Paint;)V");
    jmethodID drawBitmap = env->GetMethodID(canvasClass, "drawBitmap",
        "(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V");
    jmethodID rectCtor = env->GetMethodID(rectClass, "<init>", "(IIII)V");
    jobject srcRect = env->NewObject(rectClass, rectCtor, 0, 0, 1, 1);
    jmethodID rectSet = env->GetMethodID(rectClass, "set", "(IIII)V");
    jmethodID rectFCtor = env->GetMethodID(rectFClass, "<init>", "(FFFF)V");
    jobject dstRect = env->NewObject(rectFClass, rectFCtor, 0.f, 0.f, 1.f, 1.f);
    jmethodID rectFSet = env->GetMethodID(rectFClass, "set", "(FFFF)V");
    jclass bitmapClass = env->GetObjectClass(playerBitmap);
    jmethodID getWidth = env->GetMethodID(bitmapClass, "getWidth", "()I");
    jmethodID getHeight = env->GetMethodID(bitmapClass, "getHeight", "()I");
    jmethodID setTextSize = env->GetMethodID(paintClass, "setTextSize", "(F)V");
    jmethodID drawText = env->GetMethodID(canvasClass, "drawText",
        "(Ljava/lang/String;FFLandroid/graphics/Paint;)V");

    float w = (float)std::max(1, (int)width);
    float h = (float)std::max(1, (int)height);
    rect(env, canvas, drawRect, paint, setColor, 0, 0, w, h, rgb(4, 8, 20));

    float roadL = w * .145f, roadR = w * .855f;
    rect(env, canvas, drawRect, paint, setColor, 0, 0, roadL, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL, 0, roadR, h, rgb(19, 27, 45));
    rect(env, canvas, drawRect, paint, setColor, roadR, 0, w, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL - 3, 0, roadL + 2, h, rgb(0, 200, 255));
    rect(env, canvas, drawRect, paint, setColor, roadR - 2, 0, roadR + 3, h, rgb(0, 200, 255));

    bool boosting = nitroHeld && nitroEnergy > .02f && !gameOver && !paused;
    if (!paused && !gameOver) {
        frameCount++;
        roadScroll += boosting ? .035f : .019f;
        if (roadScroll >= 1.f) roadScroll -= 1.f;
        if (frameCount % 4 == 0) score += boosting ? 2 : 1;

        if (frameCount % 75 == 0) {
            int r = frameCount % 300;
            if (r == 0 || r == 150) {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.08f, .055f, .055f, 0.f, 1, true, false});
            } else if (r == 225) {
                float lane = .36f + (float)((frameCount / 75) % 2) * .28f;
                entities.push_back({lane, -.18f, .16f, .20f, (float)frameCount * .03f, 3, true, false});
            } else {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.18f, .105f, .145f, 0.f, 0, true, false});
            }
        }
        if (frameCount % 215 == 0) {
            float lane = .25f + (float)((frameCount / 215) % 3) * .25f;
            entities.push_back({lane, -.22f, .105f, .16f, (float)frameCount * .047f, 2, true, false});
        }
        if (entities.size() > 40) entities.erase(entities.begin(), entities.begin() + (entities.size() - 40));

        if (frameCount > 500) {
            policeActive = true;
            chase = clampf(chase + (boosting ? -.0017f : -.00075f - nitroLevel * .00008f), 0.f, 1.f);
        }
        if (boosting) nitroEnergy = std::max(0.f, nitroEnergy - (.0032f - nitroLevel * .00028f));
        else nitroEnergy = std::min(1.f, nitroEnergy + .0009f + nitroLevel * .0001f);
    }

    // Scrolling lane markings.
    for (int lane = 1; lane <= 2; ++lane) {
        float x = w * (.145f + .71f * lane / 3.f);
        for (int i = 0; i < 8; ++i) {
            float yy = std::fmod(i / 8.f + roadScroll, 1.f) * h;
            rect(env, canvas, drawRect, paint, setColor, x - 1.5f, yy, x + 1.5f, yy + h * .062f, rgb(72, 100, 135));
        }
    }

    float roadSpeed = .0040f + speedLevel * .00035f;
    for (auto &o : entities) {
        if (!o.active) continue;
        if (!paused && !gameOver) {
            float factor = o.type == 2 ? .78f : o.type == 3 ? .60f : 1.f;
            o.y += roadSpeed * (boosting ? 1.45f : 1.f) * factor;
            if (o.type == 2) {
                o.x = clampf(.50f + std::sin(frameCount * .018f + o.phase) * .24f, .23f, .77f);
            }
        }
        float ox = o.x * w;
        float oy = o.y * h;
        float bw = o.w * w;
        float bh = o.h * h;
        if (o.type == 1) {
            if (effectsOn) {
                applyPaintColor(env, paint, setColor, rgb(255, 193, 40));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .026f, paint);
                applyPaintColor(env, paint, setColor, rgb(255, 238, 145));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .016f, paint);
            }
            drawSprite(env, canvas, drawBitmap, coinBitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - bw * .55f, oy - bh * .55f, ox + bw * .55f, oy + bh * .55f);
            if (std::abs(o.x - carX) < .072f && std::abs(o.y - .80f) < .09f) {
                runCoins += 1; score += 25; o.active = false;
            }
        } else {
            jobject bitmap = o.type == 2 ? rivalBitmap : (o.type == 3 ? truckBitmap : trafficBitmap);
            float sw = o.type == 3 ? w * .15f : w * .095f;
            float sh = o.type == 3 ? h * .14f : h * .115f;
            drawSprite(env, canvas, drawBitmap, bitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - sw / 2, oy, ox + sw / 2, oy + sh);
            if (std::abs(o.x - carX) < (o.type == 3 ? .095f : .078f) &&
                o.y + (o.type == 3 ? .14f : .115f) > .745f && o.y < .88f) gameOver = true;
            if (o.type == 2 && !o.rewarded && o.y > .95f) { score += 50; o.rewarded = true; }
        }
        if (o.y > 1.15f) o.active = false;
    }

    // Police pursuit NPC. Nitro buys time; an approaching police car can end the race.
    if (policeActive) {
        if (!paused && !gameOver) policeX += clampf(carX - policeX, -.0045f, .0045f);
        float py = .93f - chase * .16f;
        float pw = w * .105f, ph = h * .12f;
        drawSprite(env, canvas, drawBitmap, policeBitmap, srcRect, dstRect, rectSet, rectFSet,
            getWidth, getHeight, paint, policeX * w - pw / 2, py * h, policeX * w + pw / 2, py * h + ph);
        if (effectsOn && frameCount % 10 < 5) {
            rect(env, canvas, drawRect, paint, setColor, policeX * w - pw * .24f, py * h + ph * .28f,
                 policeX * w, py * h + ph * .35f, rgb(35, 130, 255));
            rect(env, canvas, drawRect, paint, setColor, policeX * w, py * h + ph * .28f,
                 policeX * w + pw * .24f, py * h + ph * .35f, rgb(255, 45, 70));
        }
        if (chase > .94f && std::abs(policeX - carX) < .20f) gameOver = true;
    }

    // Nitro streaks behind the selected car sprite.
    if (boosting && effectsOn) {
        for (int i = 0; i < 7; ++i) {
            float sx = carX * w + std::sin((frameCount + i) * 1.7f) * w * .075f;
            float sy = h * (.89f + (i % 3) * .025f);
            rect(env, canvas, drawRect, paint, setColor, sx - 1.5f, sy, sx + 1.5f, sy + h * .07f,
                 i % 2 ? rgb(0, 195, 255) : rgb(120, 250, 255));
        }
        rect(env, canvas, drawRect, paint, setColor, carX * w - w * .018f, h * .86f,
             carX * w + w * .018f, h * .94f, rgb(255, 239, 120));
    }
    float playerW = w * .11f;
    float playerH = h * .145f;
    drawSprite(env, canvas, drawBitmap, playerBitmap, srcRect, dstRect, rectSet, rectFSet,
        getWidth, getHeight, paint, carX * w - playerW / 2, h * .745f,
        carX * w + playerW / 2, h * .745f + playerH);

    // Nitro energy bar.
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .93f, w * .73f, h * .946f, rgb(20, 40, 65));
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .93f,
         w * (.27f + .46f * nitroEnergy), h * .946f,
         boosting ? rgb(255, 210, 80) : rgb(0, 205, 255));

    if (gameOver || paused) {
        applyPaintColor(env, paint, setColor, rgb(255, 255, 255));
        env->CallVoidMethod(paint, setTextSize, h * .034f);
        jstring msg = env->NewStringUTF(gameOver ? "RACE OVER" : "PAUSED");
        env->CallVoidMethod(canvas, drawText, msg, w * .36f, h * .48f, paint);
        env->DeleteLocalRef(msg);
    }

    env->DeleteLocalRef(srcRect); env->DeleteLocalRef(dstRect); env->DeleteLocalRef(paint);
    env->DeleteLocalRef(canvasClass); env->DeleteLocalRef(paintClass); env->DeleteLocalRef(rectClass);
    env->DeleteLocalRef(rectFClass); env->DeleteLocalRef(bitmapClass);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeTouch(JNIEnv*, jobject, jfloat x, jfloat y) {
    if (x < 0.f) { nitroHeld = false; return; }
    if (paused || gameOver) return;
    float touchX = leftHanded ? (1.f - x) : x;
    if (y > .38f) {
        if (touchX < .43f) carX = std::max(.22f, carX - (.115f + handlingLevel * .006f));
        else if (touchX > .57f) carX = std::min(.78f, carX + (.115f + handlingLevel * .006f));
        else nitroHeld = true;
    }
}
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeScore(JNIEnv*, jobject) { return score; }
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeCoins(JNIEnv*, jobject) { return runCoins; }
extern "C" JNIEXPORT jboolean JNICALL
Java_com_friss_neonracer_MainActivity_nativeGameOver(JNIEnv*, jobject) { return gameOver ? JNI_TRUE : JNI_FALSE; }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativePause(JNIEnv*, jobject, jboolean p) { paused = (p == JNI_TRUE); }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeReset(JNIEnv*, jobject) {
    carX = .5f; roadScroll = 0.f; chase = 0.f; policeX = .5f; nitroEnergy = 1.f;
    score = 0; runCoins = 0; frameCount = 0; paused = false; gameOver = false;
    nitroHeld = false; policeActive = false; entities.clear();
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetUpgrades(JNIEnv*, jobject, jint s, jint n, jint h) {
    speedLevel = std::max(0, std::min(5, (int)s));
    nitroLevel = std::max(0, std::min(5, (int)n));
    handlingLevel = std::max(0, std::min(5, (int)h));
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetOptions(JNIEnv*, jobject, jboolean effects, jboolean left) {
    effectsOn = (effects == JNI_TRUE);
    leftHanded = (left == JNI_TRUE);
}
