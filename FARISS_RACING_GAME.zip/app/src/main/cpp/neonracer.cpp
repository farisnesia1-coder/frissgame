#include <jni.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <mutex>
static std::mutex gameMutex;

struct Entity {
    float x, y, w, h, phase;
    int type;       // 0 traffic, 1 coin, 2 rival, 3 truck
    bool active;
    bool rewarded;
};

static float carX = 0.5f, roadScroll = 0.f, chase = 0.f, policeX = 0.5f;
static float nitroEnergy = 1.f;
static int score = 0, runCoins = 0, frameCount = 0;
static int speedLevel = 0, nitroLevel = 0, handlingLevel = 0;
static bool paused = true, gameOver = false, nitroHeld = false;
static bool effectsOn = true, leftHanded = false, policeActive = false;
static int weatherMode = 0; // 0 clear, 1 rain, 2 fog
static int currentSpeed = 0;
static std::vector<Entity> entities;

static jint rgb(int r, int g, int b) {
    return (jint)(0xff000000u | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
}
static void applyPaintColor(JNIEnv* e, jobject p, jmethodID m, int c) {
    e->CallVoidMethod(p, m, (jint)c);
}
static void rect(JNIEnv* e, jobject canvas, jmethodID draw, jobject p, jmethodID color,
                 float l, float t, float r, float b, int c) {
    applyPaintColor(e, p, color, c);
    e->CallVoidMethod(canvas, draw, l, t, r, b, p);
}
static void drawSprite(JNIEnv* e, jobject canvas, jmethodID drawBitmap, jobject bitmap,
                       jobject srcRect, jobject dstRect, jmethodID rectSet, jmethodID rectFSet,
                       jmethodID getWidth, jmethodID getHeight, jobject paint,
                       float l, float t, float r, float b) {
    if (!bitmap) return;
    jint bw = e->CallIntMethod(bitmap, getWidth);
    jint bh = e->CallIntMethod(bitmap, getHeight);
    e->CallVoidMethod(srcRect, rectSet, 0, 0, bw, bh);
    e->CallVoidMethod(dstRect, rectFSet, l, t, r, b);
    e->CallVoidMethod(canvas, drawBitmap, bitmap, srcRect, dstRect, paint);
}
static float clampf(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRender(
    JNIEnv* env, jobject, jobject canvas, jint width, jint height,
    jobject playerBitmap, jobject trafficBitmap, jobject rivalBitmap,
    jobject policeBitmap, jobject truckBitmap, jobject coinBitmap) {

    jclass canvasClass = env->GetObjectClass(canvas);
    jclass paintClass = env->FindClass("android/graphics/Paint");
    jclass rectClass = env->FindClass("android/graphics/Rect");
    jclass rectFClass = env->FindClass("android/graphics/RectF");
    jmethodID paintCtor = env->GetMethodID(paintClass, "<init>", "()V");
    jobject paint = env->NewObject(paintClass, paintCtor);
    jmethodID setColor = env->GetMethodID(paintClass, "setColor", "(I)V");
    jmethodID setAA = env->GetMethodID(paintClass, "setAntiAlias", "(Z)V");
    jmethodID setFilter = env->GetMethodID(paintClass, "setFilterBitmap", "(Z)V");
    env->CallVoidMethod(paint, setAA, JNI_TRUE);
    env->CallVoidMethod(paint, setFilter, JNI_TRUE);
    jmethodID drawRect = env->GetMethodID(canvasClass, "drawRect", "(FFFFLandroid/graphics/Paint;)V");
    jmethodID drawCircle = env->GetMethodID(canvasClass, "drawCircle", "(FFFLandroid/graphics/Paint;)V");
    jmethodID drawLine = env->GetMethodID(canvasClass, "drawLine", "(FFFFLandroid/graphics/Paint;)V");
    jmethodID setStrokeWidth = env->GetMethodID(paintClass, "setStrokeWidth", "(F)V");
    jmethodID drawBitmap = env->GetMethodID(canvasClass, "drawBitmap",
        "(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V");
    jmethodID rectCtor = env->GetMethodID(rectClass, "<init>", "(IIII)V");
    jobject srcRect = env->NewObject(rectClass, rectCtor, 0, 0, 1, 1);
    jmethodID rectSet = env->GetMethodID(rectClass, "set", "(IIII)V");
    jmethodID rectFCtor = env->GetMethodID(rectFClass, "<init>", "(FFFF)V");
    jobject dstRect = env->NewObject(rectFClass, rectFCtor, 0.f, 0.f, 1.f, 1.f);
    jmethodID rectFSet = env->GetMethodID(rectFClass, "set", "(FFFF)V");
    jclass bitmapClass = env->GetObjectClass(playerBitmap);
    jmethodID getWidth = env->GetMethodID(bitmapClass, "getWidth", "()I");
    jmethodID getHeight = env->GetMethodID(bitmapClass, "getHeight", "()I");
    jmethodID setTextSize = env->GetMethodID(paintClass, "setTextSize", "(F)V");
    jmethodID drawText = env->GetMethodID(canvasClass, "drawText",
        "(Ljava/lang/String;FFLandroid/graphics/Paint;)V");

    float w = (float)std::max(1, (int)width);
    float h = (float)std::max(1, (int)height);
    rect(env, canvas, drawRect, paint, setColor, 0, 0, w, h, rgb(4, 8, 20));
    // Layered midnight sky, distant horizon glow and animated city skyline.
    rect(env, canvas, drawRect, paint, setColor, 0, 0, w, h * .30f, rgb(7, 17, 42));
    rect(env, canvas, drawRect, paint, setColor, 0, h * .24f, w, h * .36f, 0x55206eae);
    applyPaintColor(env, paint, setColor, 0x4439cfff);
    env->CallVoidMethod(canvas, drawCircle, w * .78f, h * .16f, w * .12f, paint);
    applyPaintColor(env, paint, setColor, 0xffc9f4ff);
    env->CallVoidMethod(canvas, drawCircle, w * .78f, h * .16f, w * .055f, paint);
    for (int star = 0; star < 14; ++star) {
        float sx = std::fmod((star * 73.7f + 19.f), w);
        float sy = h * (.035f + std::fmod(star * .037f, .19f));
        applyPaintColor(env, paint, setColor, (star % 3 == 0) ? 0xff77dfff : 0x99d8f4ff);
        env->CallVoidMethod(canvas, drawCircle, sx, sy, (star % 4 == 0) ? 1.8f : 1.0f, paint);
    }
    // Additional skyline blocks behind the roadside silhouettes.
    for (int b = 0; b < 12; ++b) {
        float bw = w * (.025f + (b % 4) * .009f);
        float bh = h * (.11f + ((b * 7) % 8) * .018f);
        float bx = (b % 2 == 0) ? w * (.02f + (b / 2) * .040f) : w * (.62f + (b / 2) * .041f);
        float by = h * .32f - bh;
        rect(env, canvas, drawRect, paint, setColor, bx, by, bx + bw, h * .34f,
             (b % 2) ? rgb(8, 26, 55) : rgb(11, 21, 46));
        for (int win = 0; win < 2; ++win) {
            float wx = bx + bw * (.20f + (win % 2) * .42f);
            float wy = by + bh * (.18f + (win / 2) * .36f);
            rect(env, canvas, drawRect, paint, setColor, wx, wy, wx + bw * .16f, wy + h * .006f,
                 (win + b) % 2 ? 0xff0a83ba : 0xff174c86);
        }
    }

    float roadL = w * .145f, roadR = w * .855f;
    // Dark neon city silhouettes and scrolling window lights on both sides of the road.
    for (int i = 0; i < 11; ++i) {
        float yy = std::fmod(i * .105f + roadScroll * .70f, 1.18f) * h - h * .10f;
        float bh = h * (.075f + (i % 3) * .022f);
        float leftWidth = w * (.035f + (i % 3) * .018f);
        float rightWidth = w * (.040f + ((i + 1) % 3) * .016f);
        rect(env, canvas, drawRect, paint, setColor, 0, yy, leftWidth, yy + bh,
             (i % 2) ? rgb(8, 24, 48) : rgb(10, 17, 37));
        rect(env, canvas, drawRect, paint, setColor, w - rightWidth, yy - h*.025f, w, yy + bh,
             (i % 2) ? rgb(8, 24, 48) : rgb(10, 17, 37));
        for (int win = 0; win < 3; ++win) {
            float wy = yy + bh * (.18f + .22f * win);
            rect(env, canvas, drawRect, paint, setColor, leftWidth*.18f, wy, leftWidth*.48f, wy+h*.006f,
                 (win % 2) ? rgb(0, 100, 165) : rgb(0, 58, 112));
            rect(env, canvas, drawRect, paint, setColor, w-rightWidth*.52f, wy, w-rightWidth*.20f, wy+h*.006f,
                 (win % 2) ? rgb(0, 100, 165) : rgb(0, 58, 112));
        }
    }
    rect(env, canvas, drawRect, paint, setColor, 0, 0, roadL, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL, 0, roadR, h, rgb(19, 27, 45));
    rect(env, canvas, drawRect, paint, setColor, roadR, 0, w, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL - 3, 0, roadL + 2, h, rgb(0, 200, 255));
    rect(env, canvas, drawRect, paint, setColor, roadR - 2, 0, roadR + 3, h, rgb(0, 200, 255));
    // Perspective guide lines converge toward the city vanishing point.
    applyPaintColor(env, paint, setColor, 0x6655cfff);
    env->CallVoidMethod(paint, setStrokeWidth, 1.4f);
    env->CallVoidMethod(canvas, drawLine, w*.50f, h*.30f, roadL+w*.09f, h, paint);
    env->CallVoidMethod(canvas, drawLine, w*.50f, h*.30f, roadR-w*.09f, h, paint);
    applyPaintColor(env, paint, setColor, 0x553b7da8);
    env->CallVoidMethod(canvas, drawLine, roadL, h*.30f, roadL, h, paint);
    env->CallVoidMethod(canvas, drawLine, roadR, h*.30f, roadR, h, paint);
    for (int i = 0; i < 9; ++i) {
        float edgeY = std::fmod(i / 9.f + roadScroll, 1.f) * h;
        rect(env, canvas, drawRect, paint, setColor, roadL + 6, edgeY, roadL + 9, edgeY + h*.025f, rgb(0, 94, 150));
        rect(env, canvas, drawRect, paint, setColor, roadR - 9, edgeY, roadR - 6, edgeY + h*.025f, rgb(0, 94, 150));
    }
    // Animated roadside light pylons and cyan road reflectors.
    for (int i = 0; i < 4; ++i) {
        float ly = std::fmod(i / 4.f + roadScroll * .72f, 1.f) * h;
        float spread = .018f + ly / h * .035f;
        float leftX = roadL - w * spread;
        float rightX = roadR + w * spread;
        rect(env, canvas, drawRect, paint, setColor, leftX, ly - h*.045f, leftX + 2.2f, ly + h*.015f, rgb(35, 76, 112));
        rect(env, canvas, drawRect, paint, setColor, rightX - 2.2f, ly - h*.045f, rightX, ly + h*.015f, rgb(35, 76, 112));
        applyPaintColor(env, paint, setColor, 0xff6deaff);
        env->CallVoidMethod(canvas, drawCircle, leftX + 1.f, ly - h*.045f, 2.f + ly/h*2.f, paint);
        env->CallVoidMethod(canvas, drawCircle, rightX - 1.f, ly - h*.045f, 2.f + ly/h*2.f, paint);
    }

    bool boosting = nitroHeld && nitroEnergy > .02f && !gameOver && !paused;
    currentSpeed = (!paused && !gameOver) ? std::min(380, 118 + frameCount / 7 + speedLevel * 13 + (boosting ? 72 : 0)) : 0;
    if (!paused && !gameOver) {
        frameCount++;
        roadScroll += boosting ? .035f : .019f;
        if (roadScroll >= 1.f) roadScroll -= 1.f;
        if (frameCount % 4 == 0) score += boosting ? 2 : 1;

        if (frameCount % 75 == 0) {
            int r = frameCount % 300;
            if (r == 0 || r == 150) {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.08f, .055f, .055f, 0.f, 1, true, false});
            } else if (r == 225) {
                float lane = .36f + (float)((frameCount / 75) % 2) * .28f;
                entities.push_back({lane, -.18f, .16f, .20f, (float)frameCount * .03f, 3, true, false});
            } else {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.18f, .105f, .145f, 0.f, 0, true, false});
            }
        }
        if (frameCount % 215 == 0) {
            float lane = .25f + (float)((frameCount / 215) % 3) * .25f;
            entities.push_back({lane, -.22f, .105f, .16f, (float)frameCount * .047f, 2, true, false});
        }
        if (entities.size() > 40) entities.erase(entities.begin(), entities.begin() + (entities.size() - 40));

        if (frameCount > 500) {
            policeActive = true;
            chase = clampf(chase + (boosting ? -.0017f : -.00075f - nitroLevel * .00008f), 0.f, 1.f);
        }
        if (boosting) nitroEnergy = std::max(0.f, nitroEnergy - (.0032f - nitroLevel * .00028f));
        else nitroEnergy = std::min(1.f, nitroEnergy + .0009f + nitroLevel * .0001f);
    }

    // Scrolling lane markings.
    for (int lane = 1; lane <= 2; ++lane) {
        float x = w * (.145f + .71f * lane / 3.f);
        for (int i = 0; i < 8; ++i) {
            float yy = std::fmod(i / 8.f + roadScroll, 1.f) * h;
            rect(env, canvas, drawRect, paint, setColor, x - 1.5f, yy, x + 1.5f, yy + h * .062f, rgb(72, 100, 135));
        }
    }
    // Fine wet-road reflections scroll beneath traffic without changing collision geometry.
    for (int i = 0; i < 12; ++i) {
        float yy = std::fmod(i / 12.f + roadScroll * 1.15f, 1.f) * h;
        float rw = w * (.008f + (yy / h) * .018f);
        float rx = roadL + (roadR - roadL) * (.18f + std::fmod(i * .173f, .64f));
        rect(env, canvas, drawRect, paint, setColor, rx, yy, rx + rw, yy + h*.008f,
             weatherMode == 1 ? 0x5546bde8 : 0x3346bde8);
    }

    float roadSpeed = .0040f + speedLevel * .00035f;
    for (auto &o : entities) {
        if (!o.active) continue;
        if (!paused && !gameOver) {
            float factor = o.type == 2 ? .78f : o.type == 3 ? .60f : 1.f;
            o.y += roadSpeed * (boosting ? 1.45f : 1.f) * factor;
            if (o.type == 2) {
                o.x = clampf(.50f + std::sin(frameCount * .018f + o.phase) * .24f, .23f, .77f);
            }
        }
        float ox = o.x * w;
        float oy = o.y * h;
        float bw = o.w * w;
        float bh = o.h * h;
        if (o.type == 1) {
            if (effectsOn) {
                applyPaintColor(env, paint, setColor, rgb(255, 193, 40));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .026f, paint);
                applyPaintColor(env, paint, setColor, rgb(255, 238, 145));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .016f, paint);
            }
            drawSprite(env, canvas, drawBitmap, coinBitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - bw * .55f, oy - bh * .55f, ox + bw * .55f, oy + bh * .55f);
            if (std::abs(o.x - carX) < .072f && std::abs(o.y - .80f) < .09f) {
                runCoins += 1; score += 25; o.active = false;
            }
        } else {
            jobject bitmap = o.type == 2 ? rivalBitmap : (o.type == 3 ? truckBitmap : trafficBitmap);
            float sw = o.type == 3 ? w * .15f : w * .095f;
            float sh = o.type == 3 ? h * .14f : h * .115f;
            drawSprite(env, canvas, drawBitmap, bitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - sw / 2, oy, ox + sw / 2, oy + sh);
            if (std::abs(o.x - carX) < (o.type == 3 ? .095f : .078f) &&
                o.y + (o.type == 3 ? .14f : .115f) > .745f && o.y < .88f) gameOver = true;
            if (o.type == 2 && !o.rewarded && o.y > .95f) { score += 50; o.rewarded = true; }
        }
        if (o.y > 1.15f) o.active = false;
    }

    // Police pursuit NPC. Nitro buys time; an approaching police car can end the race.
    if (policeActive) {
        if (!paused && !gameOver) policeX += clampf(carX - policeX, -.0045f, .0045f);
        float py = .93f - chase * .16f;
        float pw = w * .105f, ph = h * .12f;
        drawSprite(env, canvas, drawBitmap, policeBitmap, srcRect, dstRect, rectSet, rectFSet,
            getWidth, getHeight, paint, policeX * w - pw / 2, py * h, policeX * w + pw / 2, py * h + ph);
        if (effectsOn && frameCount % 10 < 5) {
            rect(env, canvas, drawRect, paint, setColor, policeX * w - pw * .24f, py * h + ph * .28f,
                 policeX * w, py * h + ph * .35f, rgb(35, 130, 255));
            rect(env, canvas, drawRect, paint, setColor, policeX * w, py * h + ph * .28f,
                 policeX * w + pw * .24f, py * h + ph * .35f, rgb(255, 45, 70));
        }
        if (chase > .94f && std::abs(policeX - carX) < .20f) gameOver = true;
    }

    // Weather overlays: lightweight procedural rain or layered low fog.
    if (weatherMode == 1) {
        applyPaintColor(env, paint, setColor, 0x887bcdf2);
        env->CallVoidMethod(paint, setStrokeWidth, 1.2f);
        for (int drop = 0; drop < 26; ++drop) {
            float rx = std::fmod(drop * 83.17f + frameCount * (1.4f + (drop % 3) * .35f), w);
            float ry = std::fmod(drop * 47.31f + frameCount * (4.2f + (drop % 4) * .6f), h);
            env->CallVoidMethod(canvas, drawLine, rx, ry, rx - w*.008f, ry + h*.025f, paint);
        }
    } else if (weatherMode == 2) {
        rect(env, canvas, drawRect, paint, setColor, 0, h*.30f, w, h*.43f, 0x223f9dc7);
        rect(env, canvas, drawRect, paint, setColor, 0, h*.56f, w, h*.67f, 0x183f9dc7);
    }

    // Nitro streaks behind the selected car sprite.
    if (boosting && effectsOn) {
        for (int i = 0; i < 7; ++i) {
            float sx = carX * w + std::sin((frameCount + i) * 1.7f) * w * .075f;
            float sy = h * (.89f + (i % 3) * .025f);
            rect(env, canvas, drawRect, paint, setColor, sx - 1.5f, sy, sx + 1.5f, sy + h * .07f,
                 i % 2 ? rgb(0, 195, 255) : rgb(120, 250, 255));
        }
        rect(env, canvas, drawRect, paint, setColor, carX * w - w * .018f, h * .86f,
             carX * w + w * .018f, h * .94f, rgb(255, 239, 120));
    }
    float playerW = w * .11f;
    float playerH = h * .145f;
    // Soft cyan underglow and contact shadow make the player car read clearly on the road.
    applyPaintColor(env, paint, setColor, effectsOn ? 0x5534dfff : 0x44202028);
    env->CallVoidMethod(canvas, drawCircle, carX * w, h * .84f, playerW * .62f, paint);
    applyPaintColor(env, paint, setColor, 0x99000000);
    env->CallVoidMethod(canvas, drawCircle, carX * w, h * .875f, playerW * .50f, paint);
    drawSprite(env, canvas, drawBitmap, playerBitmap, srcRect, dstRect, rectSet, rectFSet,
        getWidth, getHeight, paint, carX * w - playerW / 2, h * .745f,
        carX * w + playerW / 2, h * .745f + playerH);

    // Nitro energy bar.
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .705f, w * .73f, h * .721f, rgb(20, 40, 65));
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .705f,
         w * (.27f + .46f * nitroEnergy), h * .721f,
         boosting ? rgb(255, 210, 80) : rgb(0, 205, 255));

    if (gameOver || paused) {
        applyPaintColor(env, paint, setColor, rgb(255, 255, 255));
        env->CallVoidMethod(paint, setTextSize, h * .034f);
        jstring msg = env->NewStringUTF(gameOver ? "RACE OVER" : "PAUSED");
        env->CallVoidMethod(canvas, drawText, msg, w * .36f, h * .48f, paint);
        env->DeleteLocalRef(msg);
    }

    env->DeleteLocalRef(srcRect); env->DeleteLocalRef(dstRect); env->DeleteLocalRef(paint);
    env->DeleteLocalRef(canvasClass); env->DeleteLocalRef(paintClass); env->DeleteLocalRef(rectClass);
    env->DeleteLocalRef(rectFClass); env->DeleteLocalRef(bitmapClass);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeTouch(JNIEnv*, jobject, jfloat x, jfloat y) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if (x < 0.f) { nitroHeld = false; return; }
    if (paused || gameOver) return;
    float touchX = leftHanded ? (1.f - x) : x;
    if (y > .38f) {
        if (touchX < .43f) carX = std::max(.22f, carX - (.115f + handlingLevel * .006f));
        else if (touchX > .57f) carX = std::min(.78f, carX + (.115f + handlingLevel * .006f));
        else nitroHeld = true;
    }
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSteer(JNIEnv*, jobject, jint direction) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if (paused || gameOver) return;
    float step = .115f + handlingLevel * .006f;
    if (direction < 0) carX = std::max(.22f, carX - step);
    else if (direction > 0) carX = std::min(.78f, carX + step);
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeNitro(JNIEnv*, jobject, jboolean down) {
    std::lock_guard<std::mutex> lock(gameMutex);
    nitroHeld = (down == JNI_TRUE) && !paused && !gameOver;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeScore(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return score; }
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeCoins(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return runCoins; }
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeSpeed(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return currentSpeed; }
extern "C" JNIEXPORT jboolean JNICALL
Java_com_friss_neonracer_MainActivity_nativeGameOver(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return gameOver ? JNI_TRUE : JNI_FALSE; }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativePause(JNIEnv*, jobject, jboolean p) {
    std::lock_guard<std::mutex> lock(gameMutex); paused = (p == JNI_TRUE); }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeReset(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex);
    carX = .5f; roadScroll = 0.f; chase = 0.f; policeX = .5f; nitroEnergy = 1.f;
    score = 0; runCoins = 0; frameCount = 0; currentSpeed = 0; paused = false; gameOver = false;
    nitroHeld = false; policeActive = false; entities.clear();
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetUpgrades(JNIEnv*, jobject, jint s, jint n, jint h) {
    std::lock_guard<std::mutex> lock(gameMutex);
    speedLevel = std::max(0, std::min(5, (int)s));
    nitroLevel = std::max(0, std::min(5, (int)n));
    handlingLevel = std::max(0, std::min(5, (int)h));
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetOptions(JNIEnv*, jobject, jboolean effects, jboolean left) {
    std::lock_guard<std::mutex> lock(gameMutex);
    effectsOn = (effects == JNI_TRUE);
    leftHanded = (left == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetWeather(JNIEnv*, jobject, jint mode) {
    std::lock_guard<std::mutex> lock(gameMutex);
    weatherMode = std::max(0, std::min(2, (int)mode));
}

// -----------------------------------------------------------------------------
// PHASE 2: OpenGL ES 3.0 mobile racing renderer. The Canvas renderer above is
// retained as a compatibility fallback; the Android game surface now uses this
// real perspective scene with a chase camera and procedural 3D geometry.
// -----------------------------------------------------------------------------
#include <GLES3/gl3.h>
#include <array>
#include <cstring>

static GLuint glProgram = 0, glVbo = 0;
static GLint glPosLoc = -1, glMvpLoc = -1, glColorLoc = -1;
static float glAspect = 1.f;
static float glCameraX = 0.f;
static float glTime = 0.f;

static GLuint compileShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint ok = 0; glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) { glDeleteShader(shader); return 0; }
    return shader;
}
static void glInitScene() {
    const char* vs = "#version 300 es\nlayout(location=0) in vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
    const char* fs = "#version 300 es\nprecision mediump float; uniform vec4 uColor; out vec4 frag; void main(){frag=uColor;}";
    GLuint v = compileShader(GL_VERTEX_SHADER, vs), f = compileShader(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return;
    glProgram = glCreateProgram(); glAttachShader(glProgram, v); glAttachShader(glProgram, f);
    glLinkProgram(glProgram); glDeleteShader(v); glDeleteShader(f);
    GLint linked = 0; glGetProgramiv(glProgram, GL_LINK_STATUS, &linked);
    if (!linked) { glDeleteProgram(glProgram); glProgram = 0; return; }
    glPosLoc = 0; glMvpLoc = glGetUniformLocation(glProgram, "uMVP");
    glColorLoc = glGetUniformLocation(glProgram, "uColor");
    glGenBuffers(1, &glVbo);
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE); // Keep thin road planes visible from the chase-camera angle.
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}
static void matIdentity(float* m) { std::memset(m, 0, 16*sizeof(float)); m[0]=m[5]=m[10]=m[15]=1.f; }
static void matMultiply(float* out, const float* a, const float* b) {
    float t[16];
    for(int c=0;c<4;c++) for(int r=0;r<4;r++) { t[c*4+r]=0; for(int k=0;k<4;k++) t[c*4+r]+=a[k*4+r]*b[c*4+k]; }
    std::memcpy(out,t,sizeof(t));
}
static void matPerspective(float* m,float fovy,float aspect,float n,float f) {
    std::memset(m,0,16*sizeof(float)); float q=1.f/std::tan(fovy*.5f);
    m[0]=q/aspect; m[5]=q; m[10]=(f+n)/(n-f); m[11]=-1.f; m[14]=(2.f*f*n)/(n-f);
}
static void matLookAt(float* m,float ex,float ey,float ez,float cx,float cy,float cz) {
    float fx=cx-ex, fy=cy-ey, fz=cz-ez; float fl=std::sqrt(fx*fx+fy*fy+fz*fz); fx/=fl;fy/=fl;fz/=fl;
    float sx=fy*0.f-fz*1.f, sy=fz*0.f-fx*0.f, sz=fx*1.f-fy*0.f;
    float sl=std::sqrt(sx*sx+sy*sy+sz*sz); sx/=sl;sy/=sl;sz/=sl;
    float ux=sy*fz-sz*fy, uy=sz*fx-sx*fz, uz=sx*fy-sy*fx;
    matIdentity(m); m[0]=sx;m[4]=sy;m[8]=sz; m[1]=ux;m[5]=uy;m[9]=uz; m[2]=-fx;m[6]=-fy;m[10]=-fz;
    m[12]=-(sx*ex+sy*ey+sz*ez); m[13]=-(ux*ex+uy*ey+uz*ez); m[14]=(fx*ex+fy*ey+fz*ez);
}
static void matModel(float* m,float x,float y,float z,float sx,float sy,float sz) {
    matIdentity(m); m[0]=sx;m[5]=sy;m[10]=sz;m[12]=x;m[13]=y;m[14]=z;
}
static void glDrawMesh(const float* verts, int count, const float* mvp, float r,float g,float b,float a=1.f) {
    if (!glProgram || count<=0) return;
    glUseProgram(glProgram); glUniformMatrix4fv(glMvpLoc,1,GL_FALSE,mvp);
    glUniform4f(glColorLoc,r,g,b,a); glBindBuffer(GL_ARRAY_BUFFER,glVbo);
    glBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)(count*3*sizeof(float)),verts,GL_STREAM_DRAW);
    glEnableVertexAttribArray((GLuint)glPosLoc); glVertexAttribPointer((GLuint)glPosLoc,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glDrawArrays(GL_TRIANGLES,0,count); glDisableVertexAttribArray((GLuint)glPosLoc);
}
static void glBox(const float* vp,float x,float y,float z,float sx,float sy,float sz,float r,float g,float b) {
    static const float cube[] = {
      -1,-1,1, 1,-1,1, 1,1,1, -1,-1,1, 1,1,1, -1,1,1,
      1,-1,-1, -1,-1,-1, -1,1,-1, 1,-1,-1, -1,1,-1, 1,1,-1,
      -1,-1,-1, -1,-1,1, -1,1,1, -1,-1,-1, -1,1,1, -1,1,-1,
      1,-1,1, 1,-1,-1, 1,1,-1, 1,-1,1, 1,1,-1, 1,1,1,
      -1,1,1, 1,1,1, 1,1,-1, -1,1,1, 1,1,-1, -1,1,-1,
      -1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,-1, 1,-1,1, -1,-1,1
    };
    float model[16],mvp[16]; matModel(model,x,y,z,sx,sy,sz); matMultiply(mvp,vp,model);
    glDrawMesh(cube,36,mvp,r,g,b,1.f);
}
static void glQuad(const float* vp,float x1,float z1,float x2,float z2,float y,float r,float g,float b) {
    float v[]={x1,y,z1, x2,y,z1, x2,y,z2, x1,y,z1, x2,y,z2, x1,y,z2};
    glDrawMesh(v,6,vp,r,g,b,1.f);
}
static float roadCenter(float z) {
    float d=-z + roadScroll*24.f;
    return std::sin(d*.035f)*1.15f + std::sin(d*.012f)*.48f;
}
static void glRoadStrip(const float* vp,float z1,float z2,float halfWidth,float y,float r,float g,float b) {
    float c1=roadCenter(z1), c2=roadCenter(z2);
    float v[]={c1-halfWidth,y,z1, c1+halfWidth,y,z1, c2+halfWidth,y,z2,
               c1-halfWidth,y,z1, c2+halfWidth,y,z2, c2-halfWidth,y,z2};
    glDrawMesh(v,6,vp,r,g,b,1.f);
}
static void glCar(const float* vp,float x,float z,float scale,float bodyR,float bodyG,float bodyB,bool player) {
    glBox(vp,x,.02f,z,.58f*scale,.19f*scale,1.05f*scale,bodyR,bodyG,bodyB);
    glBox(vp,x,.22f*scale,z-.12f*scale,.39f*scale,.19f*scale,.52f*scale,.08f,.16f,.25f);
    // Windscreen and roof highlights.
    glBox(vp,x,.34f*scale,z-.16f*scale,.30f*scale,.035f*scale,.27f*scale,.20f,.65f,.88f);
    for(int side=-1;side<=1;side+=2) {
        glBox(vp,x+side*.58f*scale,-.015f,z-.62f*scale,.13f*scale,.17f*scale,.28f*scale,.025f,.035f,.05f);
        glBox(vp,x+side*.58f*scale,-.015f,z+.58f*scale,.13f*scale,.17f*scale,.28f*scale,.025f,.035f,.05f);
    }
    glBox(vp,x-.30f*scale,.09f*scale,z+1.04f*scale,.13f*scale,.045f*scale,.035f*scale,1.f,.08f,.07f);
    glBox(vp,x+.30f*scale,.09f*scale,z+1.04f*scale,.13f*scale,.045f*scale,.035f*scale,1.f,.08f,.07f);
    if(player) {
        glBox(vp,x-.22f*scale,.01f,z-.92f*scale,.08f*scale,.025f*scale,.12f*scale,.10f,.75f,1.f);
        glBox(vp,x+.22f*scale,.01f,z-.92f*scale,.08f*scale,.025f*scale,.12f*scale,.10f,.75f,1.f);
    }
}
static void glUpdateSimulation(float dt) {
    if(paused || gameOver) { currentSpeed=0; return; }
    float step=std::max(.25f,std::min(2.5f,dt*60.f));
    bool boosting=nitroHeld && nitroEnergy>.02f;
    currentSpeed=std::min(380,118+frameCount/7+speedLevel*13+(boosting?72:0));
    frameCount++;
    roadScroll+= (boosting?.035f:.019f)*step; if(roadScroll>=1.f)roadScroll-=std::floor(roadScroll);
    if(frameCount%4==0)score+=boosting?2:1;
    if(frameCount%75==0) {
        int r=frameCount%300;
        if(r==0||r==150) { float lane=.25f+(float)((frameCount/75)%3)*.25f; entities.push_back({lane,-.08f,.055f,.055f,0.f,1,true,false}); }
        else if(r==225) { float lane=.36f+(float)((frameCount/75)%2)*.28f; entities.push_back({lane,-.18f,.16f,.20f,(float)frameCount*.03f,3,true,false}); }
        else { float lane=.25f+(float)((frameCount/75)%3)*.25f; entities.push_back({lane,-.18f,.105f,.145f,0.f,0,true,false}); }
    }
    if(frameCount%215==0) { float lane=.25f+(float)((frameCount/215)%3)*.25f; entities.push_back({lane,-.22f,.105f,.16f,(float)frameCount*.047f,2,true,false}); }
    if(entities.size()>40)entities.erase(entities.begin(),entities.begin()+(entities.size()-40));
    if(frameCount>500){policeActive=true;chase=clampf(chase+(boosting?-.0017f:-.00075f-nitroLevel*.00008f)*step,0.f,1.f);}
    if(boosting)nitroEnergy=std::max(0.f,nitroEnergy-(.0032f-nitroLevel*.00028f)*step);
    else nitroEnergy=std::min(1.f,nitroEnergy+(.0009f+nitroLevel*.0001f)*step);
    float roadSpeed=(.0040f+speedLevel*.00035f)*step;
    for(auto &o:entities){if(!o.active)continue;float factor=o.type==2?.78f:o.type==3?.60f:1.f;o.y+=roadSpeed*(boosting?1.45f:1.f)*factor;
        if(o.type==2)o.x=clampf(.50f+std::sin(frameCount*.018f+o.phase)*.24f,.23f,.77f);
        if(o.type==1){if(std::abs(o.x-carX)<.072f&&std::abs(o.y-.80f)<.09f){runCoins++;score+=25;o.active=false;}}
        else {if(std::abs(o.x-carX)<(o.type==3?.095f:.078f)&&o.y+(o.type==3?.14f:.115f)>.745f&&o.y<.88f)gameOver=true;
            if(o.type==2&&!o.rewarded&&o.y>.95f){score+=50;o.rewarded=true;}}
        if(o.y>1.15f)o.active=false;
    }
    if(policeActive){policeX+=clampf(carX-policeX,-.0045f,.0045f)*step;if(chase>.94f&&std::abs(policeX-carX)<.20f)gameOver=true;}
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeGlInit(JNIEnv*,jobject) { glInitScene(); }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRenderGL(JNIEnv*,jobject,jint width,jint height,jfloat delta) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if(!glProgram)glInitScene();
    const float w=(float)std::max(1,(int)width),h=(float)std::max(1,(int)height);
    glAspect=w/h; glTime+=std::max(0.f,std::min(.05f,(float)delta)); glUpdateSimulation(delta);
    bool boosting=nitroHeld&&nitroEnergy>.02f&&!paused&&!gameOver;
    glViewport(0,0,(GLsizei)width,(GLsizei)height);
    if(weatherMode==2) glClearColor(.62f,.72f,.78f,1.f);
    else glClearColor(.47f,.72f,.91f,1.f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    float projection[16],view[16],vp[16];
    float cameraTarget=roadCenter(-7.f)+(carX-.5f)*.38f;
    glCameraX+=(cameraTarget-glCameraX)*.10f;
    matPerspective(projection,0.92f,glAspect,.1f,130.f);
    matLookAt(view,glCameraX,5.1f,9.0f,glCameraX*.72f,.0f,-9.0f);
    matMultiply(vp,projection,view);
    // Bright horizon, distant hills and a clean daytime sky.
    glQuad(vp,-90.f,-95.f,90.f,18.f,-.65f,.24f,.47f,.43f);
    for(int i=0;i<13;i++){
        float x=-34.f+i*5.7f; float hill=2.0f+(i%4)*.75f;
        glBox(vp,x,-.2f,-47.f-(i%3)*2.f,3.2f,hill,1.5f,.39f,.60f,.68f);
    }
    // Asphalt road with broad shoulders, edge strips and dashed lane dividers.
    for(int seg=0;seg<28;seg++){
        float z1=12.f-seg*3.0f, z2=z1-3.0f;
        glRoadStrip(vp,z1,z2,6.2f,-.12f,.78f,.82f,.84f);
        glRoadStrip(vp,z1,z2,5.7f,-.08f,.16f,.19f,.23f);
        // Narrow neon shoulder lines follow the road curvature.
        float c1=roadCenter(z1), c2=roadCenter(z2);
        float left[]={c1-5.95f,-.055f,z1,c1-5.82f,-.055f,z1,c2-5.82f,-.055f,z2,c1-5.95f,-.055f,z1,c2-5.82f,-.055f,z2,c2-5.95f,-.055f,z2};
        float right[]={c1+5.82f,-.055f,z1,c1+5.95f,-.055f,z1,c2+5.95f,-.055f,z2,c1+5.82f,-.055f,z1,c2+5.95f,-.055f,z2,c2+5.82f,-.055f,z2};
        glDrawMesh(left,6,vp,.05f,.67f,.93f,1.f); glDrawMesh(right,6,vp,.05f,.67f,.93f,1.f);
    }
    for(int lane=1;lane<=2;lane++)for(int i=0;i<24;i++){
        float z=10.f-i*3.5f+(roadScroll*18.f); while(z>12.f)z-=84.f;
        float cx=roadCenter(z)+(-3.8f+lane*2.5333f);
        glQuad(vp,cx-.045f,z-1.0f,cx+.045f,z,.005f,.88f,.91f,.93f);
    }
    // Guardrails, lamp posts and alternating roadside buildings create depth cues.
    for(int i=0;i<22;i++){
        float z=8.f-i*4.0f+(roadScroll*22.f);while(z>10.f)z-=88.f;
        float center=roadCenter(z);
        glBox(vp,center-6.15f,.35f,z,.12f,.18f,1.8f,.64f,.72f,.78f);
        glBox(vp,center+6.15f,.35f,z,.12f,.18f,1.8f,.64f,.72f,.78f);
        if(i%2==0){glBox(vp,center-8.4f,1.2f,z-1.f,1.0f,1.2f,1.3f,.52f,.67f,.75f);glBox(vp,center+8.4f,1.7f,z-1.f,1.1f,1.7f,1.5f,.48f,.63f,.72f);}
        glBox(vp,center-6.8f,2.2f,z,.055f,2.2f,.055f,.28f,.35f,.43f);
        glBox(vp,center+6.8f,2.2f,z,.055f,2.2f,.055f,.28f,.35f,.43f);
        glBox(vp,center-6.8f,4.4f,z,.24f,.07f,.24f,.45f,.86f,1.f);
        glBox(vp,center+6.8f,4.4f,z,.24f,.07f,.24f,.45f,.86f,1.f);
    }
    // Traffic, rivals, trucks and collectible coins scale naturally with depth.
    for(auto &o:entities){if(!o.active)continue;float z=-39.f+o.y*47.f;float x=roadCenter(z)+(o.x-.5f)*8.2f;float scale=.34f+o.y*.80f;
        if(o.type==1){glBox(vp,x,.45f,z,.18f*scale,.18f*scale,.18f*scale,1.f,.69f,.08f);glBox(vp,x,.45f,z-.02f,.10f*scale,.20f*scale,.10f*scale,1.f,.9f,.35f);}
        else if(o.type==3)glCar(vp,x,z,scale,.52f,.56f,.61f,false);
        else if(o.type==2)glCar(vp,x,z,scale,.74f,.12f,.16f,false);
        else glCar(vp,x,z,scale,.88f,.91f,.94f,false);
    }
    if(policeActive){float pz=-1.0f-(1.f-chase)*10.f;glCar(vp,roadCenter(pz)+(policeX-.5f)*8.2f,pz,.85f,.08f,.24f,.68f,false);}
    // Player car in the foreground, with cyan underglow and nitro trails.
    float playerX=roadCenter(-1.4f)+(carX-.5f)*8.2f;
    if(boosting){glBox(vp,playerX-.27f,.02f,-.05f,.045f,.04f,1.5f,.10f,.72f,1.f);glBox(vp,playerX+.27f,.02f,-.05f,.045f,.04f,1.5f,.10f,.72f,1.f);}
    glCar(vp,playerX,-1.4f,1.0f,.035f,.48f,.88f,true);
    // Soft speed streaks on boost; restrained so the road remains readable.
    if(boosting)for(int i=0;i<10;i++){float x=playerX+std::sin(glTime*8.f+i*2.1f)*2.5f;float z=-7.f-(i%5)*2.5f;glBox(vp,x,.02f,z,.018f,.018f,1.1f,.22f,.78f,1.f);}
    if(weatherMode==1){for(int i=0;i<35;i++){float x=std::fmod(i*1.73f+glTime*5.f,14.f)-7.f;float z=-5.f-std::fmod(i*4.13f+glTime*18.f,45.f);glBox(vp,x,3.f,z,.012f,.012f,.55f,.55f,.78f,.94f);}}
}
