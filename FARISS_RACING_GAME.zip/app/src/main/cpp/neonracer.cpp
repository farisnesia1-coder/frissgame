#include <jni.h>
#include <algorithm>
#include <cmath>
#include <vector>
#include <mutex>
static std::mutex gameMutex;

struct Entity {
    float x, y, w, h, phase;
    int type;       // 0 traffic, 1 coin, 2 rival, 3 truck
    int variant;    // 0..9 distinct street-car silhouettes / paint profiles
    bool active;
    bool rewarded;
};

static float carX = 0.5f, roadScroll = 0.f, chase = 0.f, policeX = 0.5f;
static float nitroEnergy = 1.f;
static int score = 0, runCoins = 0, frameCount = 0;
static int speedLevel = 0, nitroLevel = 0, handlingLevel = 0;
static int selectedCarStyle = 0;
static bool paused = true, gameOver = false, nitroHeld = false;
static bool effectsOn = true, leftHanded = false, policeActive = false;
static int weatherMode = 0; // 0 clear, 1 rain, 2 fog
static int currentSpeed = 0;
static std::vector<Entity> entities;

static jint rgb(int r, int g, int b) {
    return (jint)(0xff000000u | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255));
}
static void applyPaintColor(JNIEnv* e, jobject p, jmethodID m, int c) {
    e->CallVoidMethod(p, m, (jint)c);
}
static void rect(JNIEnv* e, jobject canvas, jmethodID draw, jobject p, jmethodID color,
                 float l, float t, float r, float b, int c) {
    applyPaintColor(e, p, color, c);
    e->CallVoidMethod(canvas, draw, l, t, r, b, p);
}
static void drawSprite(JNIEnv* e, jobject canvas, jmethodID drawBitmap, jobject bitmap,
                       jobject srcRect, jobject dstRect, jmethodID rectSet, jmethodID rectFSet,
                       jmethodID getWidth, jmethodID getHeight, jobject paint,
                       float l, float t, float r, float b) {
    if (!bitmap) return;
    jint bw = e->CallIntMethod(bitmap, getWidth);
    jint bh = e->CallIntMethod(bitmap, getHeight);
    e->CallVoidMethod(srcRect, rectSet, 0, 0, bw, bh);
    e->CallVoidMethod(dstRect, rectFSet, l, t, r, b);
    e->CallVoidMethod(canvas, drawBitmap, bitmap, srcRect, dstRect, paint);
}
static float clampf(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRender(
    JNIEnv* env, jobject, jobject canvas, jint width, jint height,
    jobject playerBitmap, jobject trafficBitmap, jobject rivalBitmap,
    jobject policeBitmap, jobject truckBitmap, jobject coinBitmap) {

    jclass canvasClass = env->GetObjectClass(canvas);
    jclass paintClass = env->FindClass("android/graphics/Paint");
    jclass rectClass = env->FindClass("android/graphics/Rect");
    jclass rectFClass = env->FindClass("android/graphics/RectF");
    jmethodID paintCtor = env->GetMethodID(paintClass, "<init>", "()V");
    jobject paint = env->NewObject(paintClass, paintCtor);
    jmethodID setColor = env->GetMethodID(paintClass, "setColor", "(I)V");
    jmethodID setAA = env->GetMethodID(paintClass, "setAntiAlias", "(Z)V");
    jmethodID setFilter = env->GetMethodID(paintClass, "setFilterBitmap", "(Z)V");
    env->CallVoidMethod(paint, setAA, JNI_TRUE);
    env->CallVoidMethod(paint, setFilter, JNI_TRUE);
    jmethodID drawRect = env->GetMethodID(canvasClass, "drawRect", "(FFFFLandroid/graphics/Paint;)V");
    jmethodID drawCircle = env->GetMethodID(canvasClass, "drawCircle", "(FFFLandroid/graphics/Paint;)V");
    jmethodID drawLine = env->GetMethodID(canvasClass, "drawLine", "(FFFFLandroid/graphics/Paint;)V");
    jmethodID setStrokeWidth = env->GetMethodID(paintClass, "setStrokeWidth", "(F)V");
    jmethodID drawBitmap = env->GetMethodID(canvasClass, "drawBitmap",
        "(Landroid/graphics/Bitmap;Landroid/graphics/Rect;Landroid/graphics/RectF;Landroid/graphics/Paint;)V");
    jmethodID rectCtor = env->GetMethodID(rectClass, "<init>", "(IIII)V");
    jobject srcRect = env->NewObject(rectClass, rectCtor, 0, 0, 1, 1);
    jmethodID rectSet = env->GetMethodID(rectClass, "set", "(IIII)V");
    jmethodID rectFCtor = env->GetMethodID(rectFClass, "<init>", "(FFFF)V");
    jobject dstRect = env->NewObject(rectFClass, rectFCtor, 0.f, 0.f, 1.f, 1.f);
    jmethodID rectFSet = env->GetMethodID(rectFClass, "set", "(FFFF)V");
    jclass bitmapClass = env->GetObjectClass(playerBitmap);
    jmethodID getWidth = env->GetMethodID(bitmapClass, "getWidth", "()I");
    jmethodID getHeight = env->GetMethodID(bitmapClass, "getHeight", "()I");
    jmethodID setTextSize = env->GetMethodID(paintClass, "setTextSize", "(F)V");
    jmethodID drawText = env->GetMethodID(canvasClass, "drawText",
        "(Ljava/lang/String;FFLandroid/graphics/Paint;)V");

    float w = (float)std::max(1, (int)width);
    float h = (float)std::max(1, (int)height);
    rect(env, canvas, drawRect, paint, setColor, 0, 0, w, h, rgb(4, 8, 20));
    // Layered midnight sky, distant horizon glow and animated city skyline.
    rect(env, canvas, drawRect, paint, setColor, 0, 0, w, h * .30f, rgb(7, 17, 42));
    rect(env, canvas, drawRect, paint, setColor, 0, h * .24f, w, h * .36f, 0x55206eae);
    applyPaintColor(env, paint, setColor, 0x4439cfff);
    env->CallVoidMethod(canvas, drawCircle, w * .78f, h * .16f, w * .12f, paint);
    applyPaintColor(env, paint, setColor, 0xffc9f4ff);
    env->CallVoidMethod(canvas, drawCircle, w * .78f, h * .16f, w * .055f, paint);
    for (int star = 0; star < 14; ++star) {
        float sx = std::fmod((star * 73.7f + 19.f), w);
        float sy = h * (.035f + std::fmod(star * .037f, .19f));
        applyPaintColor(env, paint, setColor, (star % 3 == 0) ? 0xff77dfff : 0x99d8f4ff);
        env->CallVoidMethod(canvas, drawCircle, sx, sy, (star % 4 == 0) ? 1.8f : 1.0f, paint);
    }
    // Additional skyline blocks behind the roadside silhouettes.
    for (int b = 0; b < 12; ++b) {
        float bw = w * (.025f + (b % 4) * .009f);
        float bh = h * (.11f + ((b * 7) % 8) * .018f);
        float bx = (b % 2 == 0) ? w * (.02f + (b / 2) * .040f) : w * (.62f + (b / 2) * .041f);
        float by = h * .32f - bh;
        rect(env, canvas, drawRect, paint, setColor, bx, by, bx + bw, h * .34f,
             (b % 2) ? rgb(8, 26, 55) : rgb(11, 21, 46));
        for (int win = 0; win < 2; ++win) {
            float wx = bx + bw * (.20f + (win % 2) * .42f);
            float wy = by + bh * (.18f + (win / 2) * .36f);
            rect(env, canvas, drawRect, paint, setColor, wx, wy, wx + bw * .16f, wy + h * .006f,
                 (win + b) % 2 ? 0xff0a83ba : 0xff174c86);
        }
    }

    float roadL = w * .145f, roadR = w * .855f;
    // Dark neon city silhouettes and scrolling window lights on both sides of the road.
    for (int i = 0; i < 11; ++i) {
        float yy = std::fmod(i * .105f + roadScroll * .70f, 1.18f) * h - h * .10f;
        float bh = h * (.075f + (i % 3) * .022f);
        float leftWidth = w * (.035f + (i % 3) * .018f);
        float rightWidth = w * (.040f + ((i + 1) % 3) * .016f);
        rect(env, canvas, drawRect, paint, setColor, 0, yy, leftWidth, yy + bh,
             (i % 2) ? rgb(8, 24, 48) : rgb(10, 17, 37));
        rect(env, canvas, drawRect, paint, setColor, w - rightWidth, yy - h*.025f, w, yy + bh,
             (i % 2) ? rgb(8, 24, 48) : rgb(10, 17, 37));
        for (int win = 0; win < 3; ++win) {
            float wy = yy + bh * (.18f + .22f * win);
            rect(env, canvas, drawRect, paint, setColor, leftWidth*.18f, wy, leftWidth*.48f, wy+h*.006f,
                 (win % 2) ? rgb(0, 100, 165) : rgb(0, 58, 112));
            rect(env, canvas, drawRect, paint, setColor, w-rightWidth*.52f, wy, w-rightWidth*.20f, wy+h*.006f,
                 (win % 2) ? rgb(0, 100, 165) : rgb(0, 58, 112));
        }
    }
    rect(env, canvas, drawRect, paint, setColor, 0, 0, roadL, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL, 0, roadR, h, rgb(19, 27, 45));
    rect(env, canvas, drawRect, paint, setColor, roadR, 0, w, h, rgb(7, 14, 31));
    rect(env, canvas, drawRect, paint, setColor, roadL - 3, 0, roadL + 2, h, rgb(0, 200, 255));
    rect(env, canvas, drawRect, paint, setColor, roadR - 2, 0, roadR + 3, h, rgb(0, 200, 255));
    // Perspective guide lines converge toward the city vanishing point.
    applyPaintColor(env, paint, setColor, 0x6655cfff);
    env->CallVoidMethod(paint, setStrokeWidth, 1.4f);
    env->CallVoidMethod(canvas, drawLine, w*.50f, h*.30f, roadL+w*.09f, h, paint);
    env->CallVoidMethod(canvas, drawLine, w*.50f, h*.30f, roadR-w*.09f, h, paint);
    applyPaintColor(env, paint, setColor, 0x553b7da8);
    env->CallVoidMethod(canvas, drawLine, roadL, h*.30f, roadL, h, paint);
    env->CallVoidMethod(canvas, drawLine, roadR, h*.30f, roadR, h, paint);
    for (int i = 0; i < 9; ++i) {
        float edgeY = std::fmod(i / 9.f + roadScroll, 1.f) * h;
        rect(env, canvas, drawRect, paint, setColor, roadL + 6, edgeY, roadL + 9, edgeY + h*.025f, rgb(0, 94, 150));
        rect(env, canvas, drawRect, paint, setColor, roadR - 9, edgeY, roadR - 6, edgeY + h*.025f, rgb(0, 94, 150));
    }
    // Animated roadside light pylons and cyan road reflectors.
    for (int i = 0; i < 4; ++i) {
        float ly = std::fmod(i / 4.f + roadScroll * .72f, 1.f) * h;
        float spread = .018f + ly / h * .035f;
        float leftX = roadL - w * spread;
        float rightX = roadR + w * spread;
        rect(env, canvas, drawRect, paint, setColor, leftX, ly - h*.045f, leftX + 2.2f, ly + h*.015f, rgb(35, 76, 112));
        rect(env, canvas, drawRect, paint, setColor, rightX - 2.2f, ly - h*.045f, rightX, ly + h*.015f, rgb(35, 76, 112));
        applyPaintColor(env, paint, setColor, 0xff6deaff);
        env->CallVoidMethod(canvas, drawCircle, leftX + 1.f, ly - h*.045f, 2.f + ly/h*2.f, paint);
        env->CallVoidMethod(canvas, drawCircle, rightX - 1.f, ly - h*.045f, 2.f + ly/h*2.f, paint);
    }

    bool boosting = nitroHeld && nitroEnergy > .02f && !gameOver && !paused;
    currentSpeed = (!paused && !gameOver) ? std::min(380, 118 + frameCount / 7 + speedLevel * 13 + (boosting ? 72 : 0)) : 0;
    if (!paused && !gameOver) {
        frameCount++;
        roadScroll += boosting ? .035f : .019f;
        if (roadScroll >= 1.f) roadScroll -= 1.f;
        if (frameCount % 4 == 0) score += boosting ? 2 : 1;

        if (frameCount % 75 == 0) {
            int r = frameCount % 300;
            if (r == 0 || r == 150) {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.08f, .055f, .055f, 0.f, 1, 0, true, false});
            } else if (r == 225) {
                float lane = .36f + (float)((frameCount / 75) % 2) * .28f;
                entities.push_back({lane, -.18f, .16f, .20f, (float)frameCount * .03f, 3, 8, true, false});
            } else {
                float lane = .25f + (float)((frameCount / 75) % 3) * .25f;
                entities.push_back({lane, -.18f, .105f, .145f, 0.f, 0, (frameCount / 75) % 10, true, false});
            }
        }
        if (frameCount % 215 == 0) {
            float lane = .25f + (float)((frameCount / 215) % 3) * .25f;
            entities.push_back({lane, -.22f, .105f, .16f, (float)frameCount * .047f, 2, (frameCount / 215 + 3) % 10, true, false});
        }
        if (entities.size() > 40) entities.erase(entities.begin(), entities.begin() + (entities.size() - 40));

        if (frameCount > 500) {
            policeActive = true;
            chase = clampf(chase + (boosting ? -.0017f : -.00075f - nitroLevel * .00008f), 0.f, 1.f);
        }
        if (boosting) nitroEnergy = std::max(0.f, nitroEnergy - (.0032f - nitroLevel * .00028f));
        else nitroEnergy = std::min(1.f, nitroEnergy + .0009f + nitroLevel * .0001f);
    }

    // Scrolling lane markings.
    for (int lane = 1; lane <= 2; ++lane) {
        float x = w * (.145f + .71f * lane / 3.f);
        for (int i = 0; i < 8; ++i) {
            float yy = std::fmod(i / 8.f + roadScroll, 1.f) * h;
            rect(env, canvas, drawRect, paint, setColor, x - 1.5f, yy, x + 1.5f, yy + h * .062f, rgb(72, 100, 135));
        }
    }
    // Fine wet-road reflections scroll beneath traffic without changing collision geometry.
    for (int i = 0; i < 12; ++i) {
        float yy = std::fmod(i / 12.f + roadScroll * 1.15f, 1.f) * h;
        float rw = w * (.008f + (yy / h) * .018f);
        float rx = roadL + (roadR - roadL) * (.18f + std::fmod(i * .173f, .64f));
        rect(env, canvas, drawRect, paint, setColor, rx, yy, rx + rw, yy + h*.008f,
             weatherMode == 1 ? 0x5546bde8 : 0x3346bde8);
    }

    float roadSpeed = .0040f + speedLevel * .00035f;
    for (auto &o : entities) {
        if (!o.active) continue;
        if (!paused && !gameOver) {
            float factor = o.type == 2 ? .78f : o.type == 3 ? .60f : 1.f;
            o.y += roadSpeed * (boosting ? 1.45f : 1.f) * factor;
            if (o.type == 2) {
                o.x = clampf(.50f + std::sin(frameCount * .018f + o.phase) * .24f, .23f, .77f);
            }
        }
        float ox = o.x * w;
        float oy = o.y * h;
        float bw = o.w * w;
        float bh = o.h * h;
        if (o.type == 1) {
            if (effectsOn) {
                applyPaintColor(env, paint, setColor, rgb(255, 193, 40));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .026f, paint);
                applyPaintColor(env, paint, setColor, rgb(255, 238, 145));
                env->CallVoidMethod(canvas, drawCircle, ox, oy, w * .016f, paint);
            }
            drawSprite(env, canvas, drawBitmap, coinBitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - bw * .55f, oy - bh * .55f, ox + bw * .55f, oy + bh * .55f);
            if (std::abs(o.x - carX) < .072f && std::abs(o.y - .80f) < .09f) {
                runCoins += 1; score += 25; o.active = false;
            }
        } else {
            jobject bitmap = o.type == 2 ? rivalBitmap : (o.type == 3 ? truckBitmap : trafficBitmap);
            float sw = o.type == 3 ? w * .15f : w * .095f;
            float sh = o.type == 3 ? h * .14f : h * .115f;
            drawSprite(env, canvas, drawBitmap, bitmap, srcRect, dstRect, rectSet, rectFSet,
                getWidth, getHeight, paint, ox - sw / 2, oy, ox + sw / 2, oy + sh);
            if (std::abs(o.x - carX) < (o.type == 3 ? .095f : .078f) &&
                o.y + (o.type == 3 ? .14f : .115f) > .745f && o.y < .88f) gameOver = true;
            if (o.type == 2 && !o.rewarded && o.y > .95f) { score += 50; o.rewarded = true; }
        }
        if (o.y > 1.15f) o.active = false;
    }

    // Police pursuit NPC. Nitro buys time; an approaching police car can end the race.
    if (policeActive) {
        if (!paused && !gameOver) policeX += clampf(carX - policeX, -.0045f, .0045f);
        float py = .93f - chase * .16f;
        float pw = w * .105f, ph = h * .12f;
        drawSprite(env, canvas, drawBitmap, policeBitmap, srcRect, dstRect, rectSet, rectFSet,
            getWidth, getHeight, paint, policeX * w - pw / 2, py * h, policeX * w + pw / 2, py * h + ph);
        if (effectsOn && frameCount % 10 < 5) {
            rect(env, canvas, drawRect, paint, setColor, policeX * w - pw * .24f, py * h + ph * .28f,
                 policeX * w, py * h + ph * .35f, rgb(35, 130, 255));
            rect(env, canvas, drawRect, paint, setColor, policeX * w, py * h + ph * .28f,
                 policeX * w + pw * .24f, py * h + ph * .35f, rgb(255, 45, 70));
        }
        if (chase > .94f && std::abs(policeX - carX) < .20f) gameOver = true;
    }

    // Weather overlays: lightweight procedural rain or layered low fog.
    if (weatherMode == 1) {
        applyPaintColor(env, paint, setColor, 0x887bcdf2);
        env->CallVoidMethod(paint, setStrokeWidth, 1.2f);
        for (int drop = 0; drop < 26; ++drop) {
            float rx = std::fmod(drop * 83.17f + frameCount * (1.4f + (drop % 3) * .35f), w);
            float ry = std::fmod(drop * 47.31f + frameCount * (4.2f + (drop % 4) * .6f), h);
            env->CallVoidMethod(canvas, drawLine, rx, ry, rx - w*.008f, ry + h*.025f, paint);
        }
    } else if (weatherMode == 2) {
        rect(env, canvas, drawRect, paint, setColor, 0, h*.30f, w, h*.43f, 0x223f9dc7);
        rect(env, canvas, drawRect, paint, setColor, 0, h*.56f, w, h*.67f, 0x183f9dc7);
    }

    // Nitro streaks behind the selected car sprite.
    if (boosting && effectsOn) {
        for (int i = 0; i < 7; ++i) {
            float sx = carX * w + std::sin((frameCount + i) * 1.7f) * w * .075f;
            float sy = h * (.89f + (i % 3) * .025f);
            rect(env, canvas, drawRect, paint, setColor, sx - 1.5f, sy, sx + 1.5f, sy + h * .07f,
                 i % 2 ? rgb(0, 195, 255) : rgb(120, 250, 255));
        }
        rect(env, canvas, drawRect, paint, setColor, carX * w - w * .018f, h * .86f,
             carX * w + w * .018f, h * .94f, rgb(255, 239, 120));
    }
    float playerW = w * .11f;
    float playerH = h * .145f;
    // Soft cyan underglow and contact shadow make the player car read clearly on the road.
    applyPaintColor(env, paint, setColor, effectsOn ? 0x5534dfff : 0x44202028);
    env->CallVoidMethod(canvas, drawCircle, carX * w, h * .84f, playerW * .62f, paint);
    applyPaintColor(env, paint, setColor, 0x99000000);
    env->CallVoidMethod(canvas, drawCircle, carX * w, h * .875f, playerW * .50f, paint);
    drawSprite(env, canvas, drawBitmap, playerBitmap, srcRect, dstRect, rectSet, rectFSet,
        getWidth, getHeight, paint, carX * w - playerW / 2, h * .745f,
        carX * w + playerW / 2, h * .745f + playerH);

    // Nitro energy bar.
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .705f, w * .73f, h * .721f, rgb(20, 40, 65));
    rect(env, canvas, drawRect, paint, setColor, w * .27f, h * .705f,
         w * (.27f + .46f * nitroEnergy), h * .721f,
         boosting ? rgb(255, 210, 80) : rgb(0, 205, 255));

    if (gameOver || paused) {
        applyPaintColor(env, paint, setColor, rgb(255, 255, 255));
        env->CallVoidMethod(paint, setTextSize, h * .034f);
        jstring msg = env->NewStringUTF(gameOver ? "RACE OVER" : "PAUSED");
        env->CallVoidMethod(canvas, drawText, msg, w * .36f, h * .48f, paint);
        env->DeleteLocalRef(msg);
    }

    env->DeleteLocalRef(srcRect); env->DeleteLocalRef(dstRect); env->DeleteLocalRef(paint);
    env->DeleteLocalRef(canvasClass); env->DeleteLocalRef(paintClass); env->DeleteLocalRef(rectClass);
    env->DeleteLocalRef(rectFClass); env->DeleteLocalRef(bitmapClass);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeTouch(JNIEnv*, jobject, jfloat x, jfloat y) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if (x < 0.f) { nitroHeld = false; return; }
    if (paused || gameOver) return;
    float touchX = leftHanded ? (1.f - x) : x;
    if (y > .38f) {
        if (touchX < .43f) carX = std::max(.22f, carX - (.115f + handlingLevel * .006f));
        else if (touchX > .57f) carX = std::min(.78f, carX + (.115f + handlingLevel * .006f));
        else nitroHeld = true;
    }
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSteer(JNIEnv*, jobject, jint direction) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if (paused || gameOver) return;
    float step = .115f + handlingLevel * .006f;
    if (direction < 0) carX = std::max(.22f, carX - step);
    else if (direction > 0) carX = std::min(.78f, carX + step);
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeNitro(JNIEnv*, jobject, jboolean down) {
    std::lock_guard<std::mutex> lock(gameMutex);
    nitroHeld = (down == JNI_TRUE) && !paused && !gameOver;
}
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeScore(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return score; }
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeCoins(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return runCoins; }
extern "C" JNIEXPORT jint JNICALL
Java_com_friss_neonracer_MainActivity_nativeSpeed(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return currentSpeed; }
extern "C" JNIEXPORT jboolean JNICALL
Java_com_friss_neonracer_MainActivity_nativeGameOver(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex); return gameOver ? JNI_TRUE : JNI_FALSE; }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativePause(JNIEnv*, jobject, jboolean p) {
    std::lock_guard<std::mutex> lock(gameMutex); paused = (p == JNI_TRUE); }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeReset(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gameMutex);
    carX = .5f; roadScroll = 0.f; chase = 0.f; policeX = .5f; nitroEnergy = 1.f;
    score = 0; runCoins = 0; frameCount = 0; currentSpeed = 0; paused = false; gameOver = false;
    nitroHeld = false; policeActive = false; entities.clear();
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetUpgrades(JNIEnv*, jobject, jint s, jint n, jint h) {
    std::lock_guard<std::mutex> lock(gameMutex);
    speedLevel = std::max(0, std::min(5, (int)s));
    nitroLevel = std::max(0, std::min(5, (int)n));
    handlingLevel = std::max(0, std::min(5, (int)h));
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetCarStyle(JNIEnv*, jobject, jint style) {
    std::lock_guard<std::mutex> lock(gameMutex);
    selectedCarStyle = std::max(0, std::min(9, (int)style));
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetOptions(JNIEnv*, jobject, jboolean effects, jboolean left) {
    std::lock_guard<std::mutex> lock(gameMutex);
    effectsOn = (effects == JNI_TRUE);
    leftHanded = (left == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeSetWeather(JNIEnv*, jobject, jint mode) {
    std::lock_guard<std::mutex> lock(gameMutex);
    weatherMode = std::max(0, std::min(2, (int)mode));
}

// -----------------------------------------------------------------------------
// PHASE 2: OpenGL ES 3.0 mobile racing renderer. The Canvas renderer above is
// retained as a compatibility fallback; the Android game surface now uses this
// real perspective scene with a chase camera and procedural 3D geometry.
// -----------------------------------------------------------------------------
#include <GLES3/gl3.h>
#include <array>
#include <cstring>

static GLuint glProgram = 0, glVbo = 0;
static GLint glPosLoc = -1, glMvpLoc = -1, glColorLoc = -1;
static float glAspect = 1.f;
static float glCameraX = 0.f;
static float glTime = 0.f;

static GLuint compileShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    GLint ok = 0; glGetShaderiv(shader, GL_COMPILE_STATUS, &ok);
    if (!ok) { glDeleteShader(shader); return 0; }
    return shader;
}
static void glInitScene() {
    const char* vs = "#version 300 es\nlayout(location=0) in vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
    const char* fs = "#version 300 es\nprecision mediump float; uniform vec4 uColor; out vec4 frag; void main(){frag=uColor;}";
    GLuint v = compileShader(GL_VERTEX_SHADER, vs), f = compileShader(GL_FRAGMENT_SHADER, fs);
    if (!v || !f) return;
    glProgram = glCreateProgram(); glAttachShader(glProgram, v); glAttachShader(glProgram, f);
    glLinkProgram(glProgram); glDeleteShader(v); glDeleteShader(f);
    GLint linked = 0; glGetProgramiv(glProgram, GL_LINK_STATUS, &linked);
    if (!linked) { glDeleteProgram(glProgram); glProgram = 0; return; }
    glPosLoc = 0; glMvpLoc = glGetUniformLocation(glProgram, "uMVP");
    glColorLoc = glGetUniformLocation(glProgram, "uColor");
    glGenBuffers(1, &glVbo);
    glEnable(GL_DEPTH_TEST); glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE); // Keep thin road planes visible from the chase-camera angle.
    glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}
static void matIdentity(float* m) { std::memset(m, 0, 16*sizeof(float)); m[0]=m[5]=m[10]=m[15]=1.f; }
static void matMultiply(float* out, const float* a, const float* b) {
    float t[16];
    for(int c=0;c<4;c++) for(int r=0;r<4;r++) { t[c*4+r]=0; for(int k=0;k<4;k++) t[c*4+r]+=a[k*4+r]*b[c*4+k]; }
    std::memcpy(out,t,sizeof(t));
}
static void matPerspective(float* m,float fovy,float aspect,float n,float f) {
    std::memset(m,0,16*sizeof(float)); float q=1.f/std::tan(fovy*.5f);
    m[0]=q/aspect; m[5]=q; m[10]=(f+n)/(n-f); m[11]=-1.f; m[14]=(2.f*f*n)/(n-f);
}
static void matLookAt(float* m,float ex,float ey,float ez,float cx,float cy,float cz) {
    float fx=cx-ex, fy=cy-ey, fz=cz-ez; float fl=std::sqrt(fx*fx+fy*fy+fz*fz); fx/=fl;fy/=fl;fz/=fl;
    float sx=fy*0.f-fz*1.f, sy=fz*0.f-fx*0.f, sz=fx*1.f-fy*0.f;
    float sl=std::sqrt(sx*sx+sy*sy+sz*sz); sx/=sl;sy/=sl;sz/=sl;
    float ux=sy*fz-sz*fy, uy=sz*fx-sx*fz, uz=sx*fy-sy*fx;
    matIdentity(m); m[0]=sx;m[4]=sy;m[8]=sz; m[1]=ux;m[5]=uy;m[9]=uz; m[2]=-fx;m[6]=-fy;m[10]=-fz;
    m[12]=-(sx*ex+sy*ey+sz*ez); m[13]=-(ux*ex+uy*ey+uz*ez); m[14]=(fx*ex+fy*ey+fz*ez);
}
static void matModel(float* m,float x,float y,float z,float sx,float sy,float sz) {
    matIdentity(m); m[0]=sx;m[5]=sy;m[10]=sz;m[12]=x;m[13]=y;m[14]=z;
}
static void glDrawMesh(const float* verts, int count, const float* mvp, float r,float g,float b,float a=1.f) {
    if (!glProgram || count<=0) return;
    glUseProgram(glProgram); glUniformMatrix4fv(glMvpLoc,1,GL_FALSE,mvp);
    glUniform4f(glColorLoc,r,g,b,a); glBindBuffer(GL_ARRAY_BUFFER,glVbo);
    glBufferData(GL_ARRAY_BUFFER,(GLsizeiptr)(count*3*sizeof(float)),verts,GL_STREAM_DRAW);
    glEnableVertexAttribArray((GLuint)glPosLoc); glVertexAttribPointer((GLuint)glPosLoc,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    glDrawArrays(GL_TRIANGLES,0,count); glDisableVertexAttribArray((GLuint)glPosLoc);
}
static void glBox(const float* vp,float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,float a=1.f) {
    static const float cube[] = {
      -1,-1,1, 1,-1,1, 1,1,1, -1,-1,1, 1,1,1, -1,1,1,
      1,-1,-1, -1,-1,-1, -1,1,-1, 1,-1,-1, -1,1,-1, 1,1,-1,
      -1,-1,-1, -1,-1,1, -1,1,1, -1,-1,-1, -1,1,1, -1,1,-1,
      1,-1,1, 1,-1,-1, 1,1,-1, 1,-1,1, 1,1,-1, 1,1,1,
      -1,1,1, 1,1,1, 1,1,-1, -1,1,1, 1,1,-1, -1,1,-1,
      -1,-1,-1, 1,-1,-1, 1,-1,1, -1,-1,-1, 1,-1,1, -1,-1,1
    };
    float model[16],mvp[16]; matModel(model,x,y,z,sx,sy,sz); matMultiply(mvp,vp,model);
    glDrawMesh(cube,36,mvp,r,g,b,a);
}
static void glQuad(const float* vp,float x1,float z1,float x2,float z2,float y,float r,float g,float b) {
    float v[]={x1,y,z1, x2,y,z1, x2,y,z2, x1,y,z1, x2,y,z2, x1,y,z2};
    glDrawMesh(v,6,vp,r,g,b,1.f);
}
static float roadCenter(float z) {
    float d=-z + roadScroll*24.f;
    return std::sin(d*.035f)*1.15f + std::sin(d*.012f)*.48f;
}
static void glRoadStrip(const float* vp,float z1,float z2,float halfWidth,float y,float r,float g,float b) {
    float c1=roadCenter(z1), c2=roadCenter(z2);
    float v[]={c1-halfWidth,y,z1, c1+halfWidth,y,z1, c2+halfWidth,y,z2,
               c1-halfWidth,y,z1, c2+halfWidth,y,z2, c2-halfWidth,y,z2};
    glDrawMesh(v,6,vp,r,g,b,1.f);
}
static void glFace(const float* vp, const float* v, float r, float g, float b, float a=1.f) {
    glDrawMesh(v,6,vp,r,g,b,a);
}
static void glCar(const float* vp,float x,float z,float scale,float bodyR,float bodyG,float bodyB,
                  bool player,int variant=0,bool truck=false) {
    variant = std::max(0, std::min(9, variant));
    if (truck) variant = 8;

    // Ten separate body profiles. Each vehicle changes its actual proportions,
    // roof/cabin footprint, tail treatment, aero and wheel placement.
    static const float widths[10]       = {.61f,.65f,.73f,.69f,.62f,.66f,.67f,.72f,.74f,.58f};
    static const float lengths[10]      = {1.06f,1.16f,1.21f,1.19f,1.05f,1.10f,1.12f,1.16f,1.10f,.99f};
    static const float frontTaper[10]   = {.72f,.77f,.92f,.84f,.74f,.80f,.81f,.91f,.93f,.76f};
    static const float rearTaper[10]    = {.96f,.98f,.96f,.93f,.91f,.99f,.96f,.99f,.98f,.89f};
    static const float cabinW[10]       = {.40f,.36f,.34f,.36f,.43f,.41f,.39f,.37f,.40f,.36f};
    static const float cabinL[10]       = {.49f,.53f,.58f,.50f,.48f,.47f,.49f,.53f,.48f,.45f};
    static const float cabinY[10]       = {.31f,.30f,.32f,.34f,.30f,.35f,.33f,.31f,.33f,.37f};
    static const float cabinShift[10]   = {-.02f,-.04f,-.08f,-.02f,-.01f,.00f,-.01f,-.04f,.01f,.06f};
    float width = truck ? .80f : widths[variant];
    float length = truck ? 1.22f : lengths[variant];
    float r = width * scale;
    float l = length * scale;
    float y0 = .02f;
    float frontW = r * frontTaper[variant];
    float rearW = r * rearTaper[variant];

    // Lower chassis with model-specific length and width.
    glBox(vp,x,.055f*scale,z,r*.91f,.075f*scale,l*.94f,.012f,.018f,.035f);

    // Sculpted upper shell: front nose width and rear haunch width differ per model.
    const float top[]={
        x-frontW,y0+.19f*scale,z-l*.98f,
        x+frontW,y0+.19f*scale,z-l*.98f,
        x+rearW,y0+.25f*scale,z+l*.87f,
        x-rearW,y0+.25f*scale,z+l*.87f,
        x-frontW,y0+.19f*scale,z-l*.98f,
        x+rearW,y0+.25f*scale,z+l*.87f,
    };
    glFace(vp,top,bodyR,bodyG,bodyB);

    // Side facets and pronounced shoulder/rocker geometry.
    const float leftSide[]={
        x-frontW,y0+.19f*scale,z-l*.98f,
        x-rearW,y0+.25f*scale,z+l*.87f,
        x-r*.98f,y0-.005f,z+l*.92f,
        x-r*.91f,y0-.005f,z-l*.90f,
        x-frontW,y0+.19f*scale,z-l*.98f,
        x-r*.98f,y0-.005f,z+l*.92f,
    };
    glFace(vp,leftSide,std::max(.01f,bodyR*.62f),std::max(.01f,bodyG*.62f),std::max(.01f,bodyB*.68f));
    const float rightSide[]={
        x+frontW,y0+.19f*scale,z-l*.98f,
        x+r*.91f,y0-.005f,z-l*.90f,
        x+r*.98f,y0-.005f,z+l*.92f,
        x+rearW,y0+.25f*scale,z+l*.87f,
        x+frontW,y0+.19f*scale,z-l*.98f,
        x+r*.98f,y0-.005f,z+l*.92f,
    };
    glFace(vp,rightSide,std::max(.01f,bodyR*.57f),std::max(.01f,bodyG*.57f),std::max(.01f,bodyB*.64f));

    if(!truck) {
        float cabX = x;
        float cabZ = z + cabinShift[variant]*scale;
        float cw = cabinW[variant]*scale;
        float cl = cabinL[variant]*scale;
        float cy = cabinY[variant]*scale;
        // Separate windshield, roof and rear glass give different car silhouettes.
        glBox(vp,cabX,cy,cabZ,cw, .145f*scale,cl, .018f,.050f,.092f);
        glBox(vp,cabX,cy+.145f*scale,cabZ-.025f*scale,cw*.82f,.035f*scale,cl*.76f,bodyR*.67f,bodyG*.68f,bodyB*.76f);
        const float rearGlass[]={
            cabX-cw*.80f,.47f*scale,cabZ+cl*.62f,
            cabX+cw*.80f,.47f*scale,cabZ+cl*.62f,
            x+rearW*.68f,.255f*scale,z+l*.77f,
            x-rearW*.68f,.255f*scale,z+l*.77f,
            cabX-cw*.80f,.47f*scale,cabZ+cl*.62f,
            x+rearW*.68f,.255f*scale,z+l*.77f,
        };
        glFace(vp,rearGlass,.018f,.075f,.14f);
        // A longer, lower front glass on GT/supercars; taller cabin on hatch/rally cars.
        if(variant==2 || variant==3) {
            glBox(vp,x,.275f*scale,z-l*.59f,.34f*scale,.018f*scale,.25f*scale,.07f,.20f,.31f);
        } else if(variant==5 || variant==6 || variant==9) {
            glBox(vp,x,.43f*scale,z-.02f*scale,.32f*scale,.018f*scale,.26f*scale,.10f,.24f,.37f);
        }
    } else {
        glBox(vp,x,.56f*scale,z-.14f*scale,.65f*scale,.42f*scale,.56f*scale,.10f,.14f,.20f);
        glBox(vp,x,.63f*scale,z+.36f*scale,.69f*scale,.50f*scale,.44f*scale,.30f,.36f,.43f);
        glBox(vp,x,.66f*scale,z+.81f*scale,.70f*scale,.53f*scale,.12f*scale,.42f,.49f,.58f);
    }

    // Wider/lower supercar tyres, high-ride rally stance, and distinct wheelbase.
    float axleFront = (variant==2 || variant==3) ? .61f : (variant==9 ? .48f : .54f);
    float axleRear = (variant==4 || variant==9) ? .48f : .56f;
    for(int side=-1;side<=1;side+=2) {
        for(int axle=-1;axle<=1;axle+=2) {
            float wheelZ = z + (axle>0 ? axleRear : -axleFront)*l;
            float wheelX = x + side*(r*.91f);
            float tireH = (variant==5 || variant==6 || variant==9) ? .17f : .145f;
            glBox(vp,wheelX,.095f*scale,wheelZ,.11f*scale,tireH*scale,.235f*scale,.006f,.010f,.018f);
            glBox(vp,wheelX-side*.018f,.095f*scale,wheelZ,.078f*scale,.078f*scale,.115f*scale,.22f,.31f,.42f);
        }
    }

    // Model-specific rear fascia and tail lamp signatures.
    glBox(vp,x,.105f*scale,z+l*.94f,r*.82f,.055f*scale,.10f*scale,.018f,.025f,.045f);
    if(variant==0 || variant==5 || variant==6) {
        // Four compact round-lamp inspired clusters.
        for(int side=-1;side<=1;side+=2) {
            glBox(vp,x+side*r*.56f,.235f*scale,z+l*.96f,.14f*scale,.058f*scale,.028f*scale,1.f,.025f,.065f);
            glBox(vp,x+side*r*.56f,.235f*scale,z+l*.965f,.075f*scale,.045f*scale,.018f*scale,1.f,.20f,.28f);
        }
    } else if(variant==2 || variant==3) {
        glBox(vp,x-r*.58f,.22f*scale,z+l*.96f,.24f*scale,.032f*scale,.025f*scale,1.f,.035f,.075f);
        glBox(vp,x+r*.58f,.22f*scale,z+l*.96f,.24f*scale,.032f*scale,.025f*scale,1.f,.035f,.075f);
        glBox(vp,x,.205f*scale,z+l*.97f,.24f*scale,.018f*scale,.02f*scale,.86f,.025f,.055f);
    } else if(variant==8) {
        glBox(vp,x-r*.58f,.23f*scale,z+l*.96f,.27f*scale,.052f*scale,.025f*scale,1.f,.06f,.035f);
        glBox(vp,x+r*.58f,.23f*scale,z+l*.96f,.27f*scale,.052f*scale,.025f*scale,1.f,.06f,.035f);
    } else {
        glBox(vp,x-r*.56f,.22f*scale,z+l*.96f,.20f*scale,.045f*scale,.025f*scale,1.f,.045f,.075f);
        glBox(vp,x+r*.56f,.22f*scale,z+l*.96f,.20f*scale,.045f*scale,.025f*scale,1.f,.045f,.075f);
    }
    glBox(vp,x,.075f*scale,z+l*1.01f,r*.52f,.045f*scale,.035f*scale,.006f,.010f,.018f);
    for(int side=-1;side<=1;side+=2)
        glBox(vp,x+side*r*.42f,.07f*scale,z+l*1.03f,.055f*scale,.035f*scale,.045f*scale,.38f,.48f,.58f);

    // Spoiler and ducktail differ by model, rather than applying one universal wing.
    bool largeWing = (variant==0 || variant==1 || variant==5 || variant==6 || variant==7);
    bool ducktail = (variant==2 || variant==3 || variant==9);
    if(largeWing && !truck) {
        float wingSpan = (variant==7 ? 1.02f : (variant==6 ? .94f : .86f))*scale;
        float wingY = (variant==5 || variant==6) ? .67f : .57f;
        glBox(vp,x,.43f*scale,z+l*.75f,.045f*scale,.16f*scale,.045f,.035f,.045f,.065f);
        glBox(vp,x,wingY*scale,z+l*.80f,wingSpan,.045f*scale,.13f*scale,.012f,.022f,.045f);
        glBox(vp,x,(wingY+.012f)*scale,z+l*.80f,wingSpan*.92f,.018f*scale,.09f*scale,player?.10f:.16f,player?.72f:.34f,player?1.f:.52f);
    } else if(ducktail && !truck) {
        glBox(vp,x,.30f*scale,z+l*.82f,.68f*scale,.045f*scale,.075f*scale,bodyR*.75f,bodyG*.75f,bodyB*.78f);
    }

    // Signature body kits: hood vents, side intakes, roof scoop, rally cladding, muscle bonnet.
    if(variant==0) { // Takara: tuner sedan with twin bonnet vents
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*.19f*scale,.245f*scale,z-l*.64f,.105f*scale,.018f*scale,.23f*scale,.018f,.035f,.052f);
    } else if(variant==1) { // Kurosawa: GT side blades and wide rear deck
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.91f,.18f*scale,z-.02f*scale,.045f*scale,.055f*scale,.64f*scale,.37f,.48f,.61f);
        glBox(vp,x,.27f*scale,z+l*.58f,.34f*scale,.018f*scale,.16f*scale,.025f,.06f,.10f);
    } else if(variant==2) { // Toro: low supercar with angular rear vents
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.70f,.20f*scale,z+l*.53f,.12f*scale,.018f*scale,.21f*scale,.012f,.025f,.045f);
    } else if(variant==3) { // Velare: exotic side intakes
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.89f,.20f*scale,z+.02f*scale,.035f*scale,.055f*scale,.28f*scale,.015f,.075f,.14f);
    } else if(variant==4) { // Nemo: luxury GT with clean long deck and chrome strip
        glBox(vp,x,.23f*scale,z+l*.69f,.42f*scale,.018f*scale,.035f*scale,.40f,.50f,.62f);
    } else if(variant==5) { // Hayate: rally roof scoop and raised ride stance
        glBox(vp,x,.52f*scale,z-.12f*scale,.23f*scale,.04f*scale,.25f*scale,.025f,.055f,.09f);
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.91f,.17f*scale,z,.055f*scale,.06f*scale,.68f*scale,.025f,.09f,.16f);
    } else if(variant==6) { // Raijin: bonnet power bulge and rally skirts
        glBox(vp,x,.26f*scale,z-l*.48f,.28f*scale,.055f*scale,.40f*scale,bodyR*.76f,bodyG*.76f,bodyB*.76f);
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.92f,.15f*scale,z,.05f*scale,.055f*scale,.74f*scale,.02f,.06f,.10f);
    } else if(variant==7) { // Vortex: long coupe with twin exhaust/deck diffuser
        glBox(vp,x,.24f*scale,z+l*.67f,.48f*scale,.025f*scale,.19f*scale,.10f,.13f,.18f);
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*.31f*scale,.075f*scale,z+l*1.05f,.09f*scale,.045f*scale,.055f*scale,.18f,.22f,.29f);
    } else if(variant==8) { // Blaze: wide muscle coupe with long hood scoop
        glBox(vp,x,.25f*scale,z-l*.61f,.22f*scale,.055f*scale,.35f*scale,.035f,.045f,.06f);
        glBox(vp,x,.315f*scale,z-l*.57f,.14f*scale,.018f*scale,.26f*scale,.62f,.68f,.76f);
    } else { // Shinobi: compact hatch with roof spoiler and short wheelbase
        glBox(vp,x,.31f*scale,z-l*.23f,.35f*scale,.025f*scale,.06f*scale,.22f,.05f,.45f);
        glBox(vp,x,.35f*scale,z+l*.69f,.52f*scale,.02f*scale,.07f*scale,.40f,.12f,.70f);
    }

    // Front splitter, headlights and model-specific side skirts.
    glBox(vp,x,.09f*scale,z-l*1.01f,r*.82f,.035f*scale,.045f*scale,.015f,.025f,.045f);
    glBox(vp,x-r*.55f,.20f*scale,z-l*.995f,.18f*scale,.035f*scale,.025f*scale,.68f,.86f,1.f);
    glBox(vp,x+r*.55f,.20f*scale,z-l*.995f,.18f*scale,.035f*scale,.025f*scale,.68f,.86f,1.f);
    if(variant==5 || variant==6 || variant==9) {
        for(int side=-1;side<=1;side+=2) glBox(vp,x+side*r*.93f,.10f*scale,z,.045f*scale,.05f*scale,.82f*scale,.02f,.10f,.18f);
    }

    if(player) {
        // Selected car always gets a blue underglow and brighter dual exhaust effects.
        glBox(vp,x-r*.50f,.018f,z,.045f*scale,.018f*scale,l*1.48f,.02f,.42f,.95f,.48f);
        glBox(vp,x+r*.50f,.018f,z,.045f*scale,.018f*scale,l*1.48f,.02f,.42f,.95f,.48f);
        glBox(vp,x-r*.40f,.08f*scale,z+l*1.04f,.07f*scale,.035f*scale,.06f*scale,.22f,.80f,1.f);
        glBox(vp,x+r*.40f,.08f*scale,z+l*1.04f,.07f*scale,.035f*scale,.06f*scale,.22f,.80f,1.f);
    }
}
static void glUpdateSimulation(float dt) {
    if(paused || gameOver) { currentSpeed=0; return; }
    float step=std::max(.25f,std::min(2.5f,dt*60.f));
    bool boosting=nitroHeld && nitroEnergy>.02f;
    currentSpeed=std::min(380,118+frameCount/7+speedLevel*13+(boosting?72:0));
    frameCount++;
    roadScroll+= (boosting?.035f:.019f)*step; if(roadScroll>=1.f)roadScroll-=std::floor(roadScroll);
    if(frameCount%4==0)score+=boosting?2:1;
    // A steady multi-lane traffic stream: NPCs cycle through ten distinct model/paint variants.
    if(frameCount%58==0) {
        int sequence=(frameCount/58);
        float lane=.25f+(float)(sequence%3)*.25f;
        entities.push_back({lane,-.20f,.105f,.145f,0.f,0,sequence%10,true,false});
        if(sequence%3==0) {
            int secondLane=(sequence+1)%3;
            entities.push_back({.25f+(float)secondLane*.25f,-.30f,.105f,.145f,0.f,0,(sequence+4)%10,true,false});
        }
    }
    if(frameCount%165==0) {
        float lane=.25f+(float)((frameCount/165)%3)*.25f;
        int variant=(frameCount/165+5)%10;
        entities.push_back({lane,-.24f,.105f,.16f,(float)frameCount*.047f,2,variant,true,false});
    }
    // Keep the existing coin pickup and wallet reward loop active in the new renderer.
    if(frameCount%205==0) {
        float lane=.25f+(float)((frameCount/205)%3)*.25f;
        entities.push_back({lane,-.12f,.055f,.055f,0.f,1,0,true,false});
    }
    if(frameCount%390==0) {
        float lane=(frameCount/390)%2==0 ? .36f : .64f;
        entities.push_back({lane,-.34f,.16f,.20f,(float)frameCount*.03f,3,8,true,false});
    }
    if(entities.size()>40)entities.erase(entities.begin(),entities.begin()+(entities.size()-40));
    if(frameCount>500){policeActive=true;chase=clampf(chase+(boosting?-.0017f:-.00075f-nitroLevel*.00008f)*step,0.f,1.f);}
    if(boosting)nitroEnergy=std::max(0.f,nitroEnergy-(.0032f-nitroLevel*.00028f)*step);
    else nitroEnergy=std::min(1.f,nitroEnergy+(.0009f+nitroLevel*.0001f)*step);
    float roadSpeed=(.0040f+speedLevel*.00035f)*step;
    for(auto &o:entities){if(!o.active)continue;float factor=o.type==2?.78f:o.type==3?.60f:1.f;o.y+=roadSpeed*(boosting?1.45f:1.f)*factor;
        if(o.type==2)o.x=clampf(.50f+std::sin(frameCount*.018f+o.phase)*.24f,.23f,.77f);
        if(o.type==1){if(std::abs(o.x-carX)<.072f&&std::abs(o.y-.80f)<.09f){runCoins++;score+=25;o.active=false;}}
        else {if(std::abs(o.x-carX)<(o.type==3?.095f:.078f)&&o.y+(o.type==3?.14f:.115f)>.745f&&o.y<.88f)gameOver=true;
            if(o.type==2&&!o.rewarded&&o.y>.95f){score+=50;o.rewarded=true;}}
        if(o.y>1.15f)o.active=false;
    }
    if(policeActive){policeX+=clampf(carX-policeX,-.0045f,.0045f)*step;if(chase>.94f&&std::abs(policeX-carX)<.20f)gameOver=true;}
}
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeGlInit(JNIEnv*,jobject) { glInitScene(); }
extern "C" JNIEXPORT void JNICALL
Java_com_friss_neonracer_MainActivity_nativeRenderGL(JNIEnv*,jobject,jint width,jint height,jfloat delta) {
    std::lock_guard<std::mutex> lock(gameMutex);
    if(!glProgram)glInitScene();
    const float w=(float)std::max(1,(int)width),h=(float)std::max(1,(int)height);
    glAspect=w/h; glTime+=std::max(0.f,std::min(.05f,(float)delta)); glUpdateSimulation(delta);
    bool boosting=nitroHeld&&nitroEnergy>.02f&&!paused&&!gameOver;
    glViewport(0,0,(GLsizei)width,(GLsizei)height);
    if(weatherMode==2) glClearColor(.018f,.035f,.075f,1.f);
    else glClearColor(.004f,.009f,.026f,1.f);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    float projection[16],view[16],vp[16];
    float cameraTarget=roadCenter(-7.f)+(carX-.5f)*.34f;
    glCameraX+=(cameraTarget-glCameraX)*.085f;
    matPerspective(projection,.88f,glAspect,.1f,145.f);
    matLookAt(view,glCameraX,4.35f,9.4f,glCameraX*.72f,.05f,-13.0f);
    matMultiply(vp,projection,view);

    // Deep-blue urban sky, distant skyline and a dark ground plane.
    glQuad(vp,-110.f,-130.f,110.f,30.f,-.68f,.012f,.022f,.052f);
    for(int side=-1;side<=1;side+=2) {
        for(int i=0;i<11;i++) {
            float z=13.f-i*8.7f+roadScroll*10.f; while(z>17.f)z-=96.f;
            float center=roadCenter(z);
            float bx=center+side*(9.4f+(i%3)*2.2f);
            float bh=4.2f+(float)((i*7+3)%7)*1.15f;
            float bw=1.25f+(i%3)*.38f;
            float depth=2.8f+(i%2)*.8f;
            glBox(vp,bx,bh*.5f,z,bw,bh*.5f,depth,.018f,.035f,.082f);
            // A few saturated facade strips create the neon-city skyline without heavy textures.
            glBox(vp,bx-side*bw*.86f,bh*.47f,z+depth*.54f,.035f,bh*.43f,.035f,.018f,.18f,.44f);
            glBox(vp,bx+side*bw*.80f,bh*.50f,z+depth*.54f,.025f,bh*.46f,.035f,.02f,.31f,.58f);
            for(int row=0;row<4;row++) {
                float wy=.75f+(float)row*(bh-.9f)/4.f;
                glBox(vp,bx-bw*.38f,wy,z+depth*.56f,.12f,.065f,.035f,(i+row)%4==0?.72f:.035f,(i+row)%4==0?.10f:.34f,(i+row)%4==0?.32f:.78f);
                glBox(vp,bx+bw*.28f,wy+.12f,z+depth*.56f,.12f,.065f,.035f,.035f,.48f,.86f);
            }
        }
    }
    // Distant bridge lights and two neon gantries over the highway.
    for(int gate=0;gate<2;gate++) {
        float gz=-24.f-gate*42.f+(roadScroll*8.f); while(gz>10.f)gz-=84.f;
        float gc=roadCenter(gz);
        glBox(vp,gc,5.3f,gz,6.3f,.13f,.22f,.018f,.10f,.25f);
        glBox(vp,gc,5.48f,gz,5.9f,.035f,.055f,.06f,.54f,1.f);
        glBox(vp,gc-6.0f,2.8f,gz,.12f,2.7f,.12f,.035f,.10f,.19f);
        glBox(vp,gc+6.0f,2.8f,gz,.12f,2.7f,.12f,.035f,.10f,.19f);
        glBox(vp,gc-6.0f,5.25f,gz,.20f,.055f,.20f,.02f,.36f,.72f);
        glBox(vp,gc+6.0f,5.25f,gz,.20f,.055f,.20f,.02f,.36f,.72f);
    }

    // Wet-looking asphalt, dark shoulders, cyan edge strips and lane markers.
    for(int seg=0;seg<34;seg++) {
        float z1=13.f-seg*3.0f, z2=z1-3.0f;
        glRoadStrip(vp,z1,z2,6.5f,-.14f,.035f,.052f,.082f);
        glRoadStrip(vp,z1,z2,5.78f,-.085f,.055f,.070f,.105f);
        float c1=roadCenter(z1),c2=roadCenter(z2);
        float left[]={c1-5.99f,-.045f,z1,c1-5.82f,-.045f,z1,c2-5.82f,-.045f,z2,c1-5.99f,-.045f,z1,c2-5.82f,-.045f,z2,c2-5.99f,-.045f,z2};
        float right[]={c1+5.82f,-.045f,z1,c1+5.99f,-.045f,z1,c2+5.99f,-.045f,z2,c1+5.82f,-.045f,z1,c2+5.99f,-.045f,z2,c2+5.82f,-.045f,z2};
        glDrawMesh(left,6,vp,.015f,.36f,.74f,1.f); glDrawMesh(right,6,vp,.015f,.36f,.74f,1.f);
    }
    for(int lane=1;lane<=2;lane++)for(int i=0;i<26;i++) {
        float z=11.f-i*3.6f+(roadScroll*18.f); while(z>12.f)z-=94.f;
        float cx=roadCenter(z)+(-3.85f+lane*2.566f);
        glQuad(vp,cx-.035f,z-1.05f,cx+.035f,z,.001f,.44f,.62f,.78f);
    }
    // Colored road reflections are short transparent streaks close to the edge rails.
    for(int i=0;i<18;i++) {
        float z=8.f-i*5.0f+(roadScroll*17.f); while(z>12.f)z-=90.f;
        float c=roadCenter(z);
        glBox(vp,c-4.85f,-.035f,z,.025f,.008f,1.15f,.02f,.20f,.48f,.42f);
        glBox(vp,c+4.85f,-.035f,z,.025f,.008f,1.15f,.32f,.025f,.16f,.28f);
    }

    // Guardrails, lamp posts, light heads and repeating roadside neon pylons.
    for(int i=0;i<22;i++) {
        float z=9.f-i*4.3f+(roadScroll*21.f); while(z>11.f)z-=95.f;
        float center=roadCenter(z);
        glBox(vp,center-6.15f,.26f,z,.11f,.14f,1.9f,.16f,.24f,.37f);
        glBox(vp,center+6.15f,.26f,z,.11f,.14f,1.9f,.16f,.24f,.37f);
        glBox(vp,center-7.1f,2.35f,z,.045f,2.25f,.045f,.035f,.14f,.27f);
        glBox(vp,center+7.1f,2.35f,z,.045f,2.25f,.045f,.035f,.14f,.27f);
        glBox(vp,center-7.1f,4.65f,z,.28f,.075f,.28f,.025f,.49f,.95f);
        glBox(vp,center+7.1f,4.65f,z,.28f,.075f,.28f,.025f,.49f,.95f);
    }

    // Traffic cars, rival racers, heavy vehicles and coins approach in perspective.
    static const float palette[10][3]={{.04f,.22f,.92f},{.72f,.76f,.82f},{.98f,.57f,.025f},{.78f,.035f,.07f},{.47f,.56f,.67f},{.025f,.30f,.82f},{.70f,.025f,.055f},{.025f,.045f,.075f},{.82f,.85f,.88f},{.30f,.035f,.72f}};
    for(auto &o:entities) {
        if(!o.active)continue;
        float z=-43.f+o.y*48.f;
        float x=roadCenter(z)+(o.x-.5f)*8.2f;
        float scale=.30f+o.y*.92f;
        if(o.type==1) {
            glBox(vp,x,.48f,z,.17f*scale,.17f*scale,.17f*scale,1.f,.60f,.035f);
            glBox(vp,x,.48f,z-.025f,.09f*scale,.20f*scale,.10f*scale,1.f,.92f,.40f);
        } else if(o.type==3) {
            glCar(vp,x,z,scale,.34f,.41f,.52f,false,8,true);
        } else {
            int variant=o.variant%10;
            float cr=palette[variant][0],cg=palette[variant][1],cb=palette[variant][2];
            glCar(vp,x,z,scale,cr,cg,cb,false,variant,false);
        }
    }
    if(policeActive) {
        float pz=-1.0f-(1.f-chase)*10.f;
        glCar(vp,roadCenter(pz)+(policeX-.5f)*8.2f,pz,.86f,.025f,.12f,.42f,false,0,false);
        glBox(vp,roadCenter(pz)+(policeX-.5f)*8.2f-.18f,.47f,pz+.55f,.12f,.055f,.08f,1.f,.025f,.035f);
        glBox(vp,roadCenter(pz)+(policeX-.5f)*8.2f+.18f,.47f,pz+.55f,.12f,.055f,.08f,.025f,.20f,1.f);
    }

    // Player vehicle stays in the near foreground; its model follows selected garage paint.
    float playerX=roadCenter(-1.55f)+(carX-.5f)*8.2f;
    static const float playerPalette[10][3]={{.04f,.22f,.92f},{.72f,.76f,.82f},{.98f,.57f,.025f},{.78f,.035f,.07f},{.47f,.56f,.67f},{.025f,.30f,.82f},{.70f,.025f,.055f},{.025f,.045f,.075f},{.82f,.85f,.88f},{.30f,.035f,.72f}};
    int style=std::max(0,std::min(9,selectedCarStyle));
    if(boosting) {
        glBox(vp,playerX-.31f,.025f,-.18f,.045f,.04f,1.65f,.02f,.55f,1.f);
        glBox(vp,playerX+.31f,.025f,-.18f,.045f,.04f,1.65f,.02f,.55f,1.f);
        for(int i=0;i<9;i++) {
            float sx=playerX+std::sin(glTime*8.f+i*1.73f)*1.8f;
            glBox(vp,sx,.03f,-7.f-(i%4)*2.5f,.014f,.016f,.95f,.06f,.46f,.92f,.70f);
        }
    }
    glCar(vp,playerX,-1.55f,1.22f,playerPalette[style][0],playerPalette[style][1],playerPalette[style][2],true,style,false);
    if(weatherMode==1) {
        for(int i=0;i<32;i++) {
            float x=std::fmod(i*1.73f+glTime*5.f,15.f)-7.5f;
            float z=-5.f-std::fmod(i*4.13f+glTime*18.f,48.f);
            glBox(vp,x,3.4f,z,.012f,.012f,.60f,.40f,.58f,.78f,.72f);
        }
    } else if(weatherMode==2) {
        // Low fog banks sit near the road horizon and preserve the dark-night palette.
        glBox(vp,0.f,.28f,-48.f,15.f,.20f,2.2f,.18f,.25f,.38f,.18f);
    }
}
